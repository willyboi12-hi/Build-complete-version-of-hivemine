# Test guide

Run the engine's JVM tests with no phone and no Android SDK:

```bash
bash tests/run.sh
```

The script compiles `tests/unit/com/hiveminemobile/RunTests.java` against the engine classes in `app/src/main/java` (via `-sourcepath`), with the Android stand-ins in `tests/fakes`, then runs `com.hiveminemobile.RunTests`.

What the tests cover, and what they can't cover, is listed in `tests/README.md`.

The stand-ins are not the real Android framework. `bash tests/run-ai.sh` tests the AI tab and its buttons with the same fakes. Gestures, overlays, screenshots, accessibility, and Roblox behavior must be verified on a physical device (see `DEVICE_TEST_MATRIX.md`).
