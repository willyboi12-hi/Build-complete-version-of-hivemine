# Security and privacy notes

- Accessibility access is powerful. Enable it only when the user understands and authorizes the visible UI automation.
- Android does not permit an app to silently re-enable an accessibility service disabled by the user or system. Stop and direct the user to Android settings.
- Do not collect credentials, cookies, tokens, or unrelated screen contents.
- Keep diagnostic logs bounded and avoid logging private screen data.
- Do not commit signing keys, passwords, API keys, or personal server links.
- Review exported Android components and permissions before release.
- Use dependencies only when needed and review their provenance and update status.
- Keep release signing credentials outside source control.
- This project does not guarantee compliance with Roblox rules or freedom from account enforcement.
