#!/usr/bin/env bash
# Tests the AI features without a phone, using test fakes in tests/fakes:
#   AiBridgeChecks: the AI switch, Start/Recover/Stop rules, messages, restart persistence.
#   AiTabChecks:    builds the real floating dashboard, opens its AI tab, presses its buttons.
#   AndroidWiringChecks: readiness (phase 085) and the macro command bridge (phase 089) in the app code.
# Not covered: real drawing and touch. Those need a device.
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="build/tests-ai"
rm -rf "$OUT"
mkdir -p "$OUT"
SP="tests/fakes:app/src/main/java:hivemine-ai/ai-core/src/main/java"
javac -Xmaxerrs 1000 -encoding UTF-8 -nowarn -d "$OUT" -sourcepath "$SP" tests/ai/com/hiveminemobile/AiBridgeChecks.java tests/ai/com/hiveminemobile/AiTabChecks.java tests/ai/com/hiveminemobile/AndroidWiringChecks.java
java -cp "$OUT" com.hiveminemobile.AiBridgeChecks
java -cp "$OUT" com.hiveminemobile.AiTabChecks
java -cp "$OUT" com.hiveminemobile.AndroidWiringChecks
