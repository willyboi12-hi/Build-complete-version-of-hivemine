package android.database;
public interface Cursor {
    boolean moveToNext();
    long getLong(int columnIndex);
    String getString(int columnIndex);
    void close();
}
