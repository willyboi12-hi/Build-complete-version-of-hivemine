package android.database.sqlite;
import android.content.ContentValues;
import android.database.Cursor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
public class SQLiteDatabase {
    private final Map<String, List<Map<String, Object>>> tables = new LinkedHashMap<String, List<Map<String, Object>>>();
    private long nextId = 1L;
    public void execSQL(String sql) { }
    public long insert(String table, String nullColumnHack, ContentValues values) {
        List<Map<String, Object>> rows = tables.get(table);
        if (rows == null) { rows = new ArrayList<Map<String, Object>>(); tables.put(table, rows); }
        Map<String, Object> row = new LinkedHashMap<String, Object>(values);
        row.put("id", nextId++);
        rows.add(row);
        return ((Long) row.get("id")).longValue();
    }
    public Cursor query(String table, String[] columns, String selection, String[] selectionArgs,
                        String groupBy, String having, String orderBy, String limit) {
        List<Map<String, Object>> source = tables.get(table);
        List<Map<String, Object>> rows = source == null ? new ArrayList<Map<String, Object>>() : new ArrayList<Map<String, Object>>(source);
        Collections.reverse(rows);
        int count = rows.size();
        try { count = Math.min(count, Integer.parseInt(limit)); } catch (Exception ignored) { }
        final List<Object[]> out = new ArrayList<Object[]>();
        for (int i = 0; i < count; i++) {
            Map<String, Object> row = rows.get(i);
            Object[] values = new Object[columns.length];
            for (int j = 0; j < columns.length; j++) values[j] = row.get(columns[j]);
            out.add(values);
        }
        return new Cursor() {
            int index = -1;
            public boolean moveToNext() { index++; return index < out.size(); }
            public long getLong(int columnIndex) { return ((Number) out.get(index)[columnIndex]).longValue(); }
            public String getString(int columnIndex) { Object v = out.get(index)[columnIndex]; return v == null ? null : String.valueOf(v); }
            public void close() { }
        };
    }
}
