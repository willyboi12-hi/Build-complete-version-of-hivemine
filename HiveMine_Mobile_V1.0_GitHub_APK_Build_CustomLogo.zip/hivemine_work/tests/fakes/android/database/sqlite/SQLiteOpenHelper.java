package android.database.sqlite;
import android.content.Context;
import java.util.HashMap;
import java.util.Map;
public abstract class SQLiteOpenHelper {
    private static final Map<String, SQLiteDatabase> DATABASES = new HashMap<String, SQLiteDatabase>();
    private final String name;
    private final int version;
    private SQLiteDatabase database;
    public SQLiteOpenHelper(Context context, String name, Object factory, int version) { this.name = name; this.version = version; }
    public abstract void onCreate(SQLiteDatabase db);
    public abstract void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion);
    public synchronized SQLiteDatabase getWritableDatabase() {
        if (database == null) {
            database = DATABASES.get(name);
            if (database == null) { database = new SQLiteDatabase(); DATABASES.put(name, database); onCreate(database); }
        }
        return database;
    }
    public SQLiteDatabase getReadableDatabase() { return getWritableDatabase(); }
    public void close() { }
}
