package android.view;
import android.content.Context;
import android.graphics.drawable.Drawable;
import java.util.ArrayList;
import java.util.List;
/** TEST FAKE. Records the view tree so tests can find and press controls. */
public class View {
    public interface OnClickListener { void onClick(View v); }
    public interface OnTouchListener { boolean onTouch(View v, MotionEvent e); }
    private final Context context;
    private OnClickListener clickListener;
    private OnTouchListener touchListener;
    private Object tag;
    private Drawable background;
    private Object layoutParams;
    protected ViewGroup parent;
    private int padL, padT, padR, padB;
    private int minHeight;
    private int visibility = 0;
    public View(Context c) { this.context = c; }
    public Context getContext() { return context; }
    public void setOnClickListener(OnClickListener l) { this.clickListener = l; }
    public OnClickListener getOnClickListener() { return clickListener; }
    public void setOnTouchListener(OnTouchListener l) { this.touchListener = l; }
    public boolean performClick() { if (clickListener != null) { clickListener.onClick(this); return true; } return false; }
    public boolean dispatchTouch(MotionEvent e) { return touchListener != null && touchListener.onTouch(this, e); }
    public void setTag(Object t) { tag = t; }
    public Object getTag() { return tag; }
    public void setBackground(Drawable d) { background = d; }
    public void setBackgroundColor(int c) { background = null; }
    public Drawable getBackground() { return background; }
    public void setLayoutParams(Object lp) { layoutParams = lp; }
    public Object getLayoutParams() { return layoutParams; }
    public void setPadding(int l, int t, int r, int b) { padL = l; padT = t; padR = r; padB = b; }
    public int getPaddingLeft() { return padL; }
    public void setMinimumHeight(int h) { minHeight = h; }
    public void setMinimumWidth(int w) { minWidth = w; }
    public void setMinWidth(int w) { minWidth = w; }
    private int minWidth;
    public int getMinimumHeight() { return minHeight; }
    public void setMinHeight(int h) { minHeight = h; }
    public void setVisibility(int v) { visibility = v; }
    public int getVisibility() { return visibility; }
    public static final int VISIBLE = 0, INVISIBLE = 4, GONE = 8;
    public ViewGroup getParent() { return parent; }
    public void setAlpha(float a) {}
    public void setElevation(float e) {}
    public void invalidate() {}
    public void requestLayout() {}
}
