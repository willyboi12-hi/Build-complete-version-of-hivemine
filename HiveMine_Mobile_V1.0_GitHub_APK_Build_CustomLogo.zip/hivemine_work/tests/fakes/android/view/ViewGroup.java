package android.view;
import android.content.Context;
import java.util.ArrayList;
import java.util.List;
/** TEST FAKE. Keeps children in order. */
public class ViewGroup extends View {
    private final List<View> children = new ArrayList<>();
    public ViewGroup(Context c) { super(c); }
    public void addView(View v) { addView(v, null); }
    public void addView(View v, Object lp) {
        if (lp != null) v.setLayoutParams(lp);
        children.add(v);
        v.parent = this;
    }
    public void removeView(View v) { children.remove(v); v.parent = null; }
    public void removeAllViews() { for (View v : children) v.parent = null; children.clear(); }
    public int getChildCount() { return children.size(); }
    public View getChildAt(int i) { return children.get(i); }
    public List<View> getChildren() { return children; }
    public static class LayoutParams {
        public static final int MATCH_PARENT = -1, WRAP_CONTENT = -2;
        public int width, height;
        public LayoutParams(int w, int h) { width = w; height = h; }
        public int leftMargin, topMargin, rightMargin, bottomMargin;
        public void setMargins(int l, int t, int r, int b) { leftMargin = l; topMargin = t; rightMargin = r; bottomMargin = b; }
    }
}
