package android.view;
public final class Gravity { public static final int START = 8388611, END = 8388613, TOP = 48, BOTTOM = 80, LEFT = 3, RIGHT = 5, CENTER = 17, CENTER_VERTICAL = 16, CENTER_HORIZONTAL = 1; private Gravity() {} }
