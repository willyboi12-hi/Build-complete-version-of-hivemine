package android.view;
import android.graphics.PixelFormat;
import java.util.ArrayList;
import java.util.List;
/** TEST FAKE. Records windows added to the screen. */
public class WindowManager {
    public final List<View> windows = new ArrayList<>();
    public final List<LayoutParams> windowParams = new ArrayList<>();
    public void addView(View v, LayoutParams lp) { windows.add(v); windowParams.add(lp); v.setLayoutParams(lp); }
    public void updateViewLayout(View v, LayoutParams lp) { v.setLayoutParams(lp); }
    public void removeView(View v) { int i = windows.indexOf(v); if (i >= 0) { windows.remove(i); windowParams.remove(i); } }
    public void removeViewImmediate(View v) { removeView(v); }
    public static class LayoutParams extends ViewGroup.LayoutParams {
        public static final int TYPE_PHONE = 2002, TYPE_APPLICATION_OVERLAY = 2038, TYPE_ACCESSIBILITY_OVERLAY = 2032;
        public static final int FLAG_NOT_FOCUSABLE = 8, FLAG_LAYOUT_IN_SCREEN = 256, FLAG_LAYOUT_NO_LIMITS = 512;
        public int type, flags, format, x, y, gravity;
        public LayoutParams(int w, int h, int type, int flags, int format) {
            super(w, h); this.type = type; this.flags = flags; this.format = format;
        }
        public LayoutParams(int w, int h, int type, int flags, int format, int x, int y, int gravity) { this(w, h, type, flags, format); this.x = x; this.y = y; this.gravity = gravity; }
    }
}
