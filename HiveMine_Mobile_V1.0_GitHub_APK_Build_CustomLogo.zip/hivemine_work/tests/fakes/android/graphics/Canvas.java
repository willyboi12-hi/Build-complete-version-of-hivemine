package android.graphics;
public class Canvas { public void drawCircle(float x, float y, float r, Paint p) {} public void drawRect(RectF r, Paint p) {} public void drawRoundRect(RectF r, float rx, float ry, Paint p) {} }
