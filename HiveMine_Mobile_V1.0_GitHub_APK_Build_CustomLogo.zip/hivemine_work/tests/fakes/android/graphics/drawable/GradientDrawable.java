package android.graphics.drawable;
/** TEST FAKE. Keeps color and shape so tests can check them. */
public class GradientDrawable extends Drawable {
    public static final int RECTANGLE = 0, OVAL = 1;
    public int color; public float radius; public int strokeColor; public int strokeWidth; public int shape;
    public GradientDrawable() {}
    public void setColor(int c) { color = c; }
    public void setCornerRadius(float r) { radius = r; }
    public void setStroke(int w, int c) { strokeWidth = w; strokeColor = c; }
    public void setShape(int s) { shape = s; }
}
