package android.graphics;
public class PixelFormat { public static final int TRANSLUCENT = -3, TRANSPARENT = -2, OPAQUE = -1; }
