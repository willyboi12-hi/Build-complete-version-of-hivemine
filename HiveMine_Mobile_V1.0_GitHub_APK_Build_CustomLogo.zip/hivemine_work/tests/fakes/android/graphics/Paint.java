package android.graphics;
public class Paint { public static final int ANTI_ALIAS_FLAG = 1; public Paint() {} public Paint(int f) {} public void setColor(int c) {} public void setStyle(Style s) {} public void setStrokeWidth(float w) {} public enum Style { FILL, STROKE, FILL_AND_STROKE } }
