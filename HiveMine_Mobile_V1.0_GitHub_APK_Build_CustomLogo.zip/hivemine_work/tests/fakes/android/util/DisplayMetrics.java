package android.util;
/** TEST FAKE. */
public class DisplayMetrics {
    public float density = 2.5f;
    public int widthPixels = 1080, heightPixels = 2400, densityDpi = 400;
}
