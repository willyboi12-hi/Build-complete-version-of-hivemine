package android.content;
import java.util.HashMap;
import java.util.Map;
/** TEST FAKE. Typed preferences backed by a map. */
public class SharedPreferences {
    private final Map<String, Object> m;
    SharedPreferences(Map<String, Object> m) { this.m = m; }
    public boolean getBoolean(String k, boolean d) { Object o = m.get(k); return o instanceof Boolean ? (Boolean) o : d; }
    public int getInt(String k, int d) { Object o = m.get(k); return o instanceof Integer ? (Integer) o : d; }
    public float getFloat(String k, float d) { Object o = m.get(k); return o instanceof Float ? (Float) o : d; }
    public long getLong(String k, long d) { Object o = m.get(k); return o instanceof Long ? (Long) o : d; }
    public String getString(String k, String d) { Object o = m.get(k); return o instanceof String ? (String) o : d; }
    public boolean contains(String k) { return m.containsKey(k); }
    public Editor edit() { return new Editor(m); }
    public static final class Editor {
        private final Map<String, Object> target;
        private final Map<String, Object> pending = new HashMap<>();
        private final java.util.Set<String> removed = new java.util.HashSet<>();
        Editor(Map<String, Object> t) { target = t; }
        public Editor putBoolean(String k, boolean v) { pending.put(k, v); return this; }
        public Editor putInt(String k, int v) { pending.put(k, v); return this; }
        public Editor putFloat(String k, float v) { pending.put(k, v); return this; }
        public Editor putLong(String k, long v) { pending.put(k, v); return this; }
        public Editor putString(String k, String v) { pending.put(k, v); return this; }
        public Editor remove(String k) { removed.add(k); return this; }
        public void apply() { for (String k : removed) target.remove(k); target.putAll(pending); }
        public boolean commit() { apply(); return true; }
    }
}
