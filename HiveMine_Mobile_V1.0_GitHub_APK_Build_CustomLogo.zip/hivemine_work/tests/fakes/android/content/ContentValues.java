package android.content;
import java.util.HashMap;
public class ContentValues extends HashMap<String, Object> {
    public void put(String key, String value) { super.put(key, value); }
    public void put(String key, Long value) { super.put(key, value); }
    public void put(String key, Integer value) { super.put(key, value); }
}
