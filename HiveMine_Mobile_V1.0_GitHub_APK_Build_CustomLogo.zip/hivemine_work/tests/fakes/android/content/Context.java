package android.content;
import android.view.WindowManager;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/** TEST FAKE. Preferences, the window service, and launched intents. Not the Android Context. */
public class Context {
    public static final int MODE_PRIVATE = 0;
    public static final String WINDOW_SERVICE = "window";
    private static final Map<String, Map<String, Object>> FILES = new HashMap<>();
    public static final List<Intent> LAUNCHED = new ArrayList<>();
    private final WindowManager windowManager = new WindowManager();
    public Context getApplicationContext() { return this; }
    public Object getSystemService(String name) { return WINDOW_SERVICE.equals(name) ? windowManager : null; }
    public WindowManager getWindowManager() { return windowManager; }
    public String getPackageName() { return "com.hiveminemobile"; }
    private final android.content.res.Resources resources = new android.content.res.Resources();
    public android.content.res.Resources getResources() { return resources; }
    public void startActivity(Intent i) { LAUNCHED.add(i); }
    public SharedPreferences getSharedPreferences(String name, int mode) {
        Map<String, Object> m = FILES.get(name);
        if (m == null) { m = new HashMap<>(); FILES.put(name, m); }
        return new SharedPreferences(m);
    }
    /** Test-only: wipe all saved preferences and launched intents. */
    public static void resetAll() { FILES.clear(); LAUNCHED.clear(); }
}
