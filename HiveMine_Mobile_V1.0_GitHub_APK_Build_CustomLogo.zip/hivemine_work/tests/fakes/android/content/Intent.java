package android.content;
/** TEST FAKE. */
public class Intent {
    public static final String ACTION_VIEW = "android.intent.action.VIEW";
    public static final int FLAG_ACTIVITY_NEW_TASK = 268435456;
    public String action; public Object data; public Class<?> component; public int flags;
    public Intent() {}
    public Intent(String a) { action = a; }
    public Intent(String a, Object d) { action = a; data = d; }
    public Intent(Context c, Class<?> cls) { component = cls; }
    public Intent setFlags(int f) { flags = f; return this; }
    public Intent addFlags(int f) { flags |= f; return this; }
}
