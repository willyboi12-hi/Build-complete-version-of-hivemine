package android.content.res;
import android.util.DisplayMetrics;
/** TEST FAKE. A phone-sized screen at density 2.5. */
public class Resources {
    private final DisplayMetrics metrics = new DisplayMetrics();
    public DisplayMetrics getDisplayMetrics() { return metrics; }
}
