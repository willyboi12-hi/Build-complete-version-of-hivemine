package android.os;
import java.util.ArrayList;
import java.util.List;
/** TEST FAKE. Runs posted work when the test calls runPending(). */
public class Handler {
    private static final List<Runnable> PENDING = new ArrayList<>();
    public Handler() {}
    public Handler(Looper l) {}
    public boolean post(Runnable r) { PENDING.add(r); return true; }
    public boolean postDelayed(Runnable r, long ms) { PENDING.add(r); return true; }
    public void removeCallbacks(Runnable r) { PENDING.remove(r); }
    public void removeCallbacksAndMessages(Object o) { PENDING.clear(); }
    /** Test-only: run everything posted so far. */
    public static void runPending() { List<Runnable> copy = new ArrayList<>(PENDING); PENDING.clear(); for (Runnable r : copy) r.run(); }
}
