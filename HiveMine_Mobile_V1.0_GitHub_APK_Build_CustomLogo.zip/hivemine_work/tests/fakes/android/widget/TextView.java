package android.widget;
import android.content.Context;
import android.graphics.Typeface;
import android.view.View;
/** TEST FAKE. Keeps its text and colors so tests can read them. */
public class TextView extends View {
    private CharSequence text = "";
    private int textColor;
    private float textSize;
    public TextView(Context c) { super(c); }
    public void setText(CharSequence t) { text = t == null ? "" : t; }
    public CharSequence getText() { return text; }
    public void setTextColor(int c) { textColor = c; }
    public int getCurrentTextColor() { return textColor; }
    public void setTextSize(float s) { textSize = s; }
    public void setTextSize(int unit, float s) { textSize = s; }
    public float getTextSize() { return textSize; }
    public void setTypeface(Typeface t) {}
    public void setTypeface(Typeface t, int style) {}
    public void setAllCaps(boolean b) {}
    public void setGravity(int g) {}
    public void setSingleLine(boolean b) {}
    public void setEllipsize(android.text.TextUtils.TruncateAt t) {}
    public void setMaxLines(int n) {}
    public void setLineSpacing(float a, float m) {}
    public void setLetterSpacing(float s) {}
    public void setHint(CharSequence h) {}
    public void setCompoundDrawables(android.graphics.drawable.Drawable a, android.graphics.drawable.Drawable b, android.graphics.drawable.Drawable c, android.graphics.drawable.Drawable d) {}
    public void setOnClickListener(View.OnClickListener l) { super.setOnClickListener(l); }
}
