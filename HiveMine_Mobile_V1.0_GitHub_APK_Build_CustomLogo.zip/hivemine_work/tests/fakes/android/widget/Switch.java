package android.widget;
import android.content.Context;
public class Switch extends CompoundButton {
    public Switch(Context c) { super(c); }
}
