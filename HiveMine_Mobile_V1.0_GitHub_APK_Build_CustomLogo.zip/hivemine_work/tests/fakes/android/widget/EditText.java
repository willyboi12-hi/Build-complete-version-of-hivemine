package android.widget;
import android.content.Context;
/** TEST FAKE. Basic editable text surface used by the AI command UI. */
public class EditText extends TextView {
    public EditText(Context c) { super(c); }
    public void setMinLines(int n) {}
    public void setHintTextColor(int c) {}
    public void setBackgroundColor(int c) {}
}
