package android.widget;
import android.content.Context;
import android.view.View;
public class CompoundButton extends Button {
    public interface OnCheckedChangeListener { void onCheckedChanged(CompoundButton b, boolean checked); }
    private boolean checked; private OnCheckedChangeListener listener;
    public CompoundButton(Context c) { super(c); }
    public boolean isChecked() { return checked; }
    public void setChecked(boolean c) { checked = c; if (listener != null) listener.onCheckedChanged(this, c); }
    public void setOnCheckedChangeListener(OnCheckedChangeListener l) { listener = l; }
}
