package android.widget;
import android.content.Context;
import android.view.ViewGroup;
public class FrameLayout extends ViewGroup {
    public FrameLayout(Context c) { super(c); }
    public static class LayoutParams extends ViewGroup.LayoutParams {
        public static final int MATCH_PARENT = -1, WRAP_CONTENT = -2;
        public int gravity;
        public LayoutParams(int w, int h) { super(w, h); }
        public LayoutParams(int w, int h, int g) { super(w, h); gravity = g; }
    }
}
