package android.widget;
import android.content.Context;
import android.view.View;
public class SeekBar extends View {
    public interface OnSeekBarChangeListener { void onProgressChanged(SeekBar s, int p, boolean user); void onStartTrackingTouch(SeekBar s); void onStopTrackingTouch(SeekBar s); }
    private int max = 100, progress; private OnSeekBarChangeListener listener;
    public SeekBar(Context c) { super(c); }
    public void setMax(int m) { max = m; }
    public int getMax() { return max; }
    public void setProgress(int p) { progress = p; if (listener != null) listener.onProgressChanged(this, p, false); }
    public int getProgress() { return progress; }
    public void setOnSeekBarChangeListener(OnSeekBarChangeListener l) { listener = l; }
}
