package android.widget;
import android.content.Context;
import android.view.ViewGroup;
public class HorizontalScrollView extends FrameLayout {
    public HorizontalScrollView(Context c) { super(c); }
    public void setHorizontalScrollBarEnabled(boolean b) {}
}
