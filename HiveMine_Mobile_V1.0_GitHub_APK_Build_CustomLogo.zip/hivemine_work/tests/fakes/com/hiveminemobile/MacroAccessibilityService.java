package com.hiveminemobile;
/**
 * TEST FAKE of the macro service. It mirrors the public members the AI bridge and the overlay use.
 * AiBridgeChecks verifies that the REAL service still declares these members (contract check).
 */
public class MacroAccessibilityService {
    public static volatile MacroAccessibilityService instance;
    public static volatile String status = "Ready.";
    public static volatile String bagLine = "Bag: 0%";
    private boolean running;
    private boolean paused;
    public int bagPercent = -1;
    public String sceneName = "UNKNOWN";
    public long observationAtMillis;
    public int startCalls, stopCalls, rejoinCalls, delayedCalls;
    public boolean isRunning() { return running && !paused; }
    public boolean isPaused() { return paused; }
    public boolean pauseMacro() { if (!running || paused) return false; paused = true; running = false; return true; }
    public boolean resumeMacro() { if (!paused) return false; paused = false; running = true; return true; }
    public long getRecoveryGeneration() { return 0L; }
    public boolean isRecoveryInProgress() { return false; }
    public int getBagPercent() { return bagPercent; }
    public String getSceneName() { return sceneName; }
    public long getLastObservationAtMillis() { return observationAtMillis; }
    public void startMacro() { startCalls++; paused = false; running = true; }
    public void startDelayed(long ms) { delayedCalls++; running = true; }
    public void stopMacro() { stopCalls++; paused = false; running = false; }
    public void runSavedTapsNow(String kind, long delayMs) {}
    public void rejoinNow() { rejoinCalls++; }
    /** Test-only: simulate the macro starting or stopping on its own. */
    public void setRunning(boolean r) { paused = false; running = r; }
}
