package com.hiveminemobile;
/** TEST FAKE. The overlay only needs the class to launch it. The real activity is checked by contract. */
public class MainActivity {
}
