package com.hiveminemobile;

import java.util.List;

/**
 * NEW test suite written from scratch for the combined repo (not the original tests/unit suite, which
 * was missing from the source archive). Covers only public behavior of the Android-free engine classes
 * that compile against tests/fakes.
 */
public final class RunTests {
    private static int passed = 0, failed = 0;

    static void check(boolean ok, String name) {
        if (ok) { passed++; } else { failed++; System.out.println("FAIL  " + name); }
    }

    public static void main(String[] args) {
        taskCoordinator();
        robloxLink();
        calibration();
        bagReader();
        patterns();
        fieldRoutes();
        System.out.println(passed + " passed, " + failed + " failed");
        if (failed > 0) System.exit(1);
    }

    static void taskCoordinator() {
        AutomationTaskCoordinator c = new AutomationTaskCoordinator();
        AutomationTaskCoordinator.Pending none = new AutomationTaskCoordinator.Pending();
        check(c.choose(null) == AutomationTaskCoordinator.Task.NONE, "coordinator: null pending -> NONE");
        check(c.choose(none) == AutomationTaskCoordinator.Task.NONE, "coordinator: empty pending -> NONE");

        AutomationTaskCoordinator.Pending p = new AutomationTaskCoordinator.Pending();
        p.farming = true; p.quest = true;
        check(c.choose(p) == AutomationTaskCoordinator.Task.QUEST, "coordinator: quest outranks farming");

        p.userInterruption = true;
        check(c.choose(p) == AutomationTaskCoordinator.Task.USER_INTERRUPTION, "coordinator: user interruption outranks all");

        c.emergencyStop();
        check(c.choose(p) == AutomationTaskCoordinator.Task.EMERGENCY_STOP, "coordinator: emergency latch overrides everything");
        check(!c.mayStart(AutomationTaskCoordinator.Task.FARMING, p), "coordinator: nothing may start while latched");
        c.resetEmergencyStop();
        check(!c.isEmergencyLatched(), "coordinator: reset clears latch");
        check(c.mayStart(AutomationTaskCoordinator.Task.USER_INTERRUPTION, p), "coordinator: highest pending task may start");
        check(!c.mayStart(AutomationTaskCoordinator.Task.FARMING, p), "coordinator: lower task may not start");
    }

    static void robloxLink() {
        check(RobloxLink.toRobloxUri("https://www.roblox.com/games/1537690962/Bee-Swarm?privateServerLinkCode=ABC123")
                .equals("roblox://placeID=1537690962&linkCode=ABC123"), "link: game + private code -> roblox://");
        check(RobloxLink.toRobloxUri("roblox://placeID=1&linkCode=x").equals("roblox://placeID=1&linkCode=x"),
                "link: roblox:// kept as-is");
        check(RobloxLink.toRobloxUri("https://www.roblox.com/games/1537690962").startsWith("https://"),
                "link: game link without code unchanged");
        check(RobloxLink.toRobloxUri(null).isEmpty(), "link: null -> empty string");
    }

    static void calibration() {
        for (double observed : new double[]{0.5, 5, 10, 20, 100}) {
            float s = Calibration.speedFor(30f, Calibration.EXPECTED_TILES, observed);
            check(s >= Calibration.MIN_SPEED && s <= Calibration.MAX_SPEED,
                    "calibration: speed clamped for observed=" + observed);
        }
    }

    static void bagReader() {
        int[] samples = {0x000000, 0x808080, 0xFFFFFF, 0x3A7BD5, 0xE0A020};
        for (int rgb : samples) {
            int p = BagReader.percentFromColor(rgb);
            check(p >= 0 && p <= 100, "bag: percent in 0..100 for 0x" + Integer.toHexString(rgb));
        }
        BagReader.Filter f = new BagReader.Filter(3);
        f.add(50); f.add(50);
        check(f.add(50) == 50, "bag: filter of identical samples returns that value");
        f.clear();
        check(f.add(80) == 80, "bag: filter after clear starts fresh");
    }

    static void patterns() {
        for (String name : Patterns.NAMES) {
            for (String size : Patterns.SIZES) {
                List<Patterns.Seg> segs = Patterns.build(name, size, 1, false, false, false);
                check(segs != null && !segs.isEmpty(), "pattern: " + name + " " + size + " non-empty");
                if (segs == null) continue;
                for (Patterns.Seg s : segs) {
                    check(s.durationMs(30) >= 0, "pattern: " + name + " " + size + " durations non-negative");
                }
            }
        }
    }

    static void fieldRoutes() {
        for (String name : FieldRoutes.NAMES) {
            List<Patterns.Seg> route = FieldRoutes.plan(name);
            check(route != null && !route.isEmpty(), "field route: " + name + " has steps");
        }
    }
}
