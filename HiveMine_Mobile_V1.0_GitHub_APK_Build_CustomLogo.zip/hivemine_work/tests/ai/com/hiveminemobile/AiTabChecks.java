package com.hiveminemobile;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import com.hiveminemobile.overlay.OverlayDashboardView;
import com.hiveminemobile.overlay.OverlayMacroController;
import com.hiveminemobile.overlay.OverlaySettings;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * Builds the REAL floating dashboard (OverlayDashboardView) against the test fakes, opens its AI tab,
 * presses the real buttons, and checks the text on screen and what the macro service receives.
 * Drawing and real touch are NOT tested here; that needs a device.
 */
public final class AiTabChecks {
    private static int passed = 0, failed = 0;
    static void check(boolean ok, String name) {
        if (ok) passed++; else { failed++; System.out.println("FAIL  " + name); }
    }

    static void walk(View v, List<View> out) {
        out.add(v);
        if (v instanceof ViewGroup) for (View c : ((ViewGroup) v).getChildren()) walk(c, out);
    }
    static List<View> all(View root) { List<View> l = new ArrayList<>(); walk(root, l); return l; }

    static Button button(View root, String text) {
        for (View v : all(root)) if (v instanceof Button && text.equals(((TextView) v).getText().toString())) return (Button) v;
        return null;
    }
    static boolean screenHas(View root, String fragment) {
        for (View v : all(root)) if (v instanceof TextView && ((TextView) v).getText().toString().contains(fragment)) return true;
        return false;
    }
    static void press(View root, String text) {
        Button b = button(root, text);
        if (b == null) throw new AssertionError("no button: " + text);
        b.performClick();
    }
    static void showTab(OverlayDashboardView d, int idx) throws Exception {
        Method m = OverlayDashboardView.class.getDeclaredMethod("showTab", int.class);
        m.setAccessible(true);
        m.invoke(d, idx);
    }

    public static void main(String[] args) throws Exception {
        Context.resetAll();
        AiControlHub.resetForTesting();
        MacroAccessibilityService svc = new MacroAccessibilityService();
        MacroAccessibilityService.instance = svc;

        com.hiveminemobile.Ui ui = new com.hiveminemobile.Ui(new Context());
        OverlayDashboardView d = new OverlayDashboardView(new Context(), ui, new OverlaySettings(new Context()), new OverlayMacroController());

        for (int i = 0; i <= 4; i++) {
            try { showTab(d, i); check(true, "existing tab " + i + " builds"); }
            catch (Exception e) { check(false, "existing tab " + i + " builds: " + e); }
        }
        check(button(d, "AI") != null, "AI tab button exists in the tab row");

        showTab(d, 5);
        check(screenHas(d, "AI control: OFF"), "AI tab shows AI control OFF by default");
        check(button(d, "Turn AI control ON") != null, "AI tab offers the Turn ON button");

        press(d, "Start");
        check(svc.startCalls == 0, "Start while OFF: macro NOT started");
        check(screenHas(d, "AI control is OFF. Turn it on first."), "Start while OFF: plain-words reason shown");

        press(d, "Turn AI control ON");
        check(AiControlHub.isEnabled(new Context()), "Turn ON: switch saved");
        check(screenHas(d, "AI control: ON"), "Turn ON: screen shows AI control ON");

        press(d, "Start");
        check(svc.startCalls == 1 && svc.isRunning(), "Start while ON: macro started once");
        check(screenHas(d, "Start sent."), "Start while ON: result shown");

        press(d, "Recover");
        check(svc.rejoinCalls == 1, "Recover while ON: rejoin sent");

        press(d, "Turn AI control OFF");
        check(!AiControlHub.isEnabled(new Context()), "Turn OFF: switch saved");
        press(d, "Stop");
        check(svc.stopCalls == 1 && !svc.isRunning(), "Stop while OFF: still stops the macro (emergency path)");
        check(screenHas(d, "Stop sent."), "Stop while OFF: result shown");

        check(screenHas(d, "STOP_REQUESTED for stop"), "decision log lists the Stop request");

        System.out.println(passed + " passed, " + failed + " failed");
        if (failed > 0) System.exit(1);
    }
}
