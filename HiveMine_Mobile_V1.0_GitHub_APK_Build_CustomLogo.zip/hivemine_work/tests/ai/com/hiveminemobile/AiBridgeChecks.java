package com.hiveminemobile;

import android.content.Context;
import com.hiveminemobile.ai.control.AutomationController;
import com.hiveminemobile.ai.control.AutomationController.Decision;
import com.hiveminemobile.ai.control.MacroStatus;
import com.hiveminemobile.ai.control.MacroPort;
import com.hiveminemobile.ai.control.ObservationFreshness;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * Tests the AI tab's logic end to end: the real AiControlHub, AiMacroPort, AutomationController, and
 * AiStatusMessages, with a fake Context and a fake macro service (tests/fakes). This does NOT test
 * drawing or touch on the overlay. That needs a device or Robolectric.
 */
public final class AiBridgeChecks {
    private static int passed = 0, failed = 0;

    static void check(boolean ok, String name) {
        if (ok) passed++; else { failed++; System.out.println("FAIL  " + name); }
    }

    static void reset() {
        Context.resetAll();
        AiControlHub.resetForTesting();
        MacroAccessibilityService.instance = null;
    }

    static MacroAccessibilityService bindService() {
        MacroAccessibilityService s = new MacroAccessibilityService();
        MacroAccessibilityService.instance = s;
        return s;
    }

    public static void main(String[] args) throws Exception {
        Context c = new Context();

        reset();
        check(!AiControlHub.isEnabled(c), "default: AI control is OFF");
        check(!AiControlHub.controller(c).isAiControlEnabled(), "default: controller starts OFF");
        check(AiControlHub.controller(c).requestStart() == Decision.REFUSED_NOT_ENABLED,
              "off: start refused (not enabled)");
        MacroAccessibilityService svc = bindService();
        check(AiControlHub.controller(c).requestStart() == Decision.REFUSED_NOT_ENABLED && svc.startCalls == 0,
              "off, service bound: start refused and macro NOT started");
        check(AiControlHub.controller(c).requestRecover() == Decision.REFUSED_NOT_ENABLED && svc.rejoinCalls == 0,
              "off, service bound: recover refused and NOT sent");

        reset();
        AiControlHub.setEnabled(c, true);
        check(AiControlHub.isEnabled(c) && AiControlHub.controller(c).isAiControlEnabled(),
              "enable: switch saved and controller follows");
        check(AiControlHub.controller(c).requestStart() == Decision.REFUSED_NOT_CONNECTED,
              "on, no service: start refused (not connected)");
        svc = bindService();
        check(AiControlHub.controller(c).requestRecover() == Decision.REFUSED_NOT_RUNNING && svc.rejoinCalls == 0,
              "on, connected but idle: recover is refused because there is no active run to rejoin");

        reset();
        AiControlHub.setEnabled(c, true);
        svc = bindService();
        check(AiControlHub.controller(c).requestStart() == Decision.START_REQUESTED && svc.startCalls == 1,
              "on, bound, idle: start requested and macro started once");
        check(AiControlHub.controller(c).requestStart() == Decision.REFUSED_ALREADY_RUNNING && svc.startCalls == 1,
              "on, already running: second start refused, no extra start");
        check(AiControlHub.controller(c).requestRecover() == Decision.RECOVER_REQUESTED && svc.rejoinCalls == 1,
              "on, bound: recover sends one rejoin");
        check(AiControlHub.controller(c).requestStop() == Decision.STOP_REQUESTED && svc.stopCalls == 1 && !svc.isRunning(),
              "on, running: stop requested and macro stopped");

        reset();
        AiControlHub.setEnabled(c, true);
        svc = bindService();
        AiControlHub.controller(c).requestStart();
        AiControlHub.setEnabled(c, false);
        check(AiControlHub.controller(c).requestStop() == Decision.STOP_REQUESTED && svc.stopCalls == 1,
              "switched OFF while running: STOP still forwarded (emergency path)");
        check(!svc.isRunning(), "switched OFF while running: macro actually stopped");

        reset();
        check(AiControlHub.controller(c).requestStop() == Decision.REFUSED_NOT_CONNECTED,
              "stop with no service bound: reported, no crash");

        reset();
        AiControlHub.setEnabled(c, true);
        AiControlHub.controller(c);
        AiControlHub.resetForTesting();
        check(AiControlHub.controller(c).isAiControlEnabled(),
              "restart: switch survives an app restart (read back from preferences)");

        reset();
        AiMacroPort port = new AiMacroPort();
        check(!port.readStatus().isConnected(), "port: unbound reports disconnected");
        svc = bindService();
        svc.setRunning(true);
        MacroStatus st = port.readStatus();
        check(st.isConnected() && st.isRunning(), "port: bound and running reports connected + running");

        reset();
        AiControlHub.setEnabled(c, true);
        bindService();
        AiControlHub.controller(c).requestStop();
        java.util.List<String> trail = AiControlHub.controller(c).getAuditTrail();
        check(!trail.isEmpty() && trail.get(trail.size() - 1).contains("STOP"), "audit: decisions are recorded");

        reset();
        final int[] svcStopCounter = new int[]{0};
        final MacroPort throwingStatusPort = new MacroPort() {
            public void start() {}
            public void stop() { svcStopCounter[0]++; }
            public void recover() {}
            public MacroStatus readStatus() { throw new RuntimeException("status unavailable"); }
        };
        AutomationController emergency = new AutomationController(throwingStatusPort);
        check(emergency.requestStop() == Decision.STOP_REQUESTED && svcStopCounter[0] == 1,
              "emergency stop: status failure cannot block stop dispatch");
        AutomationController failedStop = new AutomationController(new MacroPort() {
            public void start() {}
            public void stop() { throw new RuntimeException("dispatch failed"); }
            public void recover() {}
            public MacroStatus readStatus() { throw new RuntimeException("status unavailable"); }
        });
        check(failedStop.requestStop() == Decision.STOP_DISPATCH_FAILED,
              "emergency stop: failed dispatch is not falsely reported as sent");

        check(!ObservationFreshness.isStale(0L, 1000L, 15000L, 15000L),
              "screenshot watchdog: exact grace window is not stale");
        check(ObservationFreshness.isStale(0L, 1000L, 16001L, 15000L),
              "screenshot watchdog: detects a pipeline that never delivered its first frame");
        check(ObservationFreshness.isStale(5000L, 1000L, 20001L, 15000L),
              "screenshot watchdog: detects a previously live pipeline that stopped responding");
        check(!ObservationFreshness.isStale(5000L, 1000L, 10000L, 15000L),
              "screenshot watchdog: fresh observation remains safe");

        for (Decision d : Decision.values()) {
            String m = AiStatusMessages.forDecision(d);
            check(m != null && !m.trim().isEmpty(), "message: " + d + " has text");
        }
        check(AiStatusMessages.forDecision(Decision.REFUSED_NOT_ENABLED).contains("AI control is OFF"),
              "message: refused-not-enabled says AI control is OFF");

        String src = new String(Files.readAllBytes(Paths.get("app/src/main/java/com/hiveminemobile/MacroAccessibilityService.java")),
                                StandardCharsets.UTF_8);
        check(src.contains("public static volatile MacroAccessibilityService instance;"), "contract: real service has instance");
        check(src.contains("public static volatile String status"), "contract: real service has status");
        check(src.contains("public boolean isRunning()"), "contract: real service has isRunning()");
        check(src.contains("public void startMacro()"), "contract: real service has startMacro()");
        check(src.contains("public void stopMacro()"), "contract: real service has stopMacro()");
        check(src.contains("public void rejoinNow()"), "contract: real service has rejoinNow()");

        System.out.println(passed + " passed, " + failed + " failed");
        if (failed > 0) System.exit(1);
    }
}
