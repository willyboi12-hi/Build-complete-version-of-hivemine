package com.hiveminemobile;

import com.hiveminemobile.ai.android.AndroidIntegrationManager;
import com.hiveminemobile.ai.android.AndroidMacroCommunicationBridge;
import com.hiveminemobile.ai.control.MacroStatus;
import java.util.Arrays;

/** Phases 085 and 089 wired into the app, tested with fakes (AiMacroPort, real AiControlHub). */
public final class AndroidWiringChecks {
    private static int passed = 0, failed = 0;

    static void check(boolean ok, String name) {
        if (ok) passed++; else { failed++; System.out.println("FAIL  " + name); }
    }

    public static void main(String[] args) {
        AiBridgeChecks.reset();
        AndroidIntegrationManager unbound = AiControlHub.integration(new android.content.Context() {});
        check(!unbound.canInitialize(), "wiring 085: unbound service means integration cannot initialize");
        check(unbound.missing().containsAll(Arrays.asList("macro-port", "accessibility-service")),
            "wiring 085: unbound service is reported as missing");
        check(unbound.missing().size() == 2, "wiring 085: configuration storage is available with prefs");
        check(AiStatusMessages.readiness(unbound.missing()).contains("not ready"), "wiring 085: readiness message says not ready");

        AndroidMacroCommunicationBridge b = AiControlHub.bridge(new android.content.Context() {});
        AndroidMacroCommunicationBridge.Request r0 = b.send(AndroidMacroCommunicationBridge.Command.START, 0);
        check(r0.status() == AndroidMacroCommunicationBridge.Status.REJECTED, "wiring 089: unbound service rejects START");

        MacroAccessibilityService svc = AiBridgeChecks.bindService();
        AiControlHub.setEnabled(new android.content.Context() {}, true);
        AndroidIntegrationManager bound = AiControlHub.integration(new android.content.Context() {});
        check(bound.canInitialize(), "wiring 085: bound service makes integration ready");
        check(AiStatusMessages.readiness(bound.missing()).contains("ready."), "wiring 085: readiness message says ready");

        AndroidMacroCommunicationBridge.Request r1 = b.send(AndroidMacroCommunicationBridge.Command.START, 1);
        check(r1 != null && r1.status() == AndroidMacroCommunicationBridge.Status.ACCEPTED, "wiring 089: bound START is accepted");
        check(svc.startCalls == 1, "wiring 089: accepted START reaches the real macro service once");
        check(b.send(AndroidMacroCommunicationBridge.Command.START, 2) == null, "wiring 089: duplicate START is prevented");
        svc.setRunning(true);
        b.observe(new AiMacroPort().readStatus(), 3);
        check(r1.status() == AndroidMacroCommunicationBridge.Status.COMPLETED, "wiring 089: START completes when the macro confirms running");
        check(new AiMacroPort().readStatus().isConnected(), "wiring 089: port reports connected once bound");

        // The Android runtime ticker must feed real macro status into the bridge and UI state.
        svc.bagPercent = 65;
        svc.sceneName = "ON_FIELD";
        svc.observationAtMillis = 1234L;
        AiControlHub.managerState(new android.content.Context() {});
        AiControlHub.refreshRuntime(new android.content.Context() {}, 4);
        check(AiControlHub.managerState(new android.content.Context() {}).macroStatus.isRunning(),
            "runtime: ScreenState follows authoritative macro running state");
        check(AiControlHub.managerState(new android.content.Context() {}).bagPercent == 65,
            "runtime: screenshot-derived bag telemetry reaches AI state");
        check("ON_FIELD".equals(AiControlHub.managerState(new android.content.Context() {}).scene),
            "runtime: screenshot-derived scene telemetry reaches AI state");

        // User text now dispatches through the same bridge, then the runtime tick confirms completion.
        AiControlHub.resetForTesting();
        android.content.Context app = new android.content.Context() {};
        AiControlHub.setEnabled(app, true);
        svc = AiBridgeChecks.bindService();
        com.hiveminemobile.ai.ui.chat.AiManagerService manager = AiControlHub.manager(app);
        com.hiveminemobile.ai.ui.screens.ScreenState state = AiControlHub.managerState(app);
        String startResult = manager.handle("start farming", state, true, true);
        check(startResult.contains("request R") && svc.startCalls == 1,
            "manager: AI start command is dispatched through bridge");
        svc.setRunning(true);
        AiControlHub.refreshRuntime(app, System.currentTimeMillis() + 1);
        check(AiControlHub.bridge(app).requests().get(0).status()
                == AndroidMacroCommunicationBridge.Status.COMPLETED,
            "runtime: AI start request completes only after live status confirms running");
        String stopResult = manager.handle("stop", state, true, true);
        check(stopResult.contains("request R") && svc.stopCalls == 1,
            "manager: AI stop command is dispatched through bridge");
        AiControlHub.refreshRuntime(app, System.currentTimeMillis() + 2);
        check(AiControlHub.bridge(app).requests().get(1).status()
                == AndroidMacroCommunicationBridge.Status.COMPLETED,
            "runtime: STOP completes after live status confirms stopped");

        // Config.save now commits a single preference transaction and returns success.
        Config cfg = new Config(app);
        cfg.field = "Sunflower";
        check(cfg.save() && "Sunflower".equals(new Config(app).field),
            "configuration: full settings transaction commits and reads back");
        HiveMineAiMemoryDb memory = new HiveMineAiMemoryDb(app);
        check(memory.append("TEST", "SQLite event round trip", 55L), "memory: operational event persisted to SQLite");
        check(!memory.recent(10).isEmpty()
                && "SQLite event round trip".equals(memory.recent(10).get(0).detail),
            "memory: recent persisted event can be restored");
        AiControlHub.resetForTesting();
        AiControlHub.manager(app);
        check(!AiControlHub.managerState(app).activityLog.isEmpty(),
            "memory: Manager restores persistent operational history after hub recreation");

        System.out.println("AndroidWiringChecks: " + passed + " passed, " + failed + " failed");
        if (failed > 0) System.exit(1);
    }
}
