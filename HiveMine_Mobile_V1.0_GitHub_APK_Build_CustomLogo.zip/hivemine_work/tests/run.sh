#!/usr/bin/env bash
# Runs the JVM suite in tests/unit against the engine classes in app/src/main/java.
# Needs only a JDK, no Android SDK, no network. The Android classes are replaced by the
# stand-ins in tests/fakes, which cover only the engine classes this suite uses.
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="build/tests"
rm -rf "$OUT"
mkdir -p "$OUT"
javac -encoding UTF-8 -nowarn -d "$OUT" -sourcepath app/src/main/java:tests/fakes tests/unit/com/hiveminemobile/RunTests.java
java -cp "$OUT" com.hiveminemobile.RunTests
