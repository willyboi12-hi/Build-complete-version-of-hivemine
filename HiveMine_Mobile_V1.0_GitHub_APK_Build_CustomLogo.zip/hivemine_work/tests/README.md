# Engine tests (JVM)

The JVM suite in `tests/unit/com/hiveminemobile/RunTests.java` checks the Android-free engine classes
with no phone and no Android SDK. It needs only a JDK.

Run it with `bash tests/run.sh`. CI runs it before every APK build.

## How it works
- `tests/fakes/` holds small stand-ins for Android classes and for the macro service and main activity. They are test-only, not the real `android.jar`. `tests/run-ai.sh` tests the AI features with the same fakes (see `hivemine-ai/` and `MERGE_NOTES.md`).
- The suite compiles only the classes it uses from `app/src/main/java` (through `-sourcepath`).

## What is covered
- `AutomationTaskCoordinator`: task priority, user interruption, emergency-stop latch, and start rules.
- `RobloxLink`: game links with private server codes become `roblox://` links; other input is unchanged.
- `Calibration`: walk-speed results stay within the allowed range.
- `BagReader`: percent values stay in 0..100; the smoothing filter averages and resets.
- `Patterns`: every pattern and size builds a non-empty route with non-negative durations.
- `FieldRoutes`: every field has a route.

## What is NOT covered
- Android gestures, overlays, screenshots, accessibility, and permissions. Only a phone can confirm these.
- Real Roblox screen colors and the UI screens.
- Classes that need Android APIs (`MacroAccessibilityService`, `MainActivity`, `Ui`, and the overlay views).
