package com.hiveminemobile;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String[][] PATTERN_INFO = {
        {"Snake", "Zig-zag rows across the field. A good all-round choice."},
        {"Lines", "Straight back-and-forth rows."},
        {"Squares", "Nested squares around one spot."},
        {"Diamonds", "Nested diamonds around one spot."},
        {"Slimline", "A narrow path."},
        {"XSnake", "A longer crisscross path."},
        {"Fork", "A forked path. Best when facing a field corner (Advanced)."},
        {"Auryn", "Looping circles and flips, growing with each repeat."},
        {"CornerXSnake", "A snake path that suits field corners."},
        {"SuperCat", "Diagonal sweeps to each side."},
        {"e_lol", "Long rows with diagonal steps."},
        {"Stationary", "Stands still. Useful for testing."}
    };
    private static final String[] SIZE_LABELS = {"Tiny", "Small", "Medium", "Large", "Huge"};

    private Ui ui;
    private Config cfg;
    private ScrollView scroll;
    private LinearLayout page;
    private boolean onAdvanced;

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        if (getActionBar() != null) getActionBar().hide();
        getWindow().setStatusBarColor(Ui.BG);
        ui = new Ui(this);
        scroll = new ScrollView(this);
        scroll.setBackgroundColor(Ui.BG);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(ui.dp(18), ui.dp(26), ui.dp(18), ui.dp(34));
        scroll.addView(page);
        setContentView(scroll);
    }

    @Override protected void onResume() {
        super.onResume();
        show(onAdvanced, true);
    }

    private MacroAccessibilityService svc() { return MacroAccessibilityService.instance; }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    private void show(boolean advanced, boolean keepScroll) {
        onAdvanced = advanced;
        cfg = new Config(this);
        final int y = keepScroll ? scroll.getScrollY() : 0;
        page.removeAllViews();
        if (advanced) buildAdvanced(); else buildHome();
        scroll.post(new Runnable() { @Override public void run() { scroll.scrollTo(0, y); } });
    }

    // ------------------------------------------------------------ actions

    private void onGo(boolean running) {
        MacroAccessibilityService s = svc();
        if (running) {
            if (s != null) s.stopMacro();
            show(false, true);
            return;
        }
        if (s == null) { toast("Turn on the accessibility service first (Setup, step 1)."); return; }
        // Phase 6: non-fixed start delay so launches are not perfectly periodic
        long startMs = 2200 + (long) (Math.random() * 2000);
        s.startDelayed(startMs);
        moveTaskToBack(true);
    }

    /** Sends the user to Roblox to tap one spot; the tap is captured by an overlay. */
    private void guide(String instruction, String label) {
        MacroAccessibilityService s = svc();
        if (s == null) { toast("Turn on the accessibility service first (Setup, step 1)."); return; }
        s.guidePoint(instruction, label);
        moveTaskToBack(true);
    }

    private void showBubble() {
        MacroAccessibilityService s = svc();
        if (s == null) { toast("Turn on the accessibility service first (Setup, step 1)."); return; }
        s.showBubble();
        show(onAdvanced, true);
    }

    private void hideBubble() {
        MacroAccessibilityService s = svc();
        if (s != null) s.hideBubble();
        show(onAdvanced, true);
    }

    private void testJoystick() {
        MacroAccessibilityService s = svc();
        if (s == null) { toast("Turn on the accessibility service first (Setup, step 1)."); return; }
        if (cfg.joyX <= 0 || cfg.joyY <= 0) { toast("Set the joystick spot first (Setup, step 2)."); return; }
        s.testMove(4000);
        moveTaskToBack(true);
    }

    private void pickField() {
        new android.app.AlertDialog.Builder(this)
            .setTitle("Pick your field")
            .setItems(FieldRoutes.NAMES, (d, which) -> {
                String name = FieldRoutes.NAMES[which];
                FieldPresets.apply(cfg, name);
                FieldPresets.Preset p = FieldPresets.forField(name);
                toast(name + ": " + p.pattern + " " + p.size + " - " + p.note);
                show(false, true);
            })
            .show();
    }

    private void testItemTaps() {
        MacroAccessibilityService s = svc();
        if (s == null) { toast("Turn on the accessibility service first (Setup, step 1)."); return; }
        if (cfg.itemTaps().isEmpty()) { toast("Add the item taps first (Setup, step 7)."); return; }
        s.testItem(4000);
        moveTaskToBack(true);
    }

    private void pickTrip(final int i) {
        new android.app.AlertDialog.Builder(this)
            .setTitle("Pick a trip route")
            .setItems(TripRoutes.NAMES, (d, which) -> {
                cfg.tripRoute[i] = TripRoutes.NAMES[which];
                cfg.save();
                show(true, true);
            })
            .show();
    }

    private void testTripNow(int i) {
        MacroAccessibilityService s = svc();
        if (s == null) { toast("Turn on the accessibility service first (Setup, step 1)."); return; }
        if (cfg.tripRoute[i].isEmpty()) { toast("Pick a route first."); return; }
        s.testTrip(i, 4000);
        moveTaskToBack(true);
    }

    private void walkCheckNow() {
        MacroAccessibilityService s = svc();
        if (s == null) { toast("Turn on the accessibility service first (Setup, step 1)."); return; }
        if (cfg.joyX <= 0 || cfg.joyY <= 0) { toast("Set the joystick spot first (Setup, step 2)."); return; }
        s.walkCheck(4000);
        moveTaskToBack(true);
    }

    private void applyWalkCheck(String text) {
        double observed;
        try {
            observed = Double.parseDouble(text.trim());
        } catch (NumberFormatException e) {
            toast("Enter how many tiles it walked, for example 8.5.");
            return;
        }
        if (observed <= 0) { toast("Enter a distance above zero."); return; }
        float old = cfg.moveSpeed;
        cfg.moveSpeed = Calibration.speedFor(old, Calibration.EXPECTED_TILES, observed);
        cfg.save();
        toast("Walk speed set to " + Math.round(cfg.moveSpeed) + " studs/s (was " + Math.round(old) + ").");
        show(true, true);
    }

    private static String linkMessage(String link) {
        if (link.length() == 0) return "Link cleared.";
        if (RobloxLink.toRobloxUri(link).startsWith("roblox://")) return "Link saved.";
        return "Link saved. It is not a game link with a privateServerLinkCode, so Roblox may not open it directly.";
    }

    private void checkSpotNow() {
        MacroAccessibilityService s = svc();
        if (s == null) { toast("Turn on the accessibility service first (Setup, step 1)."); return; }
        s.checkDisconnectSpot(3000);
        moveTaskToBack(true);
    }

    private void checkPictureNow() {
        MacroAccessibilityService s = svc();
        if (s == null) { toast("Turn on the accessibility service first (Setup, step 1)."); return; }
        s.checkConvertPicture(3000);
        moveTaskToBack(true);
    }

    private void testRejoinNow() {
        MacroAccessibilityService s = svc();
        if (s == null) { toast("Turn on the accessibility service first (Setup, step 1)."); return; }
        s.rejoinNow();
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    private static int indexOf(String[] arr, String s) {
        for (int i = 0; i < arr.length; i++) if (arr[i].equals(s)) return i;
        return 2;
    }

    // ------------------------------------------------------------ home screen

    private void buildHome() {
        MacroAccessibilityService s = svc();
        boolean connected = s != null;
        boolean running = connected && s.isRunning();
        boolean joyOk = cfg.joyX > 0 && cfg.joyY > 0;
        boolean bagOk = cfg.bagX > 0 && cfg.bagY > 0;
        boolean convOk = cfg.convX > 0 && cfg.convY > 0;
        boolean camOk = cfg.camX > 0 && cfg.camY > 0;
        boolean dcOk = cfg.dcX > 0 && cfg.dcY > 0;
        int steps = cfg.resetTaps().size();
        int items = cfg.itemTaps().size();
        int boosters = cfg.boosterTaps().size();
        int planters = cfg.planterTaps().size();
        int quests = cfg.questTaps().size();
        int questNpcs = cfg.questNpcTaps().size();

        page.addView(ui.title("HiveMine Mobile V1.0"), ui.full(2));
        page.addView(ui.body("v1.4.0 ship. Fast human farm + anti-detect timer jitter. Vision, quests, boosters included."), ui.full(16));

        // status
        LinearLayout st = ui.card();
        String headline;
        int hc;
        if (!connected) { headline = "Not connected yet"; hc = Ui.AMBER; }
        else if (running) { headline = "Farming now"; hc = Ui.GREEN; }
        else { headline = "Ready"; hc = Ui.BLUE; }
        st.addView(ui.text(headline, hc, 22, true), ui.full(4));
        st.addView(ui.body(MacroAccessibilityService.status), ui.full(4));
        st.addView(ui.text(MacroAccessibilityService.bagLine, Ui.TEXT, 14, false), ui.full(4));
        FieldPresets.Preset pr = FieldPresets.forField(cfg.field);
        st.addView(ui.body("Field: " + cfg.field + "  |  " + pr.pattern + " " + pr.size + "  |  hive " + cfg.hiveSlot), ui.full(0));
        page.addView(st, ui.full(14));

        // the one big button
        Button go = running ? ui.primary("Stop", Ui.RED) : ui.primary("Start farming", Ui.GREEN);
        go.setTextSize(20);
        go.setMinHeight(ui.dp(64));
        go.setMinimumHeight(ui.dp(64));
        go.setOnClickListener(v -> onGo(running));
        page.addView(go, ui.full(14));
        Button lostBtn = ui.secondary("I'm lost (reset + walk to field)");
        lostBtn.setOnClickListener(v -> {
            MacroAccessibilityService svc = svc();
            if (svc == null) { toast("Turn on accessibility first"); return; }
            svc.imLost();
            moveTaskToBack(true);
        });
        page.addView(lostBtn, ui.full(10));

        // setup checklist
        LinearLayout setup = ui.card();
        setup.addView(ui.heading("Setup"), ui.full(2));
        setup.addView(ui.body("Accessibility required. Vision scan locks joystick / bag / convert and tags hive vs field from the live screen."), ui.full(4));
        Button autoBtn = ui.primary("Vision scan (open Roblox first)", Ui.BLUE);
        autoBtn.setOnClickListener(v -> {
            MacroAccessibilityService svc = svc();
            if (svc == null) { toast("Turn on accessibility first"); return; }
            svc.autoSenseSpots();
            moveTaskToBack(true);
            toast("Capturing... switch to Roblox if needed");
        });
        setup.addView(autoBtn, ui.full(10));
        setup.addView(ui.checkRow("1. Turn on the accessibility service",
            "Lets HiveMine Mobile tap and swipe for you.", connected, connected ? "Open" : "Open settings",
            v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))), ui.full(0));
        ui.line(setup);
        setup.addView(ui.checkRow("2. Joystick spot",
            "Where Roblox's movement stick is.", joyOk, joyOk ? "Change" : "Set",
            v -> guide("Open Roblox. Tap the CENTER of the movement joystick, then press Save here.", "joy")), ui.full(0));
        ui.line(setup);
        setup.addView(ui.checkRow("3. Bag reading",
            "Reads your pollen bar. Needed for Stop or Convert when full.", bagOk, bagOk ? "Change" : "Set",
            v -> guide("Open Roblox. Tap the LEFT end of the pollen bar, a few pixels inside it, then press Save here.", "bag")), ui.full(0));
        ui.line(setup);
        setup.addView(ui.checkRow("4. Make Honey button (optional)",
            "Where the convert button is at the hive.", convOk, convOk ? "Change" : "Set",
            v -> guide("Go to the hive in Roblox. Tap the Make Honey button, then press Save here.", "conv")), ui.full(0));
        ui.line(setup);
        setup.addView(ui.checkRow("5. Reset steps (optional)",
            "Menu taps that reset your character before converting. Saved: " + steps + ".", steps > 0, "Add step",
            v -> guide("Tap the next button you press to reset, such as the menu. Press Save here. Add steps in order.", "rst")), ui.full(0));
        ui.line(setup);
        setup.addView(ui.checkRow("6. Camera spot (optional)",
            "Only needed if you turn the camera before farming.", camOk, camOk ? "Change" : "Set",
            v -> guide("Open Roblox. Tap where a camera swipe should START, a spot away from buttons, then press Save here.", "cam")), ui.full(0));
        ui.line(setup);
        setup.addView(ui.checkRow("7. Timed item (optional)",
            "Sprinkler or hotbar item. Saved taps: " + items + ".", items > 0, "Add tap",
            v -> guide("Tap the item in your hotbar, for example the sprinkler. Press Save here. Add taps in order if it needs more than one.", "item")), ui.full(0));
        ui.line(setup);
        setup.addView(ui.checkRow("8. Booster (optional)",
            "Booster hotbar taps while farming. Saved: " + boosters + ".", boosters > 0, "Add tap",
            v -> guide("Tap your booster in the hotbar (and any confirm). Press Save here. Add taps in order.", "booster")), ui.full(0));
        ui.line(setup);
        setup.addView(ui.checkRow("9. Planter (optional)",
            "Place/harvest planter taps. Saved: " + planters + ".", planters > 0, "Add tap",
            v -> guide("Tap planter place or harvest buttons in order. Press Save here after each.", "planter")), ui.full(0));
        ui.line(setup);
        boolean aiOn = AiControlHub.isEnabled(this);
        setup.addView(ui.checkRow("10. AI control (off by default)",
            "Lets HiveMine AI start, recover and stop the macro. Stop always works, even when this is off.",
            aiOn, aiOn ? "Turn off" : "Turn on",
            v -> {
                AiControlHub.setEnabled(this, !aiOn);
                toast(aiOn ? "AI control off" : "AI control on");
                recreate();
            }), ui.full(0));
        ui.line(setup);
        setup.addView(ui.checkRow("10. Quest Turn In (green only)",
            "Extra taps after green Turn In is found. Saved: " + quests + ".", quests > 0, "Add tap",
            v -> guide("When a quest row is GREEN Complete, record any extra taps on that row. Green is also auto-found.", "quest")), ui.full(0));
        ui.line(setup);
        setup.addView(ui.checkRow("11. Quest NPC (next quest)",
            "Walk/talk to the character to get the next quest. Saved: " + questNpcs + ".", questNpcs > 0, "Add tap",
            v -> guide("After Complete, walk/talk to Spirit Bear (or the quest NPC) and accept the next quest. Save taps in order.", "questnpc")), ui.full(0));
        ui.line(setup);
        setup.addView(ui.checkRow("12. Disconnect spot (optional)",
            "Where Roblox's disconnect or rejoin button is. Needs a private server link under Advanced.",
            dcOk, dcOk ? "Change" : "Set",
            v -> guide("Open Roblox's disconnect or rejoin screen, tap its button, then press Save here.", "dc")), ui.full(0));
        Button bub = ui.secondary("Show floating bubble");
        bub.setOnClickListener(v -> showBubble());
        setup.addView(bub, ui.full(0));
        page.addView(setup, ui.full(14));

        // pattern and size
        LinearLayout pat = ui.card();
        pat.addView(ui.heading("Pattern"), ui.full(6));
        for (String[] p : PATTERN_INFO) {
            final String name = p[0];
            boolean sel = name.equals(cfg.pattern);
            Button b = ui.button(name + "\n" + p[1], sel ? Ui.BLUE : Ui.CARD_HI, Ui.TEXT);
            b.setTextSize(15);
            b.setOnClickListener(v -> { cfg.pattern = name; cfg.save(); show(false, true); });
            pat.addView(b, ui.full(8));
        }
        pat.addView(ui.label("Size"), ui.full(6));
        pat.addView(ui.chips(SIZE_LABELS, indexOf(Patterns.SIZES, cfg.size), v -> {
            cfg.size = Patterns.SIZES[v];
            cfg.save();
        }), ui.full(0));
        page.addView(pat, ui.full(14));

        // how it runs
        LinearLayout run = ui.card();
        run.addView(ui.heading("How it runs"), ui.full(6));
        run.addView(ui.slider("Repeat", 1, 9, 1, clamp(cfg.reps, 1, 9),
            v -> v == 1 ? "1 time" : v + " times",
            v -> { cfg.reps = v; cfg.save(); }), ui.full(0));
        run.addView(ui.slider("Stop after", 0, 180, 5, clamp(cfg.runMinutes, 0, 180),
            v -> v == 0 ? "Never" : v + " min",
            v -> { cfg.runMinutes = v; cfg.save(); }), ui.full(0));
        run.addView(ui.slider("Use item every", 0, 60, 1, clamp(cfg.itemMinutes, 0, 60),
            v -> v == 0 ? "Off" : v + " min",
            v -> { cfg.itemMinutes = v; cfg.save(); }), ui.full(0));
        run.addView(ui.slider("Booster every", 0, 60, 1, clamp(cfg.boosterMinutes, 0, 60),
            v -> v == 0 ? "Off" : v + " min",
            v -> { cfg.boosterMinutes = v; cfg.save(); }), ui.full(0));
        run.addView(ui.slider("Planter every", 0, 120, 5, clamp(cfg.planterMinutes, 0, 120),
            v -> v == 0 ? "Off" : v + " min",
            v -> { cfg.planterMinutes = v; cfg.save(); }), ui.full(0));
        run.addView(ui.slider("Quest every", 0, 60, 1, clamp(cfg.questMinutes, 0, 60),
            v -> v == 0 ? "Off" : v + " min",
            v -> { cfg.questMinutes = v; cfg.save(); }), ui.full(0));
        run.addView(ui.toggle("Smart quest (only tap when claim UI seen)", cfg.questSmart,
            on -> { cfg.questSmart = on; cfg.save(); }), ui.full(0));
        run.addView(ui.body("Smart quest: green Complete rows = go turn in. Red progress rows = still farming (skip). Then NPC taps."), ui.full(4));
        run.addView(ui.label("Human polish"), ui.full(6));
        run.addView(ui.toggle("Human mode (fast + natural)", cfg.humanMode,
            on -> { cfg.humanMode = on; cfg.save(); }), ui.full(0));
        run.addView(ui.slider("Human level", 0, 2, 1, clamp(cfg.humanLevel, 0, 2),
            v -> v == 0 ? "Light" : v == 1 ? "Normal" : "Heavy",
            v -> { cfg.humanLevel = v; cfg.save(); }), ui.full(0));
        run.addView(ui.body("Human stays quick: small drift and short pauses. Crank Walk speed under Movement."), ui.full(4));
        run.addView(ui.label("Field"), ui.full(6));
        Button fieldBtn = ui.secondary(cfg.field + "  (tap to change)");
        fieldBtn.setOnClickListener(v -> pickField());
        run.addView(fieldBtn, ui.full(8));
        run.addView(ui.toggle("Walk back to the field after converting", cfg.returnToField,
            on -> { cfg.returnToField = on; cfg.save(); }), ui.full(0));
        run.addView(ui.toggle("Auto walk to field on Start (recommended)", cfg.walkFirst,
            on -> { cfg.walkFirst = on; cfg.save(); }), ui.full(4));
        run.addView(ui.body("Pine Tree is the default. Pepper and Coconut routes can drift because of jumps."), ui.full(8));
        run.addView(ui.label("When my bag is full"), ui.full(6));
        run.addView(ui.chips(Config.FULL_ACTIONS, clamp(cfg.fullAction, 0, 2), v -> {
            cfg.fullAction = v;
            cfg.save();
            show(false, true);
        }), ui.full(4));
        if (cfg.fullAction > 0 && !bagOk) {
            run.addView(ui.body("This needs the bag spot. See step 3 in Setup."), ui.full(4));
        }
        run.addView(ui.slider("Full at", 50, 100, 5, clamp(cfg.fullPercent, 50, 100),
            v -> v + "%",
            v -> { cfg.fullPercent = v; cfg.save(); }), ui.full(0));
        run.addView(ui.label("Fail-safes (auto realign)"), ui.full(8));
        run.addView(ui.slider("Stuck reset after", 0, 15, 1, clamp(cfg.stuckMinutes, 0, 15),
            v -> v == 0 ? "Off" : v + " min no bag change",
            v -> { cfg.stuckMinutes = v; cfg.save(); }), ui.full(0));
        run.addView(ui.slider("Self-correct every", 0, 30, 1, clamp(cfg.selfCorrectMinutes, 0, 30),
            v -> v == 0 ? "Off" : v + " min",
            v -> { cfg.selfCorrectMinutes = v; cfg.save(); }), ui.full(0));
        run.addView(ui.body("Stuck = bag percent flat too long → reset + walk back. Self-correct = timed clean reset so drift never stacks."), ui.full(4));
        Button testWalk = ui.secondary("Test walk to field (no farming)");
        testWalk.setOnClickListener(v -> {
            MacroAccessibilityService svc = svc();
            if (svc == null) { toast("Turn on accessibility first"); return; }
            svc.testWalkToField(3000);
            moveTaskToBack(true);
        });
        run.addView(testWalk, ui.full(8));
        page.addView(run, ui.full(14));

        Button adv = ui.secondary("Advanced settings");
        adv.setOnClickListener(v -> show(true, false));
        page.addView(adv, ui.full(14));
        page.addView(ui.body("Use at your own risk. Macros can get a Roblox account moderated, so try an alt first."), ui.full(0));
    }

    // ------------------------------------------------------------ advanced screen

    private void buildAdvanced() {
        Button back = ui.secondary("Back");
        back.setOnClickListener(v -> show(false, false));
        page.addView(back, ui.full(12));
        page.addView(ui.title("Advanced"), ui.full(12));

        LinearLayout move = ui.card();
        move.addView(ui.heading("Movement"), ui.full(6));
        move.addView(ui.slider("Walk speed", 10, 60, 1, clamp(Math.round(cfg.moveSpeed), 10, 60),
            v -> v + " studs/s",
            v -> { cfg.moveSpeed = v; cfg.save(); }), ui.full(0));
        move.addView(ui.slider("Thumb distance", 40, 200, 10, clamp(cfg.radius, 40, 200),
            v -> v + " px",
            v -> { cfg.radius = v; cfg.save(); }), ui.full(0));
        Button walkChk = ui.secondary("Walk speed check: walk 10 tiles (switch to Roblox)");
        walkChk.setOnClickListener(v -> walkCheckNow());
        move.addView(walkChk, ui.full(8));
        EditText walked = new EditText(this);
        walked.setHint("Tiles it really walked, e.g. 8.5");
        walked.setSingleLine(true);
        walked.setTextColor(Ui.TEXT);
        walked.setHintTextColor(Ui.MUTED);
        move.addView(walked, ui.full(8));
        Button applyWalk = ui.secondary("Set walk speed from that distance");
        applyWalk.setOnClickListener(v -> applyWalkCheck(walked.getText().toString()));
        move.addView(applyWalk, ui.full(8));
        move.addView(ui.toggle("Flip forward and back", cfg.invFB, v -> { cfg.invFB = v; cfg.save(); }), ui.full(0));
        move.addView(ui.toggle("Flip left and right", cfg.invLR, v -> { cfg.invLR = v; cfg.save(); }), ui.full(0));
        move.addView(ui.toggle("Facing a field corner (for Fork)", cfg.facingCorner,
            v -> { cfg.facingCorner = v; cfg.save(); }), ui.full(0));
        page.addView(move, ui.full(14));

        LinearLayout cam = ui.card();
        cam.addView(ui.heading("Camera"), ui.full(6));
        cam.addView(ui.slider("Camera turns before start", -4, 4, 1, clamp(cfg.rotateSwipes, -4, 4),
            v -> v == 0 ? "None" : (v > 0 ? "Right " : "Left ") + Math.abs(v),
            v -> { cfg.rotateSwipes = v; cfg.save(); }), ui.full(0));
        cam.addView(ui.slider("Camera swipe length", 100, 600, 25, clamp(cfg.swipeLen, 100, 600),
            v -> v + " px",
            v -> { cfg.swipeLen = v; cfg.save(); }), ui.full(0));
        page.addView(cam, ui.full(14));

        LinearLayout conv = ui.card();
        conv.addView(ui.heading("Convert"), ui.full(6));
        conv.addView(ui.slider("Hive slot", 1, 6, 1, clamp(cfg.hiveSlot, 1, 6),
            v -> "Slot " + v,
            v -> { cfg.hiveSlot = v; cfg.save(); }), ui.full(0));
        conv.addView(ui.slider("Wait after reset", 1, 30, 1, clamp(cfg.respawnWait, 1, 30),
            v -> v + " s",
            v -> { cfg.respawnWait = v; cfg.save(); }), ui.full(0));
        Button clear = ui.secondary("Clear reset steps (" + cfg.resetTaps().size() + ")");
        clear.setOnClickListener(v -> {
            cfg.resetSteps = "";
            cfg.save();
            toast("Reset steps cleared.");
            show(true, true);
        });
        conv.addView(clear, ui.full(0));
        page.addView(conv, ui.full(14));

        LinearLayout tripCard = ui.card();
        tripCard.addView(ui.heading("Trips from the hive (optional)"), ui.full(6));
        tripCard.addView(ui.body("After a convert, a trip that is due walks to a building, taps your saved spots, walks back, then goes to your field. Routes come from HiveMine's collect paths. Three HiveMine routes that need its cannon are left out."), ui.full(8));
        tripCard.addView(ui.slider("Bees in hive (some routes check this)", 1, 50, 1, clamp(cfg.hiveBees, 1, 50),
            v -> v + " bees",
            v -> { cfg.hiveBees = v; cfg.save(); }), ui.full(8));
        for (int i = 0; i < 2; i++) {
            final int slot = i;
            tripCard.addView(ui.label("Trip " + (i + 1)), ui.full(6));
            Button trpPick = ui.secondary(cfg.tripRoute[i].isEmpty() ? "Pick a route" : cfg.tripRoute[i]);
            trpPick.setOnClickListener(v -> pickTrip(slot));
            tripCard.addView(trpPick, ui.full(8));
            tripCard.addView(ui.slider("Every", 0, 180, 5, clamp(cfg.tripMinutes[i], 0, 180),
                v -> v == 0 ? "Off" : v + " min",
                v -> { cfg.tripMinutes[slot] = v; cfg.save(); }), ui.full(0));
            Button trpRec = ui.secondary("Record destination taps (" + cfg.tripTaps(i).size() + " saved)");
            trpRec.setOnClickListener(v -> guide("Open Roblox at the building. Tap the button that collects or uses it, then press Save here. Add taps in order.", "trip" + slot));
            tripCard.addView(trpRec, ui.full(8));
            Button trpClr = ui.secondary("Clear destination taps");
            trpClr.setOnClickListener(v -> { cfg.tripSteps[slot] = ""; cfg.save(); show(true, true); });
            tripCard.addView(trpClr, ui.full(8));
            Button trpTest = ui.secondary("Test trip " + (i + 1) + " now (switch to Roblox)");
            trpTest.setOnClickListener(v -> testTripNow(slot));
            tripCard.addView(trpTest, ui.full(14));
        }
        page.addView(tripCard, ui.full(14));

        LinearLayout rejoin = ui.card();
        rejoin.addView(ui.heading("Reconnect"), ui.full(6));
        rejoin.addView(ui.body("Paste your private server link. If Roblox disconnects, the app opens it again, waits, then walks back to your field."), ui.full(8));
        EditText link = new EditText(this);
        link.setText(cfg.privateLink);
        link.setHint("Private server link");
        link.setSingleLine(true);
        link.setTextColor(Ui.TEXT);
        link.setHintTextColor(Ui.MUTED);
        rejoin.addView(link, ui.full(8));
        Button saveLink = ui.secondary("Save link");
        saveLink.setOnClickListener(v -> {
            cfg.privateLink = link.getText().toString().trim();
            cfg.save();
            toast(linkMessage(cfg.privateLink));
            show(true, true);
        });
        rejoin.addView(saveLink, ui.full(8));
        rejoin.addView(ui.toggle("Rejoin if Roblox closes or leaves the screen for 8 seconds", cfg.watchRoblox,
            on -> { cfg.watchRoblox = on; cfg.save(); }), ui.full(0));
        rejoin.addView(ui.slider("Wait after rejoining", 20, 180, 5, clamp(cfg.rejoinSec, 20, 180),
            v -> v + " s",
            v -> { cfg.rejoinSec = v; cfg.save(); }), ui.full(0));
        Button testRejoin = ui.secondary("Test rejoin now (start farming first)");
        testRejoin.setOnClickListener(v -> testRejoinNow());
        rejoin.addView(testRejoin, ui.full(0));
        Button checkPic = ui.secondary("Check Make Honey picture (switch to Roblox at the hive)");
        checkPic.setOnClickListener(v -> checkPictureNow());
        rejoin.addView(checkPic, ui.full(0));
        Button checkSpot = ui.secondary("Check disconnect spot (switch to its screen)");
        checkSpot.setOnClickListener(v -> checkSpotNow());
        rejoin.addView(checkSpot, ui.full(0));
        page.addView(rejoin, ui.full(14));

        LinearLayout tools = ui.card();
        tools.addView(ui.heading("Tools"), ui.full(6));
        Button test = ui.primary("Test joystick", Ui.BLUE);
        test.setOnClickListener(v -> testJoystick());
        tools.addView(test, ui.full(6));
        tools.addView(ui.body("Test waits 4 seconds, then walks the thumb right for one second. Switch to Roblox during that time."), ui.full(8));
        Button showB = ui.secondary("Show floating bubble");
        showB.setOnClickListener(v -> showBubble());
        tools.addView(showB, ui.full(8));
        Button hideB = ui.secondary("Hide floating bubble");
        hideB.setOnClickListener(v -> hideBubble());
        tools.addView(hideB, ui.full(8));
        Button itemTest = ui.secondary("Test item taps");
        itemTest.setOnClickListener(v -> testItemTaps());
        tools.addView(itemTest, ui.full(8));
        Button clearItem = ui.secondary("Clear item taps (" + cfg.itemTaps().size() + ")");
        clearItem.setOnClickListener(v -> {
            cfg.itemSteps = "";
            cfg.save();
            toast("Item taps cleared.");
            show(true, true);
        });
        tools.addView(clearItem, ui.full(0));
        Button clearBoost = ui.secondary("Clear booster taps (" + cfg.boosterTaps().size() + ")");
        clearBoost.setOnClickListener(v -> {
            cfg.boosterSteps = "";
            cfg.save();
            toast("Booster taps cleared.");
            show(true, true);
        });
        tools.addView(clearBoost, ui.full(0));
        Button clearPlanter = ui.secondary("Clear planter taps (" + cfg.planterTaps().size() + ")");
        clearPlanter.setOnClickListener(v -> {
            cfg.planterSteps = "";
            cfg.save();
            toast("Planter taps cleared.");
            show(true, true);
        });
        tools.addView(clearPlanter, ui.full(0));
        Button clearQuest = ui.secondary("Clear turn-in taps (" + cfg.questTaps().size() + ")");
        clearQuest.setOnClickListener(v -> {
            cfg.questSteps = "";
            cfg.save();
            toast("Turn-in taps cleared.");
            show(true, true);
        });
        tools.addView(clearQuest, ui.full(0));
        Button clearNpc = ui.secondary("Clear NPC next-quest taps (" + cfg.questNpcTaps().size() + ")");
        clearNpc.setOnClickListener(v -> {
            cfg.questNpcSteps = "";
            cfg.save();
            toast("NPC taps cleared.");
            show(true, true);
        });
        tools.addView(clearNpc, ui.full(0));
        page.addView(tools, ui.full(14));
    }
}
