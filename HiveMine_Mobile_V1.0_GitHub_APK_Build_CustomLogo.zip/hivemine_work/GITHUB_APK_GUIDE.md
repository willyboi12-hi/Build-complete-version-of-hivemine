# Build HiveMine Mobile APK without Android Studio

1. Create a GitHub repository (a free account is enough).
2. Upload the contents of this project to the repository.
3. Open **Actions** in the repository.
4. Select **HiveMine Mobile APK**.
5. Press **Run workflow**.
6. Wait for the green check to finish.
7. Open the completed workflow run and scroll to **Artifacts**.
8. Download **HiveMine-Mobile-V1.0-debug-APK**.
9. Extract the downloaded artifact and install `app-debug.apk` on the Android phone.

The workflow uses Java 17, Android SDK 35, and Gradle 8.9. It builds the debug APK directly on GitHub's Android-capable runner, so Android Studio is not required.

For installation, Android may ask you to allow the browser/files app to install unknown apps. Only enable that permission for the app you use to install the APK, then disable it afterward if desired.
