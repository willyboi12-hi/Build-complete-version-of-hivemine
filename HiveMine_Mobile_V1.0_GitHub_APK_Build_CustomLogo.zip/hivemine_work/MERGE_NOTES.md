# HiveMine Mobile + HiveMine AI (combined)

This repository combines two projects:

| Path | What it is |
| --- | --- |
| `app/`, root Gradle files | HiveMine Mobile: the Android macro app (`com.hiveminemobile`) |
| `hivemine-ai/ai-core/` | HiveMine AI core: Java 8, Android-free library (`com.hiveminemobile.ai`), wired in as Gradle module `:ai-core` |
| `hivemine-ai/` (everything else) | HiveMine AI docs, phase ledger, web UI, config, and its JVM test suite |

## Boundary
HiveMine AI never touches Android or the macro directly. It only uses `com.hiveminemobile.ai.control.MacroPort`
(`start`, `stop`, `recover`, `readStatus`). HiveMine Mobile must supply the `MacroPort` implementation.
Read `hivemine-ai/INTEGRATION_GUIDE.md` before writing that adapter.

## Wiring added in this merge
- `settings.gradle`: includes `:ai-core` from `hivemine-ai/ai-core`.
- `app/build.gradle`: `implementation project(':ai-core')`.
- `.github/workflows/android-build.yml`: runs `bash hivemine-ai/tests/run.sh` before lint and APK builds.

## Still needed before a finished build
- **Android build (blocked here):** `./gradlew :app:assembleDebug`, `:app:lintDebug`, and `:app:assembleRelease` need the Android SDK and network access. This environment has neither (no SDK, no `android.jar`, Google and Gradle servers unreachable). Run these on a machine with both.
- **Phone testing (blocked here):** check the AI switch, start/recover/stop through `AiMacroPort`, and that Stop always works with AI control off. See `DEVICE_TEST_MATRIX.md`.
- **Decision loop (open):** the AI makes no decisions and takes no actions on its own. Actions happen only when you press Start, Recover, or Stop in the AI tab. Deciding what the AI should do beyond that needs a spec.
- **Release signing (needs your key):** the release build is signed only when these Gradle properties are set: `HIVEMINE_KEYSTORE_FILE`, `HIVEMINE_KEYSTORE_PASSWORD`, `HIVEMINE_KEY_ALIAS`, `HIVEMINE_KEY_PASSWORD`. Put them in `~/.gradle/gradle.properties`, not in the repo. Without them the release APK is unsigned. The config parses but has not been run through AGP.

## Wiring added in this merge
- `settings.gradle`: includes `:ai-core` from `hivemine-ai/ai-core`.
- `app/build.gradle`: `implementation project(':ai-core')`.
- `.github/workflows/android-build.yml`: runs `bash hivemine-ai/tests/run.sh` before lint and APK builds.

## Not done yet (blocking a finished build)
- Full Android build not run: `./gradlew :app:assembleDebug`, `:app:lintDebug`, and `:app:assembleRelease` need the Android SDK and network. None of this environment's checks cover `MainActivity` or the overlay classes.
- `MainActivity` and `OverlayDashboardView` changes are not compiled. The Android stubs can't compile them. For the dashboard, the only new compile errors are `getContext()` calls, the same stub gap the existing code has.
- Device testing: the AI control switch, start/stop/recover through `AiMacroPort`, and the Stop-always-works rule must be checked on a phone (`DEVICE_TEST_MATRIX.md`).
- No loop calls the AI's decision code yet. `AutomationController` exists and the switch works, but nothing requests actions from it.
- Release signing is not configured (`app-release-unsigned.apk`).

## Wiring added in this merge
- `AiMacroPort`: `MacroPort` implementation over `MacroAccessibilityService`.
- `AiControlHub`: owns the one `AutomationController` and persists `ai_control_enabled` (default off) in the `natro_mobile` preferences.
- `MainActivity` Setup card: "10. AI control" row to turn it on or off.
- Floating overlay: new **AI** tab in `OverlayDashboardView` (opened from the bubble). It shows AI control and macro state, turns AI control on or off, sends Start / Recover / Stop through the controller (refusals are shown in plain words), and lists recent AI decisions.

## Status
- HiveMine AI is v2.00 (`ai-core` version 2.0.0). Its JVM suite passes (1015 checks).
- HiveMine Mobile has a new JVM suite (`bash tests/run.sh`, 897 checks). It replaces the original suite, whose files were not in the source archive. The old "750 passed" claim is retired (see `SANDBOX_RESULTS.txt`).
- The Gradle wrapper is regenerated for 8.9. Run `./gradlew --version` once with network access to confirm.
- The full Android build (`:app:assembleDebug`) has not been run in this environment.
- Docs outside the test files (`README.md`, `ARCHITECTURE.md`, `BUILD_INSTRUCTIONS.md`, `CHANGELOG.md`, and others) still describe the old sandbox suite and need a pass.

## Test environment for the AI features
- `bash tests/run-ai.sh` (31 checks, all passing): the AI switch, Start/Recover/Stop rules (Stop always forwarded), status messages, restart persistence, and a contract check against the real macro service source.
- Uses test fakes in `tests/fakes/` (Android `Context`, `SharedPreferences`, macro service). These are test-only and never shipped.
- Mutation check: breaking the emergency stop makes 3 checks fail, so the suite does catch regressions.
- `tests/stubs` (the original stub set) was broken in about 12 files and was replaced by `tests/fakes`. The engine suite passes against the fakes.
- `bash tests/run-ai.sh` also builds the real `OverlayDashboardView` against the fakes, opens its AI tab, presses its buttons, and checks the screen text and what the service receives (19 checks). A mutation (switch does nothing) makes these checks fail.
- Not covered: real drawing, touch, and layout; the real `MacroAccessibilityService` (gestures); and the real `MainActivity`. Those are checked only by a device or an Android test runner (Robolectric or an emulator), which need the Android SDK and network access.

## Completeness audit
- No empty files or folders. Build leftovers from the source archive (`javac.log`, `javac.exit`) and empty folders were removed. `sources.list` now lists all 247 test files.
- Phase docs: all 96 numbered docs now have content, taken from the code's own phase tags and the test files that reference each class. Phases 080, 090, and 100 have no code tag, and their docs say so. Phase 079 (ManagerIntelligenceReport) has no test coverage.
- `PHASE_INDEX_250.md` maps 250 phases to only 13 implementor classes (all exist). Phases 071-100 now have names taken from the code. Many other index names are still generic (for example "Foundation step 1"), so the "250 phases" are still mainly labels.
- Not complete: the real Android build, phone testing, the decision loop, and release signing (see "Still needed" above).
