# Deep Error Audit — HiveMine Mobile + HiveMine AI

Audit target: combined HiveMine Mobile Android app 1.8.0 + HiveMine AI core 2.00.

## Result

A full source/archive pass was performed after extracting the final package. The audit found and corrected several small-to-medium issues that were still present:

1. The JVM test runner was not executable in the archive (`644`); it is now `755`.
2. Three existing JVM tests were stale/incorrect against the finalized control behavior. The recover test now places the fake macro in a running state before requesting recovery.
3. Natural-language negation was incomplete: phrases such as `don't enable quests` and mixed clauses such as `don't farm Pine Tree and farm Sunflower` could be interpreted incorrectly. Negation now works at clause scope, and negative fields/material goals are ignored.
4. Headless `AiManagerService` instances without Android persistence incorrectly reported a settings-storage failure. They now apply settings to the current in-memory session and explicitly report that they are not persisted. Android still requires and uses the real configuration applier.
5. A failed Android configuration save could still leave the Manager's farm goal enabled for a material request. Manager control is now enabled only when settings application succeeds.
6. Runtime command outcomes were being learned in memory but were not actually written to the SQLite learning table. Terminal command outcomes are now persisted and restored on Manager startup.
7. Learning-history restoration previously selected the oldest records rather than the newest bounded history. It now restores the newest records.
8. The accessibility-service description incorrectly said that nothing was saved. It now accurately states that raw screenshots are not persisted while small operational AI summaries may be stored locally.
9. Vision frame arithmetic was hardened against integer overflow in frame-size, region-size, and gauge calculations.
10. Test reset state now clears the Manager runtime and vision hash as well as the database/controller objects.

## Automated verification

- HiveMine AI JVM suite: **1110 passed, 0 failed**.
- Source-level TODO/FIXME/HACK/STUB scan over Java production code: **none found**.
- Archive integrity: verified.
- Android Gradle build: not executable in this environment because Gradle 8.9 is not cached and `services.gradle.org` is unreachable.

## Remaining verification-only items

These are not source errors established by this audit, but they still require an Android build/device environment:

- Gradle/Android compilation and packaging.
- Android lint.
- APK installation and launch.
- Accessibility-service behavior on physical devices.
- Android screenshot capture on supported OS versions.
- Real Roblox/HiveMine runtime behavior.
- Release signing and Play/distribution validation.

The absence of those device-level checks should not be represented as a passing result merely because the JVM suite passes.
