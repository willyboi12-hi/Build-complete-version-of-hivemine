## Combined repo (HiveMine Mobile + HiveMine AI v2.00)
- Added `hivemine-ai/` (HiveMine AI v2.00) as Gradle module `:ai-core`, wired into the app.
- Added `AiMacroPort`, the app's `MacroPort` implementation for HiveMine AI.
- Replaced the missing original JVM suite with a new engine suite (897 checks).
- Regenerated the Gradle wrapper for 8.9.
- Set HiveMine AI's `VersionInfo` and `VERSION` to 2.00 (the failing v2 version test now passes).

# Changelog

## v1.8.0 source expansion
- Added `AutomationTaskCoordinator` with explicit priority arbitration and latched emergency stop.
- Added deterministic sandbox clock, fault injection, and session state model.
- Expanded JVM/sandbox tests from 739 to 750 passing checks.
- Added Gradle settings and Java 8 source compatibility.
- Expanded CI to run tests, lint, debug APK, and unsigned release APK tasks.
- Added audit, architecture, security, contribution, build, sandbox, device matrix, and production readiness documents.

## Limitations
Android build tasks and real-device validation have not been executed in this environment.


## HiveMine AI runtime hardening follow-up
- Added a dedicated one-second Android status poll that updates bridge command completion and manager state.
- Connected real bag/scene screenshot telemetry and a first-frame/stale-frame watchdog.
- Routed AI chat and overlay commands through the same authorized command bridge.
- Made STOP dispatch failures explicit and refused RECOVER for an idle macro.
- Made settings commits verifiable and added best-effort rollback on failure.
- Added bounded SQLite operational event history and corrected outdated 1.7.0 handoff docs.
- Reclassified phase evidence and updated tests: 897 engine checks and 82 AI/app wiring checks pass. Android build/device gates remain open.

## Launcher icon update
- Added custom HiveMine Mobile black/electric-blue hexagon + H launcher icon.
- Configured adaptive launcher icon for Android 8+ and fallback vector icon for older devices.
