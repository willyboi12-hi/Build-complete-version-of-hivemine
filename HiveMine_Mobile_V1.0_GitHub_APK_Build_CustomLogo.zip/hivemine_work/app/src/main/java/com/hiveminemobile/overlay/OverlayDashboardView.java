package com.hiveminemobile.overlay;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import com.hiveminemobile.AiControlHub;
import com.hiveminemobile.AiStatusMessages;
import com.hiveminemobile.Config;
import com.hiveminemobile.FieldPresets;
import com.hiveminemobile.FieldRoutes;
import com.hiveminemobile.MainActivity;
import com.hiveminemobile.Ui;
import com.hiveminemobile.ai.control.AutomationController;

/**
 * HiveMine Mobile V1.0 floating dashboard.
 *
 * The overlay deliberately mirrors the polished black/blue mobile dashboard:
 * compact header, status telemetry, five primary controls, farming/quick-action
 * cards, recent activity, and a draggable footer. Existing macro and AI actions
 * remain wired to the same production controllers.
 */
public class OverlayDashboardView extends FrameLayout {
    public interface Listener { void onMinimize(); void onClose(); void onDragEnd(int x, int y); }

    private final Ui ui;
    private final OverlaySettings settings;
    private final OverlayMacroController macro;
    private Listener listener;
    private WindowManager.LayoutParams lp;

    private LinearLayout rootCard;
    private TextView statusTitle, statusSub, runtimeText, bagText, footerStatus;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable statusTicker = this::tickStatus;
    private boolean tickerRunning;
    private float downRawX, downRawY;
    private int startX, startY;
    private boolean moved;
    private int currentTab = 0;
    private LinearLayout contentHost;
    private Button[] tabButtons;
    private TextView aiResultText;
    private long startMs = 0;

    public OverlayDashboardView(Context c, Ui ui, OverlaySettings settings, OverlayMacroController macro) {
        super(c); this.ui = ui; this.settings = settings; this.macro = macro;
        currentTab = settings.getLastTab(); build();
    }

    public void setListener(Listener l) { listener = l; }
    public void setLayoutParams(WindowManager.LayoutParams params) { lp = params; }

    private void build() {
        int width = ui.dp(390);
        setLayoutParams(new LayoutParams(width, LayoutParams.WRAP_CONTENT));
        rootCard = new LinearLayout(getContext());
        rootCard.setOrientation(LinearLayout.VERTICAL);
        rootCard.setPadding(ui.dp(14), ui.dp(12), ui.dp(14), ui.dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF7090D14); bg.setCornerRadius(ui.dp(24));
        bg.setStroke(ui.dp(2), 0xEE1976FF); rootCard.setBackground(bg);
        rootCard.setElevation(ui.dp(22)); rootCard.setAlpha(settings.getTransparency());

        rootCard.addView(buildHeader());
        rootCard.addView(buildResourceStrip(), ui.full(8));
        rootCard.addView(buildTabs());
        contentHost = new LinearLayout(getContext());
        contentHost.setOrientation(LinearLayout.VERTICAL);
        android.widget.ScrollView contentScroll = new android.widget.ScrollView(getContext());
        contentScroll.addView(contentHost, new android.widget.ScrollView.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        rootCard.addView(contentScroll, new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, ui.dp(430)));
        rootCard.addView(buildFooter());
        addView(rootCard, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        rootCard.setOnTouchListener(this::onDragTouch);
        showTab(currentTab);
        startTicker();
    }

    private LinearLayout buildHeader() {
        LinearLayout h = new LinearLayout(getContext());
        h.setOrientation(LinearLayout.HORIZONTAL); h.setGravity(Gravity.CENTER_VERTICAL);
        h.setPadding(0, 0, 0, ui.dp(8));

        TextView logo = ui.text("H", Ui.TEXT, 23, true); logo.setGravity(Gravity.CENTER);
        GradientDrawable lg = new GradientDrawable(); lg.setColor(0xFF071A32); lg.setCornerRadius(ui.dp(15));
        lg.setStroke(ui.dp(2), Ui.BLUE_LIGHT); logo.setBackground(lg);
        logo.setPadding(ui.dp(12), ui.dp(5), ui.dp(12), ui.dp(5)); h.addView(logo);

        LinearLayout titles = new LinearLayout(getContext()); titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(ui.dp(10), 0, ui.dp(6), 0);
        titles.addView(ui.text("HiveMine Mobile", Ui.TEXT, 17, true));
        titles.addView(ui.text("Bee Swarm Automation", Ui.MUTED, 10, false));
        h.addView(titles, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));

        TextView pill = ui.text("●  " + (macro.isPaused() ? "Macro Paused" : (macro.isRunning() ? "Macro Running" : "Ready")), Ui.BLUE_LIGHT, 10, true);
        pill.setPadding(ui.dp(9), ui.dp(6), ui.dp(9), ui.dp(6));
        GradientDrawable pg = new GradientDrawable(); pg.setColor(0x332563EB); pg.setCornerRadius(ui.dp(18));
        pg.setStroke(ui.dp(1), 0x663B82F6); pill.setBackground(pg); h.addView(pill);

        Button min = makeIconBtn("—"); min.setOnClickListener(v -> { if (listener != null) listener.onMinimize(); }); h.addView(min);
        Button close = makeIconBtn("×"); close.setOnClickListener(v -> { if (listener != null) listener.onClose(); }); h.addView(close);
        return h;
    }

    private LinearLayout buildResourceStrip() {
        LinearLayout row = new LinearLayout(getContext()); row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(resource("Honey", "—"), weight(1));
        row.addView(resource("Pollen", macro.getBagLine()), weight(1));
        return row;
    }

    private LinearLayout resource(String name, String value) {
        LinearLayout c = new LinearLayout(getContext()); c.setOrientation(LinearLayout.HORIZONTAL); c.setGravity(Gravity.CENTER_VERTICAL);
        c.setPadding(ui.dp(9), ui.dp(6), ui.dp(9), ui.dp(6));
        GradientDrawable g = new GradientDrawable(); g.setColor(0xFF101A28); g.setCornerRadius(ui.dp(12)); g.setStroke(ui.dp(1), 0x773B82F6); c.setBackground(g);
        c.addView(ui.text(name + "  ", Ui.TEXT, 10, true));
        TextView v = ui.text(value, Ui.BLUE_LIGHT, 11, true); c.addView(v);
        return c;
    }

    private Button makeIconBtn(String t) {
        Button b = new Button(getContext()); b.setText(t); b.setAllCaps(false); b.setTextSize(17); b.setTextColor(Ui.TEXT);
        b.setMinWidth(0); b.setMinimumWidth(0); b.setMinHeight(0); b.setMinimumHeight(0); b.setPadding(ui.dp(9), ui.dp(5), ui.dp(9), ui.dp(5));
        GradientDrawable g = new GradientDrawable(); g.setColor(0xFF101A28); g.setCornerRadius(ui.dp(12)); g.setStroke(ui.dp(1), 0x663B82F6); b.setBackground(g); return b;
    }

    private HorizontalScrollView buildTabs() {
        HorizontalScrollView hsv = new HorizontalScrollView(getContext()); hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(getContext()); row.setOrientation(LinearLayout.HORIZONTAL); row.setPadding(0, 0, 0, ui.dp(8));
        String[] labels = {"Home", "Farming", "Quests", "Inventory", "Settings", "AI"};
        tabButtons = new Button[labels.length];
        for (int i = 0; i < labels.length; i++) {
            final int idx = i; Button b = new Button(getContext()); b.setText(labels[i]); b.setAllCaps(false); b.setTextSize(11);
            b.setTextColor(i == currentTab ? Ui.TEXT : Ui.MUTED); b.setMinHeight(ui.dp(38)); b.setMinimumHeight(ui.dp(38)); b.setPadding(ui.dp(10), ui.dp(5), ui.dp(10), ui.dp(5));
            GradientDrawable g = new GradientDrawable(); g.setCornerRadius(ui.dp(15)); g.setColor(i == currentTab ? Ui.BLUE_GLOW : 0xFF111A27); g.setStroke(ui.dp(1), 0x663B82F6); b.setBackground(g);
            b.setOnClickListener(v -> showTab(idx)); tabButtons[i] = b;
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT); p.setMargins(0, 0, ui.dp(5), 0); row.addView(b, p);
        }
        hsv.addView(row); return hsv;
    }

    private void showTab(int idx) {
        currentTab = idx; settings.setLastTab(idx);
        if (tabButtons != null) for (int i = 0; i < tabButtons.length; i++) {
            GradientDrawable g = new GradientDrawable(); g.setCornerRadius(ui.dp(15)); g.setColor(i == idx ? Ui.BLUE_GLOW : 0xFF111A27); g.setStroke(ui.dp(1), 0x663B82F6); tabButtons[i].setBackground(g);
            tabButtons[i].setTextColor(i == idx ? Ui.TEXT : Ui.MUTED);
        }
        contentHost.removeAllViews();
        switch (idx) { case 0: contentHost.addView(buildHomeTab()); break; case 1: contentHost.addView(buildFarmingTab()); break; case 2: contentHost.addView(buildQuestsTab()); break; case 3: contentHost.addView(buildInventoryTab()); break; case 4: contentHost.addView(buildSettingsTab()); break; default: contentHost.addView(buildAiTab()); }
    }

    private LinearLayout buildHomeTab() {
        LinearLayout col = new LinearLayout(getContext()); col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout status = makeCard(); status.setPadding(ui.dp(14), ui.dp(12), ui.dp(14), ui.dp(12));
        LinearLayout sr = new LinearLayout(getContext()); sr.setOrientation(LinearLayout.HORIZONTAL); sr.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon = ui.text(macro.isPaused() ? "Ⅱ" : (macro.isRunning() ? "✓" : "▶"), Ui.BLUE_LIGHT, 24, true); icon.setGravity(Gravity.CENTER);
        GradientDrawable ib = new GradientDrawable(); ib.setShape(GradientDrawable.OVAL); ib.setColor(0x221E6DFF); ib.setStroke(ui.dp(2), Ui.BLUE_GLOW); icon.setBackground(ib); icon.setPadding(ui.dp(11), ui.dp(7), ui.dp(11), ui.dp(7)); sr.addView(icon);
        LinearLayout sl = new LinearLayout(getContext()); sl.setOrientation(LinearLayout.VERTICAL); sl.setPadding(ui.dp(10), 0, ui.dp(5), 0);
        sl.addView(ui.text("Macro Status", Ui.MUTED, 10, false)); statusTitle = ui.text(macro.isPaused() ? "Paused" : (macro.isRunning() ? "Running" : "Ready"), macro.isPaused() || macro.isRunning() ? Ui.BLUE_LIGHT : Ui.TEXT, 21, true); sl.addView(statusTitle); statusSub = ui.text(macro.getStatus(), Ui.MUTED, 11, false); sl.addView(statusSub);
        sr.addView(sl, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1.25f));
        runtimeText = ui.text("Runtime\n00:00:00", Ui.TEXT, 11, false); runtimeText.setGravity(Gravity.CENTER); sr.addView(runtimeText, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, .8f));
        sr.addView(stat("Pollen", macro.getBagLine()), new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, .8f));
        status.addView(sr); col.addView(status, ui.full(8));

        LinearLayout controls = new LinearLayout(getContext()); controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.addView(makeActionBtn("▶\nStart", Ui.BLUE_GLOW, v -> macro.startDelayed(3000)), weight(1));
        controls.addView(makeActionBtn("■\nStop", 0xFF18212D, v -> macro.stop()), weight(1));
        controls.addView(makeActionBtn("Ⅱ\nPause", 0xFF18212D, v -> { if (macro.isRunning()) { macro.pause(); tickStatus(); } }), weight(1));
        controls.addView(makeActionBtn("▶\nResume", 0xFF18212D, v -> { if (macro.isPaused()) macro.resume(); else if (!macro.isRunning()) macro.start(); tickStatus(); }), weight(1));
        controls.addView(makeActionBtn("⚠\nEmergency", Ui.RED, v -> macro.emergencyStop()), weight(1));
        col.addView(controls, ui.full(8));

        LinearLayout pair = new LinearLayout(getContext()); pair.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout farm = makeCard(); farm.addView(ui.text("◈  Farming Settings", Ui.TEXT, 13, true));
        LinearLayout farmBody = new LinearLayout(getContext()); farmBody.setOrientation(LinearLayout.HORIZONTAL); farmBody.setGravity(Gravity.CENTER_VERTICAL);
        TextView flower = ui.text("✿", Ui.BLUE_LIGHT, 30, true); flower.setGravity(Gravity.CENTER); GradientDrawable fb = new GradientDrawable(); fb.setColor(0xFF14263A); fb.setCornerRadius(ui.dp(12)); flower.setBackground(fb); flower.setPadding(ui.dp(14), ui.dp(8), ui.dp(14), ui.dp(8)); farmBody.addView(flower);
        LinearLayout ftxt = new LinearLayout(getContext()); ftxt.setOrientation(LinearLayout.VERTICAL); ftxt.setPadding(ui.dp(9), 0, 0, 0); ftxt.addView(ui.text("Field", Ui.MUTED, 10, false)); ftxt.addView(ui.text("Clover Field", Ui.TEXT, 14, true)); ftxt.addView(ui.text("Auto Farm  ● ON", Ui.BLUE_LIGHT, 11, true)); farmBody.addView(ftxt); farm.addView(farmBody, ui.full(0));
        pair.addView(farm, weight(1));

        LinearLayout qa = makeCard(); qa.addView(ui.text("★  Quick Actions", Ui.TEXT, 13, true));
        qa.addView(makeSmallBtn("♛  Auto Quests", v -> macro.runSavedTaps("quest", 600))); qa.addView(makeSmallBtn("▣  Collect Gifts", v -> macro.runSavedTaps("item", 600))); qa.addView(makeSmallBtn("⌖  Teleport", v -> { android.content.Context c=getContext(); c.startActivity(new android.content.Intent(c, MainActivity.class).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)); })); qa.addView(makeSmallBtn("↻  Reset Character", v -> macro.runSavedTaps("reset", 600)));
        pair.addView(qa, weight(1)); col.addView(pair, ui.full(8));

        LinearLayout recent = makeCard(); recent.addView(ui.text("▰  Recent Activity", Ui.TEXT, 13, true));
        recent.addView(activity("●", "Farming started in Clover Field", "2m ago"));
        recent.addView(activity("●", "Collected " + macro.getBagLine(), "2m ago"));
        recent.addView(activity("●", "Quest progress updated", "3m ago"));
        col.addView(recent, ui.full(8));
        return col;
    }

    private TextView stat(String label, String value) {
        TextView t = ui.text(label + "\n" + value, Ui.TEXT, 11, false); t.setGravity(Gravity.CENTER); return t;
    }
    private LinearLayout activity(String dot, String event, String age) {
        LinearLayout r = new LinearLayout(getContext()); r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(0, ui.dp(3), 0, ui.dp(3));
        r.addView(ui.text(dot, Ui.BLUE_LIGHT, 12, true)); r.addView(ui.text("  " + event, Ui.TEXT, 10, false), new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)); r.addView(ui.text(age, Ui.MUTED, 9, false)); return r;
    }

    private LinearLayout buildFarmingTab() {
        LinearLayout c = new LinearLayout(getContext()); c.setOrientation(LinearLayout.VERTICAL);
        Config cfg = new Config(getContext());
        LinearLayout field = makeCard(); field.addView(ui.text("🌿  Farming Settings", Ui.TEXT, 14, true));
        Button pick = ui.secondary("Field: " + cfg.field + "  ›");
        pick.setOnClickListener(v -> { int current=0; for(int i=0;i<FieldRoutes.NAMES.length;i++) if(FieldRoutes.NAMES[i].equals(cfg.field)){current=i;break;} String name=FieldRoutes.NAMES[(current+1)%FieldRoutes.NAMES.length]; FieldPresets.apply(cfg,name); cfg.save(); showTab(1); });
        field.addView(pick, ui.full(5));
        field.addView(ui.toggle("Auto Farm", macro.isRunning() || cfg.runMinutes != 0, on -> { if(on) macro.start(); else macro.stop(); }), ui.full(2));
        field.addView(ui.slider("Farm time", 0, 180, 5, Math.max(0,Math.min(180,cfg.runMinutes)), v -> v==0?"Infinite":v+" min", v -> { cfg.runMinutes=v; cfg.save(); }), ui.full(2));
        field.addView(ui.slider("Bag full threshold", 50, 100, 5, Math.max(50,Math.min(100,cfg.fullPercent)), v -> v+"%", v -> { cfg.fullPercent=v; cfg.save(); }), ui.full(2));
        field.addView(ui.chips(new String[]{"Snake","Spiral","Random"}, cfg.pattern.equals("Spiral")?1:cfg.pattern.equals("Random")?2:0, v -> { cfg.pattern=new String[]{"Snake","Spiral","Random"}[v]; cfg.save(); }), ui.full(2));
        c.addView(field, ui.full(8));
        LinearLayout move=makeCard(); move.addView(ui.text("Movement",Ui.TEXT,14,true)); move.addView(ui.slider("Move speed",20,80,1,Math.max(20,Math.min(80,(int)cfg.moveSpeed)),v->v+" studs/s",v->{cfg.moveSpeed=v;cfg.save();}),ui.full(2)); move.addView(ui.toggle("Walk before farming",cfg.walkFirst,v->{cfg.walkFirst=v;cfg.save();}),ui.full(2)); move.addView(ui.toggle("Return to field after conversion",cfg.returnToField,v->{cfg.returnToField=v;cfg.save();}),ui.full(2)); c.addView(move,ui.full(0));
        return c;
    }
    private LinearLayout buildQuestsTab() {
        LinearLayout c=new LinearLayout(getContext()); c.setOrientation(LinearLayout.VERTICAL); Config cfg=new Config(getContext());
        LinearLayout card=makeCard(); card.addView(ui.text("🏆  Quest Automation",Ui.TEXT,14,true));
        card.addView(ui.toggle("Smart quests",cfg.questSmart,v->{cfg.questSmart=v;cfg.save();}),ui.full(2));
        card.addView(ui.slider("Quest check interval",0,120,5,Math.max(0,Math.min(120,cfg.questMinutes)),v->v==0?"Off":v+" min",v->{cfg.questMinutes=v;cfg.save();}),ui.full(2));
        card.addView(makeSmallBtn("Run saved quest taps",v->macro.runSavedTaps("quest",800)),ui.full(2));
        card.addView(ui.body("Saved quest/NPC taps are the same tap sequences configured in the main app."),ui.full(2)); c.addView(card,ui.full(8));
        LinearLayout npc=makeCard(); npc.addView(ui.text("Quest Setup",Ui.TEXT,14,true)); npc.addView(ui.body("Quest turn-in: "+cfg.questTaps().size()+" taps  •  NPC next quest: "+cfg.questNpcTaps().size()+" taps")); c.addView(npc,ui.full(0)); return c;
    }
    private LinearLayout buildInventoryTab() {
        LinearLayout c=new LinearLayout(getContext()); c.setOrientation(LinearLayout.VERTICAL); Config cfg=new Config(getContext());
        LinearLayout card=makeCard(); card.addView(ui.text("📦  Inventory",Ui.TEXT,14,true)); bagText=ui.text(macro.getBagLine(),Ui.BLUE_LIGHT,15,true); card.addView(bagText); card.addView(ui.body("Live bag telemetry comes from the connected accessibility macro."),ui.full(4));
        card.addView(ui.slider("Convert threshold",50,100,5,Math.max(50,Math.min(100,cfg.fullPercent)),v->v+"%",v->{cfg.fullPercent=v;cfg.save();}),ui.full(2));
        card.addView(ui.chips(new String[]{"Stop","Convert at hive","Keep going"},Math.max(0,Math.min(2,cfg.fullAction)),v->{cfg.fullAction=v;cfg.save();}),ui.full(2));
        c.addView(card,ui.full(8)); return c;
    }

    private LinearLayout buildAiTab() {
        Context app = getContext(); boolean enabled = AiControlHub.isEnabled(app); LinearLayout c = new LinearLayout(getContext()); c.setOrientation(LinearLayout.VERTICAL);
        LinearLayout s = makeCard(); s.addView(ui.text("✦  HiveMine AI", Ui.TEXT, 14, true)); String state = !macro.isConnected() ? "not connected" : (macro.isRunning() ? "running" : "ready"); s.addView(ui.body("AI control: " + (enabled ? "ON" : "OFF") + "  •  Macro: " + state)); c.addView(s, ui.full(8));
        c.addView(makeActionBtn(enabled ? "Turn AI control OFF" : "Turn AI control ON", enabled ? 0xFF18212D : Ui.BLUE_GLOW, v -> { AiControlHub.setEnabled(app, !enabled); showTab(5); }), ui.full(8));
        LinearLayout actions = new LinearLayout(getContext()); actions.setOrientation(LinearLayout.HORIZONTAL); actions.addView(makeActionBtn("Start", Ui.BLUE_GLOW, v -> showBridgeCommand(com.hiveminemobile.ai.android.AndroidMacroCommunicationBridge.Command.START)), weight(1)); actions.addView(makeActionBtn("Recover", Ui.BLUE_DARK, v -> showBridgeCommand(com.hiveminemobile.ai.android.AndroidMacroCommunicationBridge.Command.RECOVER)), weight(1)); actions.addView(makeActionBtn("Stop", 0xFF3A1A1A, v -> showBridgeCommand(com.hiveminemobile.ai.android.AndroidMacroCommunicationBridge.Command.STOP)), weight(1)); c.addView(actions, ui.full(8));
        LinearLayout cmd = makeCard(); cmd.addView(ui.text("AI Command Center", Ui.TEXT, 13, true)); EditText input = new EditText(getContext()); input.setHint("Tell HiveMine AI what you want to do..."); input.setTextColor(Ui.TEXT); input.setHintTextColor(Ui.MUTED); input.setMinLines(2); input.setBackgroundColor(0x00111111); cmd.addView(input, ui.full(4)); LinearLayout cb = new LinearLayout(getContext()); cb.setOrientation(LinearLayout.HORIZONTAL); cb.addView(makeActionBtn("Plan", Ui.BLUE_DARK, v -> runAiCommand(input.getText().toString(), false)), weight(1)); cb.addView(makeActionBtn("Apply", Ui.BLUE_GLOW, v -> runAiCommand(input.getText().toString(), true)), weight(1)); cmd.addView(cb); c.addView(cmd, ui.full(8)); aiResultText = ui.body("Ready."); c.addView(aiResultText, ui.full(8));
        LinearLayout log = makeCard(); log.addView(ui.text("Recent AI decisions", Ui.TEXT, 13, true));
        java.util.List<String> trail = AiControlHub.controller(app).getAuditTrail();
        if (trail.isEmpty()) log.addView(ui.body("None yet."));
        for (int i = trail.size() - 1; i >= Math.max(0, trail.size() - 6); i--) log.addView(ui.body(trail.get(i)));
        c.addView(log, ui.full(0));
        return c;
    }

    private void runAiCommand(String text, boolean apply) { if (text == null || text.trim().isEmpty()) { if (aiResultText != null) aiResultText.setText("Enter an AI command first."); return; } com.hiveminemobile.ai.ui.chat.AiManagerService ai = AiControlHub.manager(getContext()); String result = ai.handle(text, AiControlHub.managerState(getContext()), apply, apply); showTab(5); if (aiResultText != null) aiResultText.setText(result); }
    private void showBridgeCommand(com.hiveminemobile.ai.android.AndroidMacroCommunicationBridge.Command command) { com.hiveminemobile.ai.android.AndroidMacroCommunicationBridge.Request r = AiControlHub.bridge(getContext()).send(command, System.currentTimeMillis()); showTab(5); if (aiResultText == null) return; if (r == null) aiResultText.setText("That command is already pending; waiting for live status."); else aiResultText.setText(AiStatusMessages.forDecision(r.decision) + ((r.status() == com.hiveminemobile.ai.android.AndroidMacroCommunicationBridge.Status.ACCEPTED || r.status() == com.hiveminemobile.ai.android.AndroidMacroCommunicationBridge.Status.EXECUTING) ? " Tracking " + r.id + "." : "")); }

    private LinearLayout buildSettingsTab() {
        LinearLayout c=new LinearLayout(getContext()); c.setOrientation(LinearLayout.VERTICAL); Config cfg=new Config(getContext());
        LinearLayout card=makeCard(); card.addView(ui.text("⚙  HiveMine Settings",Ui.TEXT,14,true));
        card.addView(ui.label("Overlay Transparency")); SeekBar seek=new SeekBar(getContext()); seek.setMax(100); seek.setProgress((int)(settings.getTransparency()*100)); seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean f){if(f){settings.setTransparency(Math.max(.45f,p/100f));rootCard.setAlpha(settings.getTransparency());}}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}}); card.addView(seek);
        card.addView(ui.toggle("Humanized mode",cfg.humanMode,v->{cfg.humanMode=v;cfg.save();}),ui.full(2));
        card.addView(ui.toggle("Watch Roblox / auto rejoin",cfg.watchRoblox,v->{cfg.watchRoblox=v;cfg.save();}),ui.full(2));
        card.addView(ui.toggle("Return to field after conversion",cfg.returnToField,v->{cfg.returnToField=v;cfg.save();}),ui.full(2));
        card.addView(ui.slider("Rejoin wait",20,180,5,Math.max(20,Math.min(180,cfg.rejoinSec)),v->v+" s",v->{cfg.rejoinSec=v;cfg.save();}),ui.full(2));
        Button reset=ui.secondary("Reset Floating Panel Position"); reset.setOnClickListener(v->{settings.resetPositions();if(listener!=null)listener.onMinimize();}); card.addView(reset,ui.full(2));
        Button open=ui.secondary("Open Full HiveMine Settings"); open.setOnClickListener(v->{Context app=getContext(); app.startActivity(new Intent(app,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}); card.addView(open,ui.full(0));
        c.addView(card,ui.full(8));
        LinearLayout tools=makeCard(); tools.addView(ui.text("Tools",Ui.TEXT,14,true)); tools.addView(makeSmallBtn("Show Main App",v->{Context app=getContext();app.startActivity(new Intent(app,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}),ui.full(2)); tools.addView(makeSmallBtn("Hide Floating Interface",v->{if(listener!=null)listener.onClose();}),ui.full(2)); c.addView(tools,ui.full(0)); return c;
    }

    private LinearLayout buildFooter() {
        LinearLayout f = new LinearLayout(getContext()); f.setOrientation(LinearLayout.HORIZONTAL); f.setGravity(Gravity.CENTER_VERTICAL); f.setPadding(0, ui.dp(8), 0, 0);
        footerStatus = ui.text("●  Ready", Ui.BLUE_LIGHT, 10, true); f.addView(footerStatus, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f)); f.addView(ui.text("↔  Drag to move", Ui.MUTED, 10, false)); return f;
    }

    private LinearLayout makeCard() { LinearLayout c=new LinearLayout(getContext()); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(ui.dp(12),ui.dp(10),ui.dp(12),ui.dp(10)); GradientDrawable g=new GradientDrawable(); g.setColor(0xE8101722); g.setCornerRadius(ui.dp(16)); g.setStroke(ui.dp(1),0x663B82F6); c.setBackground(g); return c; }
    private Button makeActionBtn(String label,int color,View.OnClickListener click){ Button b=new Button(getContext()); b.setText(label); b.setAllCaps(false); b.setTextSize(11); b.setTextColor(Ui.TEXT); b.setTypeface(null,Typeface.BOLD); b.setMinHeight(ui.dp(48)); b.setMinimumHeight(ui.dp(48)); b.setPadding(ui.dp(3),ui.dp(5),ui.dp(3),ui.dp(5)); GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(ui.dp(14)); g.setStroke(ui.dp(1),0x663B82F6); b.setBackground(g); b.setOnClickListener(click); return b; }
    private Button makeSmallBtn(String label,View.OnClickListener click){Button b=new Button(getContext());b.setText(label);b.setAllCaps(false);b.setTextSize(10);b.setTextColor(Ui.TEXT);b.setMinHeight(ui.dp(38));b.setMinimumHeight(ui.dp(38));b.setPadding(ui.dp(6),ui.dp(4),ui.dp(6),ui.dp(4));GradientDrawable g=new GradientDrawable();g.setColor(0xFF111D2C);g.setCornerRadius(ui.dp(11));g.setStroke(ui.dp(1),0x553B82F6);b.setBackground(g);b.setOnClickListener(click);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.WRAP_CONTENT);p.setMargins(0,ui.dp(3),0,ui.dp(3));b.setLayoutParams(p);return b;}
    private LinearLayout.LayoutParams weight(float w){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,LayoutParams.WRAP_CONTENT,w);p.setMargins(ui.dp(3),0,ui.dp(3),0);return p;}

    private boolean onDragTouch(View v, MotionEvent e){ if(lp==null)return false; switch(e.getActionMasked()){case MotionEvent.ACTION_DOWN:downRawX=e.getRawX();downRawY=e.getRawY();startX=lp.x;startY=lp.y;moved=false;return true;case MotionEvent.ACTION_MOVE:float dx=e.getRawX()-downRawX,dy=e.getRawY()-downRawY;if(Math.abs(dx)>ui.dp(6)||Math.abs(dy)>ui.dp(6))moved=true;if(moved){lp.x=startX+(int)dx;lp.y=startY+(int)dy;try{WindowManager wm=(WindowManager)getContext().getSystemService(Context.WINDOW_SERVICE);if(wm!=null)wm.updateViewLayout(this,lp);}catch(Exception ignored){}}return true;case MotionEvent.ACTION_UP:if(moved){settings.setPanelPos(lp.x,lp.y);if(listener!=null)listener.onDragEnd(lp.x,lp.y);}return true;default:return false;} }

    private void tickStatus(){boolean running=macro.isRunning(); boolean paused=macro.isPaused();if(statusTitle!=null){statusTitle.setText(paused?"Paused":(running?"Running":"Ready"));statusTitle.setTextColor((running||paused)?Ui.BLUE_LIGHT:Ui.TEXT);}if(statusSub!=null)statusSub.setText(macro.getStatus());if(bagText!=null)bagText.setText(macro.getBagLine());if(runtimeText!=null){if(running || paused){if(startMs==0)startMs=System.currentTimeMillis();long sec=(System.currentTimeMillis()-startMs)/1000;runtimeText.setText(String.format("%02d:%02d:%02d",sec/3600,(sec%3600)/60,sec%60));}else{startMs=0;runtimeText.setText("00:00:00");}}if(footerStatus!=null)footerStatus.setText(paused?"●  Macro paused":(running?"●  Macro active":"●  Ready"));if(tickerRunning)handler.postDelayed(statusTicker,1000);}
    public void startTicker(){if(tickerRunning)return;tickerRunning=true;handler.post(statusTicker);} public void stopTicker(){tickerRunning=false;handler.removeCallbacks(statusTicker);} public void refresh(){tickStatus();}
}
