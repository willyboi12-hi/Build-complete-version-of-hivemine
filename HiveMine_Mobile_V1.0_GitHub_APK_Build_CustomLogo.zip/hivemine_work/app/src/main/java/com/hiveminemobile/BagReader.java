package com.hiveminemobile;

// Pollen-bag percentage from one pixel of the in-game bar, ported from HiveMine Macro v1.1.2
// (submacros/background.ahk, nm_backpackPercent), GNU GPL v3. The bar's color at its left end
// changes with how full the bag is. Pure Java so it can be tested on its own.

import java.util.ArrayDeque;

public final class BagReader {
    private BagReader() {}

    /** @param rgb pixel color as 0xRRGGBB (alpha ignored). Returns 0-100 in steps of 5, 0 if unrecognized. */
    public static int percentFromColor(int rgb) {
        int c = rgb & 0xFFFFFF;
        int p;
	p = 0;

	if (((c & 0xFF0000) <= 0x690000)) { // less or equal to 50%
		if ((c & 0xFF0000) <= 0x4B0000) { // less or equal to 25%
			if ((c & 0xFF0000) <= 0x420000) { // less or equal to 10%
				if (((c & 0xFF0000) <= 0x410000) && ((c & 0x00FFFF) <= 0x00FF80) && ((c & 0x00FFFF) > 0x00FF86)) { // less or equal to 5%
					p = 0;
				} else if (((c & 0xFF0000) > 0x410000) && ((c & 0x00FFFF) <= 0x00FF80) && ((c & 0x00FFFF) > 0x00FC85)) { // greater than 5%
					p = 5;
				} else {
					p = 0;
				}
			} else { // greater than 10%
				if (((c & 0xFF0000) <= 0x470000)) { // less or equal to 20%
					if (((c & 0xFF0000) <= 0x440000) && ((c & 0x00FFFF) <= 0x00FE85) && ((c & 0x00FFFF) > 0x00F984)) { // less or equal to 15%
						p = 10;
					} else if (((c & 0xFF0000) > 0x440000) && ((c & 0x00FFFF) <= 0x00FB84) && ((c & 0x00FFFF) > 0x00F582)) { // greater than 15%
						p = 15;
					} else {
						p = 0;
					}
				} else if (((c & 0xFF0000) > 0x470000) && ((c & 0x00FFFF) <= 0x00F782) && ((c & 0x00FFFF) > 0x00F080)) { // greater than 20%
					p = 20;
				} else {
					p = 0;
				}
			}
		} else { // greater than 25%
			if ((c & 0xFF0000) <= 0x5B0000) { // less or equal to 40%
				if (((c & 0xFF0000) <= 0x4F0000) && ((c & 0x00FFFF) <= 0x00F280) && ((c & 0x00FFFF) > 0x00EA7D)) { // less or equal to 30%
					p = 25;
				} else { // greater than 30%
					if (((c & 0xFF0000) <= 0x550000) && ((c & 0x00FFFF) <= 0x00EC7D) && ((c & 0x00FFFF) > 0x00E37A)) { // less or equal to 35%
						p = 30;
					} else if (((c & 0xFF0000) > 0x550000) && ((c & 0x00FFFF) <= 0x00E57A) && ((c & 0x00FFFF) > 0x00DA76)) { // greater than 35%
						p = 35;
					} else {
						p = 0;
					}
				}
			} else { // greater than 40%
				if (((c & 0xFF0000) <= 0x620000) && ((c & 0x00FFFF) <= 0x00DC76) && ((c & 0x00FFFF) > 0x00D072)) { // less or equal to 45%
					p = 40;
				} else if (((c & 0xFF0000) > 0x620000) && ((c & 0x00FFFF) <= 0x00D272) && ((c & 0x00FFFF) > 0x00C66D)) { // greater than 45%
					p = 45;
				} else {
					p = 0;
				}
			}
		}
	} else { // greater than 50%
		if ((c & 0xFF0000) <= 0x9C0000) { // less or equal to 75%
			if ((c & 0xFF0000) <= 0x850000) { // less or equal to 65%
				if ((c & 0xFF0000) <= 0x7B0000) { // less or equal to 60%
					if (((c & 0xFF0000) <= 0x720000) && ((c & 0x00FFFF) <= 0x00C86D) && ((c & 0x00FFFF) > 0x00BA68)) { // less or equal to 55%
						p = 50;
					} else if (((c & 0xFF0000) > 0x720000) && ((c & 0x00FFFF) <= 0x00BC68) && ((c & 0x00FFFF) > 0x00AD62)) { // greater than 55%
						p = 55;
					} else {
						p = 0;
					}
				} else if (((c & 0xFF0000) > 0x7B0000) && ((c & 0x00FFFF) <= 0x00AF62) && ((c & 0x00FFFF) > 0x009E5C)) { // greater than 60%
					p = 60;
				} else {
					p = 0;
				}
			} else { // greater than 65%
				if (((c & 0xFF0000) <= 0x900000) && ((c & 0x00FFFF) <= 0x00A05C) && ((c & 0x00FFFF) > 0x008F55)) { // less or equal to 70%
					p = 65;
				} else if (((c & 0xFF0000) > 0x900000) && ((c & 0x00FFFF) <= 0x009155) && ((c & 0x00FFFF) > 0x007E4E)) { // greater than 70%
					p = 70;
				} else {
					p = 0;
				}
			}
		} else { // greater than 75%
			if (((c & 0xFF0000) <= 0xC40000)) { // less or equal to 90%
				if (((c & 0xFF0000) <= 0xA90000) && ((c & 0x00FFFF) <= 0x00804E) && ((c & 0x00FFFF) > 0x006C46)) { // less or equal to 80%
					p = 75;
				} else { // greater than 80%
					if (((c & 0xFF0000) <= 0xB60000) && ((c & 0x00FFFF) <= 0x006E46) && ((c & 0x00FFFF) > 0x005A3F)) { // less or equal to 85%
						p = 80;
					} else if (((c & 0xFF0000) > 0xB60000) && ((c & 0x00FFFF) <= 0x005D3F) && ((c & 0x00FFFF) > 0x004637)) { // greater than 85%
						p = 85;
					} else {
						p = 0;
					}
				}
			} else { // greater than 90%
				if (((c & 0xFF0000) <= 0xD30000) && ((c & 0x00FFFF) <= 0x004A37) && ((c & 0x00FFFF) > 0x00322E)) { // less or equal to 95%
					p = 90;
				} else { // greater than 95%
					if ((c == 0xF70017) || (((c & 0xFF0000) >= 0xE00000) && ((c & 0x00FFFF) <= 0x002427) && ((c & 0x00FFFF) > 0x001000))) { // is equal to 100%
						p = 100;
					} else if (((c & 0x00FFFF) <= 0x00342E)){
						p = 95;
					} else {
						p = 0;
					}
				}
			}
		}
	}
        return p;
    }

    /** Rolling average of the last few readings, like HiveMine's 6-sample filter. */
    public static final class Filter {
        private final ArrayDeque<Integer> samples = new ArrayDeque<Integer>();
        private final int size;
        public Filter(int size) { this.size = Math.max(1, size); }
        public int add(int percent) {
            samples.addFirst(percent);
            while (samples.size() > size) samples.removeLast();
            int sum = 0;
            for (int v : samples) sum += v;
            return Math.round((float) sum / samples.size());
        }
        public void clear() { samples.clear(); }
    }
}
