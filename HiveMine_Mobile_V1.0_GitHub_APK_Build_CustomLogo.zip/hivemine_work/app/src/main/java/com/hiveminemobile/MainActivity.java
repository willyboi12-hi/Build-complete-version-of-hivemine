package com.hiveminemobile;

import android.app.Activity;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Typeface;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String[][] PATTERN_INFO = {
        {"Snake", "Zig-zag rows across the field. A good all-round choice."},
        {"Lines", "Straight back-and-forth rows."},
        {"Squares", "Nested squares around one spot."},
        {"Diamonds", "Nested diamonds around one spot."},
        {"Slimline", "A narrow path."},
        {"XSnake", "A longer crisscross path."},
        {"Fork", "A forked path. Best when facing a field corner (Advanced)."},
        {"Auryn", "Looping circles and flips, growing with each repeat."},
        {"CornerXSnake", "A snake path that suits field corners."},
        {"SuperCat", "Diagonal sweeps to each side."},
        {"e_lol", "Long rows with diagonal steps."},
        {"Stationary", "Stands still. Useful for testing."}
    };
    private static final String[] SIZE_LABELS = {"Tiny", "Small", "Medium", "Large", "Huge"};

    private Ui ui;
    private Config cfg;
    private ScrollView scroll;
    private LinearLayout page;
    private boolean onAdvanced;

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        if (getActionBar() != null) getActionBar().hide();
        getWindow().setStatusBarColor(Ui.BG);
        ui = new Ui(this);
        scroll = new ScrollView(this);
        scroll.setBackgroundColor(Ui.BG);
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(ui.dp(18), ui.dp(26), ui.dp(18), ui.dp(34));
        scroll.addView(page);
        setContentView(scroll);
    }

    @Override protected void onResume() {
        super.onResume();
        show(onAdvanced, true);
    }

    private MacroAccessibilityService svc() { return MacroAccessibilityService.instance; }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    private void show(boolean advanced, boolean keepScroll) {
        onAdvanced = advanced;
        cfg = new Config(this);
        final int y = keepScroll ? scroll.getScrollY() : 0;
        page.removeAllViews();
        if (advanced) buildAdvanced(); else buildHome();
        scroll.post(new Runnable() { @Override public void run() { scroll.scrollTo(0, y); } });
    }

    // ------------------------------------------------------------ actions

    private void onGo(boolean running) {
        MacroAccessibilityService s = svc();
        if (running) {
            if (s != null) s.stopMacro();
            show(false, true);
            return;
        }
        if (s == null) { toast("Turn on the accessibility service first (Setup, step 1)."); return; }
        // Phase 6: non-fixed start delay so launches are not perfectly periodic
        long startMs = 2200 + (long) (Math.random() * 2000);
        s.startDelayed(startMs);
        moveTaskToBack(true);
    }

    /** Sends the user to Roblox to tap one spot; the tap is captured by an overlay. */
    private void guide(String instruction, String label) {
        MacroAccessibilityService s = svc();
        if (s == null) { toast("Turn on the accessibility service first (Setup, step 1)."); return; }
        s.guidePoint(instruction, label);
        moveTaskToBack(true);
    }

    private void showBubble() {
        MacroAccessibilityService s = svc();
        if (s == null) { toast("Turn on the accessibility service first (Setup, step 1)."); return; }
        s.showBubble();
        show(onAdvanced, true);
    }

    private void hideBubble() {
        MacroAccessibilityService s = svc();
        if (s != null) s.hideBubble();
        show(onAdvanced, true);
    }

    private void testJoystick() {
        MacroAccessibilityService s = svc();
        if (s == null) { toast("Turn on the accessibility service first (Setup, step 1)."); return; }
        if (cfg.joyX <= 0 || cfg.joyY <= 0) { toast("Set the joystick spot first (Setup, step 2)."); return; }
        s.testMove(4000);
        moveTaskToBack(true);
    }

    private void pickField() {
        new android.app.AlertDialog.Builder(this)
            .setTitle("Pick your field")
            .setItems(FieldRoutes.NAMES, (d, which) -> {
                String name = FieldRoutes.NAMES[which];
                FieldPresets.apply(cfg, name);
                FieldPresets.Preset p = FieldPresets.forField(name);
                toast(name + ": " + p.pattern + " " + p.size + " - " + p.note);
                show(false, true);
            })
            .show();
    }

    private void testItemTaps() {
        MacroAccessibilityService s = svc();
        if (s == null) { toast("Turn on the accessibility service first (Setup, step 1)."); return; }
        if (cfg.itemTaps().isEmpty()) { toast("Add the item taps first (Setup, step 7)."); return; }
        s.testItem(4000);
        moveTaskToBack(true);
    }

    private void pickTrip(final int i) {
        new android.app.AlertDialog.Builder(this)
            .setTitle("Pick a trip route")
            .setItems(TripRoutes.NAMES, (d, which) -> {
                cfg.tripRoute[i] = TripRoutes.NAMES[which];
                cfg.save();
                show(true, true);
            })
            .show();
    }

    private void testTripNow(int i) {
        MacroAccessibilityService s = svc();
        if (s == null) { toast("Turn on the accessibility service first (Setup, step 1)."); return; }
        if (cfg.tripRoute[i].isEmpty()) { toast("Pick a route first."); return; }
        s.testTrip(i, 4000);
        moveTaskToBack(true);
    }

    private void walkCheckNow() {
        MacroAccessibilityService s = svc();
        if (s == null) { toast("Turn on the accessibility service first (Setup, step 1)."); return; }
        if (cfg.joyX <= 0 || cfg.joyY <= 0) { toast("Set the joystick spot first (Setup, step 2)."); return; }
        s.walkCheck(4000);
        moveTaskToBack(true);
    }

    private void applyWalkCheck(String text) {
        double observed;
        try {
            observed = Double.parseDouble(text.trim());
        } catch (NumberFormatException e) {
            toast("Enter how many tiles it walked, for example 8.5.");
            return;
        }
        if (observed <= 0) { toast("Enter a distance above zero."); return; }
        float old = cfg.moveSpeed;
        cfg.moveSpeed = Calibration.speedFor(old, Calibration.EXPECTED_TILES, observed);
        cfg.save();
        toast("Walk speed set to " + Math.round(cfg.moveSpeed) + " studs/s (was " + Math.round(old) + ").");
        show(true, true);
    }

    private static String linkMessage(String link) {
        if (link.length() == 0) return "Link cleared.";
        if (RobloxLink.toRobloxUri(link).startsWith("roblox://")) return "Link saved.";
        return "Link saved. It is not a game link with a privateServerLinkCode, so Roblox may not open it directly.";
    }

    private void checkSpotNow() {
        MacroAccessibilityService s = svc();
        if (s == null) { toast("Turn on the accessibility service first (Setup, step 1)."); return; }
        s.checkDisconnectSpot(3000);
        moveTaskToBack(true);
    }

    private void checkPictureNow() {
        MacroAccessibilityService s = svc();
        if (s == null) { toast("Turn on the accessibility service first (Setup, step 1)."); return; }
        s.checkConvertPicture(3000);
        moveTaskToBack(true);
    }

    private void testRejoinNow() {
        MacroAccessibilityService s = svc();
        if (s == null) { toast("Turn on the accessibility service first (Setup, step 1)."); return; }
        s.rejoinNow();
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    private static int indexOf(String[] arr, String s) {
        for (int i = 0; i < arr.length; i++) if (arr[i].equals(s)) return i;
        return 2;
    }

    // ------------------------------------------------------------ home screen

    private void buildHome() {
        MacroAccessibilityService s = svc();
        boolean connected = s != null;
        boolean running = connected && s.isRunning();

        // Full-screen HiveMine dashboard: black + electric blue, with the real
        // macro controller underneath. This is intentionally a native Android
        // UI rather than a mock image.
        page.setPadding(ui.dp(14), ui.dp(18), ui.dp(14), ui.dp(28));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = ui.text("H", Ui.TEXT, 28, true); logo.setGravity(Gravity.CENTER);
        GradientDrawable lg = new GradientDrawable(); lg.setColor(0xFF071A32); lg.setCornerRadius(ui.dp(18)); lg.setStroke(ui.dp(2), Ui.BLUE_LIGHT);
        logo.setBackground(lg); logo.setPadding(ui.dp(13), ui.dp(6), ui.dp(13), ui.dp(6));
        header.addView(logo);
        LinearLayout brand = new LinearLayout(this); brand.setOrientation(LinearLayout.VERTICAL); brand.setPadding(ui.dp(10),0,0,0);
        TextView name = ui.text("HiveMine Mobile", Ui.TEXT, 24, true);
        brand.addView(name); brand.addView(ui.text("V1.0  •  Bee Swarm Automation", Ui.MUTED, 11, false));
        header.addView(brand, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        Button settings = ui.secondary("⚙"); settings.setTextSize(19); settings.setMinHeight(ui.dp(46));
        settings.setOnClickListener(v -> show(true, false)); header.addView(settings);
        page.addView(header, ui.full(12));

        LinearLayout nav = new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL);
        String[] tabs = {"⌂  Home","◈  Farming","★  Quests","□  Inventory","✦  AI","⚙  Settings"};
        for (int i=0;i<tabs.length;i++) {
            final int idx=i; Button b=ui.button(tabs[i], i==0?Ui.BLUE_GLOW:Ui.CARD_HI, Ui.TEXT); b.setTextSize(11); b.setMinHeight(ui.dp(48));
            b.setOnClickListener(v -> {
                if (idx==0) return;
                if (idx==1) showAdvancedSection("Farming");
                else if (idx==2) showAdvancedSection("Quests");
                else if (idx==3) showAdvancedSection("Inventory");
                else if (idx==4) showAdvancedSection("AI");
                else show(true,false);
            });
            LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f); bp.setMargins(ui.dp(2),0,ui.dp(2),0); nav.addView(b,bp);
        }
        page.addView(nav, ui.full(12));

        LinearLayout status=ui.card();
        LinearLayout statusRow=new LinearLayout(this); statusRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView dot=ui.text(running?"●":"●", running?Ui.BLUE_LIGHT:Ui.MUTED, 25, true); dot.setPadding(0,0,ui.dp(8),0); statusRow.addView(dot);
        LinearLayout st= new LinearLayout(this); st.setOrientation(LinearLayout.VERTICAL); st.setPadding(ui.dp(8),0,0,0);
        st.addView(ui.text("Status", Ui.MUTED, 11, false));
        st.addView(ui.text(running?"Running":(connected?"Ready":"Service Offline"), running?Ui.BLUE_LIGHT:Ui.TEXT, 28, true));
        st.addView(ui.text(running?MacroAccessibilityService.status:"Tap Start to begin automation", Ui.MUTED, 12, false));
        statusRow.addView(st,new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f));
        status.addView(statusRow);
        page.addView(status,ui.full(10));

        LinearLayout stats=ui.card(); stats.setOrientation(LinearLayout.HORIZONTAL);
        addStat(stats,"Runtime",running?"ACTIVE":"00:00:00"); addStat(stats,"Pollen",connected?MacroAccessibilityService.bagLine:"—"); addStat(stats,"Field",cfg.field);
        page.addView(stats,ui.full(10));

        LinearLayout controls=new LinearLayout(this); controls.setOrientation(LinearLayout.HORIZONTAL);
        Button start=ui.primary(running?"Stop":"Start",running?Ui.RED:Ui.BLUE_GLOW);
        start.setOnClickListener(v -> onGo(!running)); controls.addView(start,weight(1));
        Button pause=ui.secondary("Pause"); pause.setOnClickListener(v -> { if(s!=null && s.pauseMacro()){ toast("Automation paused. Tap Resume to continue."); show(false,true); } else toast("Pause is available while farming."); }); controls.addView(pause,weight(1));
        Button resume=ui.primary("Resume",Ui.BLUE_DARK); resume.setOnClickListener(v -> { if(s!=null && s.resumeMacro()){ toast("Automation resumed."); show(true,false); } else if(s!=null && !s.isRunning() && !s.isPaused()){ onGo(false); } else toast("Automation is already running."); }); controls.addView(resume,weight(1));
        Button emergency=ui.primary("⚠  Emergency Stop",0xFF7F1D1D); emergency.setOnClickListener(v -> { if(s!=null)s.stopMacro(); toast("Emergency stop sent."); show(false,true); }); controls.addView(emergency,weight(1));
        page.addView(controls,ui.full(10));

        LinearLayout two=new LinearLayout(this); two.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout farming=ui.card(); farming.addView(ui.text("🌿  Farming Settings",Ui.TEXT,16,true));
        farming.addView(ui.text("Field",Ui.MUTED,11,false));
        Button field=ui.secondary(cfg.field); field.setOnClickListener(v->pickField()); farming.addView(field,ui.full(5));
        farming.addView(ui.toggle("Auto Farm",cfg.autoFarm,on->{cfg.autoFarm=on;cfg.save();}));
        farming.addView(ui.body("Pattern: "+FieldPresets.forField(cfg.field).pattern+"  •  Size: "+FieldPresets.forField(cfg.field).size));
        two.addView(farming,weight(1));

        LinearLayout quick=ui.card(); quick.addView(ui.text("★  Quick Actions",Ui.TEXT,16,true));
        Button quests=ui.secondary("🏆  Auto Quests"); quests.setOnClickListener(v->runConfiguredTaps("quest", "Quest")); quick.addView(quests,ui.full(4));
        Button gifts=ui.secondary("🎁  Collect Gifts"); gifts.setOnClickListener(v->runConfiguredTaps("item", "Gift/item")); quick.addView(gifts,ui.full(4));
        Button teleport=ui.secondary("⌖  Guide / Teleport"); teleport.setOnClickListener(v->guide("Tap the destination/teleport spot in Roblox.","teleport")); quick.addView(teleport,ui.full(4));
        Button reset=ui.secondary("↻  Reset Character"); reset.setOnClickListener(v->runConfiguredTaps("reset", "Reset")); quick.addView(reset,ui.full(0));
        two.addView(quick,weight(1)); page.addView(two,ui.full(10));

        LinearLayout activity=ui.card();
        LinearLayout ah=new LinearLayout(this); ah.setGravity(Gravity.CENTER_VERTICAL); ah.addView(ui.text("Recent Activity",Ui.TEXT,16,true),new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f));
        Button log=ui.secondary("View Log →"); log.setOnClickListener(v->showActivityDialog()); ah.addView(log); activity.addView(ah,ui.full(5));
        activity.addView(activityRow(running?"Automation running in "+cfg.field:"Ready to farm",running?"now":"—"));
        activity.addView(activityRow(connected?MacroAccessibilityService.bagLine:"Macro service not connected",connected?"live":"setup"));
        activity.addView(activityRow("AI Manager available",AiControlHub.isEnabled(this)?"enabled":"disabled"));
        page.addView(activity,ui.full(10));

        LinearLayout ai=ui.card();
        LinearLayout aiHead=new LinearLayout(this); aiHead.setGravity(Gravity.CENTER_VERTICAL); aiHead.addView(ui.text("✦  AI Manager",Ui.TEXT,16,true),new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f)); aiHead.addView(ui.text(AiControlHub.isEnabled(this)?"● AI Ready":"● AI Off",AiControlHub.isEnabled(this)?Ui.BLUE_LIGHT:Ui.MUTED,12,true)); ai.addView(aiHead);
        ai.addView(ui.body("Smart automation, recovery monitoring, planning and natural-language control."),ui.full(6));
        Button aiOpen=ui.primary("Open AI Command Center",Ui.BLUE_DARK); aiOpen.setOnClickListener(v->showAdvancedSection("AI")); ai.addView(aiOpen);
        page.addView(ai,ui.full(12));

        LinearLayout footer=ui.card(); footer.addView(ui.text("Overlay",Ui.TEXT,13,true)); footer.addView(ui.body("Use the floating HiveMine control from Roblox. Buttons use the same live macro controller as this app."));
        Button overlay=ui.primary("Open Floating Interface",Ui.BLUE_GLOW); overlay.setOnClickListener(v->showBubble()); footer.addView(overlay,ui.full(4));
        Button hide=ui.secondary("Hide Floating Interface"); hide.setOnClickListener(v->hideBubble()); footer.addView(hide); page.addView(footer,ui.full(0));
    }

    private LinearLayout.LayoutParams weight(float w){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,w); p.setMargins(ui.dp(3),0,ui.dp(3),0); return p; }
    private void addStat(LinearLayout parent,String name,String value){ LinearLayout c=new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(ui.dp(5),0,ui.dp(5),0); c.addView(ui.text(name,Ui.MUTED,10,false)); c.addView(ui.text(value,Ui.BLUE_LIGHT,14,true)); parent.addView(c,new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f)); }
    private LinearLayout activityRow(String event,String age){ LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL); r.addView(ui.text("●",Ui.BLUE_LIGHT,12,true)); r.addView(ui.text("  "+event,Ui.TEXT,11,false),new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f)); r.addView(ui.text(age,Ui.MUTED,10,false)); return r; }
    private void showActivityDialog(){ new android.app.AlertDialog.Builder(this).setTitle("HiveMine Activity").setMessage("Live macro events are stored by the AI memory system.\n\n"+(MacroAccessibilityService.status==null?"Ready":MacroAccessibilityService.status)+"\n"+MacroAccessibilityService.bagLine).setPositiveButton("Close",null).show(); }
    private void showAdvancedSection(String section){ show(true,false); Toast.makeText(this,section+" controls are available in Advanced.",Toast.LENGTH_SHORT).show(); }
    private void runConfiguredTaps(String kind,String label){ MacroAccessibilityService s=svc(); if(s==null){toast("Turn on the accessibility service first (Setup, step 1).");return;} java.util.List<int[]> taps = "quest".equals(kind)?cfg.questTaps():"item".equals(kind)?cfg.itemTaps():cfg.resetTaps(); if(taps.isEmpty()){toast("Add "+label.toLowerCase()+" taps in Advanced first.");return;} s.runSavedTapsNow(taps, label, 800); toast(label+" sequence started."); }

    private void buildAdvanced() {
        Button back = ui.secondary("Back");
        back.setOnClickListener(v -> show(false, false));
        page.addView(back, ui.full(12));
        page.addView(ui.title("Advanced"), ui.full(12));

        LinearLayout move = ui.card();
        move.addView(ui.heading("Movement"), ui.full(6));
        move.addView(ui.slider("Walk speed", 10, 60, 1, clamp(Math.round(cfg.moveSpeed), 10, 60),
            v -> v + " studs/s",
            v -> { cfg.moveSpeed = v; cfg.save(); }), ui.full(0));
        move.addView(ui.slider("Thumb distance", 40, 200, 10, clamp(cfg.radius, 40, 200),
            v -> v + " px",
            v -> { cfg.radius = v; cfg.save(); }), ui.full(0));
        Button walkChk = ui.secondary("Walk speed check: walk 10 tiles (switch to Roblox)");
        walkChk.setOnClickListener(v -> walkCheckNow());
        move.addView(walkChk, ui.full(8));
        EditText walked = new EditText(this);
        walked.setHint("Tiles it really walked, e.g. 8.5");
        walked.setSingleLine(true);
        walked.setTextColor(Ui.TEXT);
        walked.setHintTextColor(Ui.MUTED);
        move.addView(walked, ui.full(8));
        Button applyWalk = ui.secondary("Set walk speed from that distance");
        applyWalk.setOnClickListener(v -> applyWalkCheck(walked.getText().toString()));
        move.addView(applyWalk, ui.full(8));
        move.addView(ui.toggle("Flip forward and back", cfg.invFB, v -> { cfg.invFB = v; cfg.save(); }), ui.full(0));
        move.addView(ui.toggle("Flip left and right", cfg.invLR, v -> { cfg.invLR = v; cfg.save(); }), ui.full(0));
        move.addView(ui.toggle("Facing a field corner (for Fork)", cfg.facingCorner,
            v -> { cfg.facingCorner = v; cfg.save(); }), ui.full(0));
        page.addView(move, ui.full(14));

        LinearLayout cam = ui.card();
        cam.addView(ui.heading("Camera"), ui.full(6));
        cam.addView(ui.slider("Camera turns before start", -4, 4, 1, clamp(cfg.rotateSwipes, -4, 4),
            v -> v == 0 ? "None" : (v > 0 ? "Right " : "Left ") + Math.abs(v),
            v -> { cfg.rotateSwipes = v; cfg.save(); }), ui.full(0));
        cam.addView(ui.slider("Camera swipe length", 100, 600, 25, clamp(cfg.swipeLen, 100, 600),
            v -> v + " px",
            v -> { cfg.swipeLen = v; cfg.save(); }), ui.full(0));
        page.addView(cam, ui.full(14));

        LinearLayout conv = ui.card();
        conv.addView(ui.heading("Convert"), ui.full(6));
        conv.addView(ui.slider("Hive slot", 1, 6, 1, clamp(cfg.hiveSlot, 1, 6),
            v -> "Slot " + v,
            v -> { cfg.hiveSlot = v; cfg.save(); }), ui.full(0));
        conv.addView(ui.slider("Wait after reset", 1, 30, 1, clamp(cfg.respawnWait, 1, 30),
            v -> v + " s",
            v -> { cfg.respawnWait = v; cfg.save(); }), ui.full(0));
        Button clear = ui.secondary("Clear reset steps (" + cfg.resetTaps().size() + ")");
        clear.setOnClickListener(v -> {
            cfg.resetSteps = "";
            cfg.save();
            toast("Reset steps cleared.");
            show(true, true);
        });
        conv.addView(clear, ui.full(0));
        page.addView(conv, ui.full(14));

        LinearLayout tripCard = ui.card();
        tripCard.addView(ui.heading("Trips from the hive (optional)"), ui.full(6));
        tripCard.addView(ui.body("After a convert, a trip that is due walks to a building, taps your saved spots, walks back, then goes to your field. Routes come from HiveMine's collect paths. Three HiveMine routes that need its cannon are left out."), ui.full(8));
        tripCard.addView(ui.slider("Bees in hive (some routes check this)", 1, 50, 1, clamp(cfg.hiveBees, 1, 50),
            v -> v + " bees",
            v -> { cfg.hiveBees = v; cfg.save(); }), ui.full(8));
        for (int i = 0; i < 2; i++) {
            final int slot = i;
            tripCard.addView(ui.label("Trip " + (i + 1)), ui.full(6));
            Button trpPick = ui.secondary(cfg.tripRoute[i].isEmpty() ? "Pick a route" : cfg.tripRoute[i]);
            trpPick.setOnClickListener(v -> pickTrip(slot));
            tripCard.addView(trpPick, ui.full(8));
            tripCard.addView(ui.slider("Every", 0, 180, 5, clamp(cfg.tripMinutes[i], 0, 180),
                v -> v == 0 ? "Off" : v + " min",
                v -> { cfg.tripMinutes[slot] = v; cfg.save(); }), ui.full(0));
            Button trpRec = ui.secondary("Record destination taps (" + cfg.tripTaps(i).size() + " saved)");
            trpRec.setOnClickListener(v -> guide("Open Roblox at the building. Tap the button that collects or uses it, then press Save here. Add taps in order.", "trip" + slot));
            tripCard.addView(trpRec, ui.full(8));
            Button trpClr = ui.secondary("Clear destination taps");
            trpClr.setOnClickListener(v -> { cfg.tripSteps[slot] = ""; cfg.save(); show(true, true); });
            tripCard.addView(trpClr, ui.full(8));
            Button trpTest = ui.secondary("Test trip " + (i + 1) + " now (switch to Roblox)");
            trpTest.setOnClickListener(v -> testTripNow(slot));
            tripCard.addView(trpTest, ui.full(14));
        }
        page.addView(tripCard, ui.full(14));

        LinearLayout rejoin = ui.card();
        rejoin.addView(ui.heading("Reconnect"), ui.full(6));
        rejoin.addView(ui.body("Paste your private server link. If Roblox disconnects, the app opens it again, waits, then walks back to your field."), ui.full(8));
        EditText link = new EditText(this);
        link.setText(cfg.privateLink);
        link.setHint("Private server link");
        link.setSingleLine(true);
        link.setTextColor(Ui.TEXT);
        link.setHintTextColor(Ui.MUTED);
        rejoin.addView(link, ui.full(8));
        Button saveLink = ui.secondary("Save link");
        saveLink.setOnClickListener(v -> {
            cfg.privateLink = link.getText().toString().trim();
            cfg.save();
            toast(linkMessage(cfg.privateLink));
            show(true, true);
        });
        rejoin.addView(saveLink, ui.full(8));
        rejoin.addView(ui.toggle("Rejoin if Roblox closes or leaves the screen for 8 seconds", cfg.watchRoblox,
            on -> { cfg.watchRoblox = on; cfg.save(); }), ui.full(0));
        rejoin.addView(ui.slider("Wait after rejoining", 20, 180, 5, clamp(cfg.rejoinSec, 20, 180),
            v -> v + " s",
            v -> { cfg.rejoinSec = v; cfg.save(); }), ui.full(0));
        Button testRejoin = ui.secondary("Test rejoin now (start farming first)");
        testRejoin.setOnClickListener(v -> testRejoinNow());
        rejoin.addView(testRejoin, ui.full(0));
        Button checkPic = ui.secondary("Check Make Honey picture (switch to Roblox at the hive)");
        checkPic.setOnClickListener(v -> checkPictureNow());
        rejoin.addView(checkPic, ui.full(0));
        Button checkSpot = ui.secondary("Check disconnect spot (switch to its screen)");
        checkSpot.setOnClickListener(v -> checkSpotNow());
        rejoin.addView(checkSpot, ui.full(0));
        page.addView(rejoin, ui.full(14));

        LinearLayout tools = ui.card();
        tools.addView(ui.heading("Tools"), ui.full(6));
        Button test = ui.primary("Test joystick", Ui.BLUE);
        test.setOnClickListener(v -> testJoystick());
        tools.addView(test, ui.full(6));
        tools.addView(ui.body("Test waits 4 seconds, then walks the thumb right for one second. Switch to Roblox during that time."), ui.full(8));
        Button showB = ui.secondary("Show floating bubble");
        showB.setOnClickListener(v -> showBubble());
        tools.addView(showB, ui.full(8));
        Button hideB = ui.secondary("Hide floating bubble");
        hideB.setOnClickListener(v -> hideBubble());
        tools.addView(hideB, ui.full(8));
        Button itemTest = ui.secondary("Test item taps");
        itemTest.setOnClickListener(v -> testItemTaps());
        tools.addView(itemTest, ui.full(8));
        Button clearItem = ui.secondary("Clear item taps (" + cfg.itemTaps().size() + ")");
        clearItem.setOnClickListener(v -> {
            cfg.itemSteps = "";
            cfg.save();
            toast("Item taps cleared.");
            show(true, true);
        });
        tools.addView(clearItem, ui.full(0));
        Button clearBoost = ui.secondary("Clear booster taps (" + cfg.boosterTaps().size() + ")");
        clearBoost.setOnClickListener(v -> {
            cfg.boosterSteps = "";
            cfg.save();
            toast("Booster taps cleared.");
            show(true, true);
        });
        tools.addView(clearBoost, ui.full(0));
        Button clearPlanter = ui.secondary("Clear planter taps (" + cfg.planterTaps().size() + ")");
        clearPlanter.setOnClickListener(v -> {
            cfg.planterSteps = "";
            cfg.save();
            toast("Planter taps cleared.");
            show(true, true);
        });
        tools.addView(clearPlanter, ui.full(0));
        Button clearQuest = ui.secondary("Clear turn-in taps (" + cfg.questTaps().size() + ")");
        clearQuest.setOnClickListener(v -> {
            cfg.questSteps = "";
            cfg.save();
            toast("Turn-in taps cleared.");
            show(true, true);
        });
        tools.addView(clearQuest, ui.full(0));
        Button clearNpc = ui.secondary("Clear NPC next-quest taps (" + cfg.questNpcTaps().size() + ")");
        clearNpc.setOnClickListener(v -> {
            cfg.questNpcSteps = "";
            cfg.save();
            toast("NPC taps cleared.");
            show(true, true);
        });
        tools.addView(clearNpc, ui.full(0));
        page.addView(tools, ui.full(14));
    }
}
