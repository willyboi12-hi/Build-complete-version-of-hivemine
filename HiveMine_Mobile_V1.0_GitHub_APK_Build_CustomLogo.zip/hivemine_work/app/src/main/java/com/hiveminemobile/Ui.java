package com.hiveminemobile;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

/** Shared look for the app and the floating bubble: dark cards, big rounded buttons, large text. Blue theme. */
public final class Ui {
    // Deep black base
    public static final int BG = 0xFF0A0C10;
    public static final int CARD = 0xFF12161C;
    public static final int CARD_HI = 0xFF1A2230;
    public static final int SURFACE = 0xFF0F1419;
    // Text
    public static final int TEXT = 0xFFF0F4F8;
    public static final int MUTED = 0xFF8B9BB0;
    // Blue family (no green)
    public static final int BLUE = 0xFF3B82F6;
    public static final int BLUE_LIGHT = 0xFF60A5FA;
    public static final int BLUE_DARK = 0xFF1E3A8A;
    public static final int BLUE_NAVY = 0xFF0F2744;
    public static final int BLUE_GLOW = 0xFF2563EB;
    // Status
    public static final int RED = 0xFFEF4444;
    public static final int AMBER = 0xFFF59E0B;
    public static final int GREEN = 0xFF3B82F6; // mapped to blue so old calls still compile
    public static final int SUCCESS = 0xFF3B82F6;

    public interface IntSink { void set(int v); }
    public interface IntFmt { String fmt(int v); }
    public interface BoolSink { void set(boolean v); }

    private final Context c;

    public Ui(Context c) { this.c = c; }

    public int dp(float v) { return Math.round(v * c.getResources().getDisplayMetrics().density); }

    public GradientDrawable box(int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    public LinearLayout.LayoutParams full(int bottomDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(bottomDp);
        return lp;
    }

    public TextView text(String s, int color, float sp, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(sp);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    public TextView title(String s) { return text(s, TEXT, 30, true); }
    public TextView heading(String s) { return text(s, TEXT, 19, true); }
    public TextView body(String s) { return text(s, MUTED, 15, false); }
    public TextView label(String s) { return text(s.toUpperCase(), MUTED, 12, true); }

    public LinearLayout card() {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(14), dp(16), dp(16));
        l.setBackground(box(CARD, 18));
        return l;
    }

    public Button button(String s, int color, int textColor) {
        Button b = new Button(c);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(17);
        b.setTextColor(textColor);
        b.setTypeface(null, Typeface.BOLD);
        b.setBackground(box(color, 14));
        b.setMinHeight(dp(56));
        b.setMinimumHeight(dp(56));
        b.setPadding(dp(16), dp(10), dp(16), dp(10));
        return b;
    }

    public Button primary(String s, int color) { return button(s, color, TEXT); }
    public Button secondary(String s) { return button(s, CARD_HI, TEXT); }

    /** A row of equal-width choices. The tapped one turns blue; the sink gets its index. */
    public LinearLayout chips(final String[] labels, final int selected, final IntSink sink) {
        final Button[] bs = new Button[labels.length];
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < labels.length; i++) {
            Button b = button(labels[i], i == selected ? BLUE : CARD_HI, TEXT);
            b.setTextSize(14);
            b.setMinHeight(dp(48));
            b.setMinimumHeight(dp(48));
            b.setPadding(dp(2), dp(6), dp(2), dp(6));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(dp(3), 0, dp(3), 0);
            row.addView(b, lp);
            bs[i] = b;
        }
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            bs[i].setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    for (int j = 0; j < bs.length; j++) bs[j].setBackground(box(j == idx ? BLUE : CARD_HI, 14));
                    sink.set(idx);
                }
            });
        }
        return row;
    }

    /** Big draggable slider with the current value written above it. */
    public LinearLayout slider(final String name, final int min, final int max, final int step, final int value,
                               final IntFmt fmt, final IntSink sink) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, dp(4), 0, dp(10));
        final TextView label = text(name + ":  " + fmt.fmt(value), TEXT, 16, false);
        SeekBar bar = new SeekBar(c);
        bar.setMax((max - min) / step);
        bar.setProgress((value - min) / step);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                int v = min + p * step;
                label.setText(name + ":  " + fmt.fmt(v));
                if (user) sink.set(v);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        box.addView(label);
        box.addView(bar, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(44)));
        return box;
    }

    public Switch toggle(String text, boolean on, final BoolSink sink) {
        Switch s = new Switch(c);
        s.setText(text);
        s.setTextColor(TEXT);
        s.setTextSize(16);
        s.setPadding(0, dp(8), 0, dp(8));
        s.setChecked(on);
        s.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean checked) { sink.set(checked); }
        });
        return s;
    }

    /** Setup row: what it is, whether it is done, and one big button. */
    public LinearLayout checkRow(String title, String sub, boolean done, String buttonText, View.OnClickListener onClick) {
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(6), 0, dp(6));
        LinearLayout left = new LinearLayout(c);
        left.setOrientation(LinearLayout.VERTICAL);
        left.addView(text(title, TEXT, 16, true));
        left.addView(text(sub, MUTED, 13, false));
        left.addView(text(done ? "Done" : "To do", done ? GREEN : AMBER, 13, true));
        row.addView(left, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        Button b = button(buttonText, done ? CARD_HI : BLUE, TEXT);
        b.setTextSize(15);
        b.setMinHeight(dp(48));
        b.setMinimumHeight(dp(48));
        b.setPadding(dp(14), dp(6), dp(14), dp(6));
        b.setOnClickListener(onClick);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        bp.leftMargin = dp(10);
        row.addView(b, bp);
        return row;
    }

    public void line(LinearLayout parent) {
        View v = new View(c);
        v.setBackgroundColor(CARD_HI);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1));
        lp.setMargins(0, dp(6), 0, dp(6));
        parent.addView(v, lp);
    }
}
