package com.hiveminemobile;

// Gather-pattern geometry ported from HiveMine Macro v1.1.2 (patterns/*.ahk), GNU GPL v3.
// Each pattern is a list of movement segments. One "tile" = 4 studs, same unit as HiveMine's Walk().
// Pure Java (no Android classes) so it can be tested on its own.

import java.util.ArrayList;
import java.util.List;

public final class Patterns {
    private Patterns() {}

    public static final class Seg {
        public final int dx, dy;        // joystick direction on screen: dx -1 left/+1 right, dy -1 forward(up)/+1 back(down)
        public final double tiles;      // distance in tiles (ignored when seconds >= 0)
        public final double seconds;    // fixed wait/hold time, or -1 to use tiles
        public final int rotate;        // camera turn presses: + right, - left, 0 = not a turn
        public Seg(int dx, int dy, double tiles, double seconds) {
            this(dx, dy, tiles, seconds, 0);
        }
        public Seg(int dx, int dy, double tiles, double seconds, int rotate) {
            this.dx = dx; this.dy = dy; this.tiles = tiles; this.seconds = seconds; this.rotate = rotate;
        }
        public double durationMs(double movespeedStudsPerSec) {
            if (seconds >= 0) return seconds * 1000.0;
            return tiles * 4.0 / movespeedStudsPerSec * 1000.0;
        }
        public boolean isWait() { return dx == 0 && dy == 0 && rotate == 0; }
        @Override public String toString() { return "(" + dx + "," + dy + ") " + (seconds >= 0 ? seconds + "s" : tiles + "t"); }
    }

    public static final String[] NAMES = {"Snake", "Lines", "Squares", "Diamonds", "Slimline", "XSnake", "Fork",
        "Auryn", "CornerXSnake", "SuperCat", "e_lol", "Stationary"};
    public static final String[] SIZES = {"XS", "S", "M", "L", "XL"};

    public static double sizeFactor(String s) {
        if ("XS".equals(s)) return 0.25;
        if ("S".equals(s)) return 0.5;
        if ("L".equals(s)) return 1.5;
        if ("XL".equals(s)) return 2.0;
        return 1.0;
    }

    private static final class B {
        final List<Seg> out = new ArrayList<Seg>();
        final int tcLR, tcFB; // screen sign of "toward center" on each axis
        B(boolean invFB, boolean invLR) {
            tcLR = invLR ? 1 : -1;  // TCLR = Left unless inverted
            tcFB = invFB ? 1 : -1;  // TCFB = Forward (up) unless inverted
        }
        // lr / fb: +1 = toward center, -1 = away from center, 0 = none
        void w(int lr, int fb, double tiles) { out.add(new Seg(lr * tcLR, fb * tcFB, tiles, -1)); }
        void pause(double seconds) { out.add(new Seg(0, 0, 0, seconds)); }
    }

    public static List<Seg> build(String name, String sizeName, int reps, boolean invFB, boolean invLR, boolean facingCorner) {
        if (ExtraPatterns.has(name)) {
            PatternBuilder pb = new PatternBuilder(invFB, invLR);
            ExtraPatterns.build(name, pb, sizeFactor(sizeName), Math.max(1, reps), facingCorner);
            return pb.steps();
        }
        double s = sizeFactor(sizeName);
        if (reps < 1) reps = 1;
        B b = new B(invFB, invLR);
        final int TC = 1, AFC = -1;
        if ("Snake".equals(name)) {
            for (int i = 0; i < reps; i++) { b.w(TC, 0, 11 * s); b.w(0, TC, 1); b.w(AFC, 0, 11 * s); b.w(0, TC, 1); }
            for (int i = 0; i < reps; i++) { b.w(TC, 0, 11 * s); b.w(0, AFC, 1); b.w(AFC, 0, 11 * s); b.w(0, AFC, 1); }
        } else if ("Lines".equals(name)) {
            for (int i = 0; i < reps; i++) { b.w(0, TC, 11 * s); b.w(TC, 0, 1); b.w(0, AFC, 11 * s); b.w(TC, 0, 1); }
            for (int i = 0; i < reps; i++) { b.w(0, TC, 11 * s); b.w(AFC, 0, 1); b.w(0, AFC, 11 * s); b.w(AFC, 0, 1); }
        } else if ("Squares".equals(name)) {
            for (int i = 1; i <= reps; i++) {
                double d = 5 * s + i;
                b.w(0, TC, d); b.w(TC, 0, d); b.w(0, AFC, d); b.w(AFC, 0, d);
            }
        } else if ("Diamonds".equals(name)) {
            for (int i = 1; i <= reps; i++) {
                double d = 5 * s + i;
                b.w(TC, TC, d); b.w(AFC, TC, d); b.w(AFC, AFC, d); b.w(TC, AFC, d);
            }
        } else if ("Slimline".equals(name)) {
            b.w(TC, 0, 4 * s + reps * 0.1 - 0.1); b.w(AFC, 0, 8 * s); b.w(TC, 0, 4 * s);
        } else if ("XSnake".equals(name)) {
            for (int i = 0; i < reps; i++) {
                b.w(TC, 0, 4 * s);
                b.w(0, TC, 2 * s);
                b.w(AFC, 0, 8 * s);
                b.w(0, TC, 2 * s);
                b.w(TC, 0, 8 * s);
                b.w(AFC, AFC, Math.sqrt(2 * Math.pow(8 * s, 2)));
                b.w(TC, 0, 8 * s);
                b.w(0, TC, 2 * s);
                b.w(AFC, 0, 8 * s);
                b.w(0, TC, 6.7 * s);
                b.w(TC, 0, 8 * s);
                b.w(0, AFC, 2 * s);
                b.w(AFC, 0, 8 * s);
                b.w(0, AFC, 2 * s);
                b.w(TC, 0, 8 * s);
                b.w(0, AFC, 2 * s);
                b.w(AFC, 0, 8 * s);
                b.w(0, AFC, 3 * s);
                b.w(TC, 0, 8 * s);
                b.w(AFC, TC, Math.sqrt(2 * Math.pow(4 * s, 2)));
            }
        } else if ("Fork".equals(name)) {
            double gap = 0.75, diag = gap * Math.sqrt(2);
            double len = (40 - gap * 16 - diag * 4) / 6;
            if (facingCorner) out(b, 0, -1, 1.5); // absolute forward, not "toward center"
            b.w(TC, AFC, diag * 2);
            b.w(TC, 0, ((reps - 1) * 4 + 2) * gap);
            b.w(TC, TC, diag * 2);
            for (int i = 0; i < reps; i++) {
                b.w(0, TC, len * s); b.w(AFC, 0, gap * 2); b.w(0, AFC, len * s); b.w(AFC, 0, gap * 2);
            }
            b.w(0, TC, len * s); b.w(AFC, 0, gap * 2); b.w(0, AFC, len * s);
        } else { // Stationary and unknown names
            b.pause(10);
        }
        return b.out;
    }

    private static void out(B b, int dx, int dy, double tiles) { b.out.add(new Seg(dx, dy, tiles, -1)); }
}
