package com.hiveminemobile;

import com.hiveminemobile.ai.control.AutomationController.Decision;

/** Plain-language result for each AI request. No Android types, so it can be tested on the JVM. */
public final class AiStatusMessages {
    private AiStatusMessages() {}

    public static String forDecision(Decision d) {
        if (d == null) return "No result.";
        switch (d) {
            case START_REQUESTED: return "Start sent. Watch the status on Home.";
            case RECOVER_REQUESTED: return "Rejoin sent.";
            case STOP_REQUESTED: return "Stop sent. Waiting for the macro to confirm it stopped.";
            case STOP_DISPATCH_FAILED: return "STOP could not be dispatched. Check the accessibility service and try the app's Stop control.";
            case REFUSED_NOT_ENABLED: return "AI control is OFF. Turn it on first.";
            case REFUSED_NOT_CONNECTED: return "Macro service is not connected. Turn on the accessibility service.";
            case REFUSED_ALREADY_RUNNING: return "Already running.";
            case REFUSED_NOT_RUNNING: return "The macro is not running, so there is nothing to rejoin or recover.";
            default: return d.name();
        }
    }

    /** Phase 085 readiness in plain words. */
    public static String readiness(java.util.List<String> missing) {
        if (missing == null || missing.isEmpty()) return "Integration: ready.";
        return "Integration: not ready. Missing: " + String.join(", ", missing) + ".";
    }
}
