package com.hiveminemobile;

import android.graphics.Bitmap;

/**
 * Phase 2 vision: screenshot-based detection of Bee Swarm mobile UI.
 * No OpenCV - pure color + region heuristics that work on the Accessibility screenshot.
 *
 * Detects:
 *  - joystick center
 *  - pollen bag left end
 *  - Make Honey / convert button
 *  - rough scene: AT_HIVE vs ON_FIELD vs UNKNOWN
 */
public final class AutoSense {
    private AutoSense() {}

    public static final int SCENE_UNKNOWN = 0;
    public static final int SCENE_AT_HIVE = 1;
    public static final int SCENE_ON_FIELD = 2;

    public static final class Result {
        public int joyX, joyY, bagX, bagY, convX, convY;
        public boolean joyOk, bagOk, convOk;
        public int scene = SCENE_UNKNOWN;
        public int bagPercentGuess = -1;
        /** Approximate hive-pad center when scene is AT_HIVE (bottom-middle zone). */
        public int hivePadX, hivePadY;
        public boolean hivePadOk;
        public int claimX, claimY;
        public boolean claimOk;
        public boolean questUiLikely;
        public String note = "";
    }

    /**
     * Full scan of a live Roblox screenshot.
     * Fills confident spots and classifies the scene.
     */
    public static Result sense(Bitmap bmp, int screenW, int screenH) {
        Result r = new Result();
        if (bmp == null || screenW < 200 || screenH < 200) {
            r.note = "bad bitmap";
            return r;
        }
        int w = bmp.getWidth();
        int h = bmp.getHeight();

        senseBag(bmp, w, h, r);
        senseJoystick(bmp, w, h, r);
        senseConvert(bmp, w, h, r);
        senseClaim(bmp, w, h, r);
        classifyScene(bmp, w, h, r);

        StringBuilder nb = new StringBuilder();
        if (r.bagOk) nb.append("bag ");
        if (r.joyOk) nb.append("joy ");
        if (r.convOk) nb.append("conv ");
        if (r.claimOk) nb.append("claim ");
        if (r.questUiLikely) nb.append("quest-ui ");
        if (r.scene == SCENE_AT_HIVE) nb.append("at-hive ");
        else if (r.scene == SCENE_ON_FIELD) nb.append("on-field ");
        r.note = nb.length() == 0 ? "no strong matches" : ("found " + nb.toString().trim());
        return r;
    }

    /** Fast quest-claim probe from one bitmap. */
    public static Result questProbe(Bitmap bmp) {
        Result r = new Result();
        if (bmp == null) return r;
        senseClaim(bmp, bmp.getWidth(), bmp.getHeight(), r);
        return r;
    }

    /** Fast scene-only scan used while farming / converting. */
    public static int sceneOnly(Bitmap bmp) {
        if (bmp == null) return SCENE_UNKNOWN;
        Result r = new Result();
        classifyScene(bmp, bmp.getWidth(), bmp.getHeight(), r);
        return r.scene;
    }

    // ------------------------------------------------------------------ bag

    private static void senseBag(Bitmap bmp, int w, int h, Result r) {
        int topLimit = Math.min(h / 5, 240);
        int bestRun = 0;
        int bestX = 0, bestY = 0;
        int bestPct = 0;

        for (int y = 6; y < topLimit; y += 2) {
            int run = 0;
            int runStartX = 0;
            int runPct = 0;
            for (int x = 4; x < w / 2; x += 2) {
                int c = bmp.getPixel(x, y) & 0xFFFFFF;
                int pct = BagReader.percentFromColor(c);
                if (pct > 0) {
                    if (run == 0) { runStartX = x; runPct = pct; }
                    run++;
                    if (pct > runPct) runPct = pct;
                } else {
                    if (run >= 4 && run > bestRun) {
                        bestRun = run;
                        bestX = runStartX + 2;
                        bestY = y;
                        bestPct = runPct;
                    }
                    run = 0;
                }
            }
            if (run >= 4 && run > bestRun) {
                bestRun = run;
                bestX = runStartX + 2;
                bestY = y;
                bestPct = runPct;
            }
        }
        if (bestRun >= 4) {
            r.bagX = bestX;
            r.bagY = bestY;
            r.bagOk = true;
            r.bagPercentGuess = bestPct;
        }
    }

    // ------------------------------------------------------------------ joystick

    private static void senseJoystick(Bitmap bmp, int w, int h, Result r) {
        int top = (int) (h * 0.52f);
        int bottom = (int) (h * 0.96f);
        int right = (int) (w * 0.42f);
        long best = -1;
        int bx = 0, by = 0;

        for (int y = top; y < bottom; y += 5) {
            for (int x = 16; x < right; x += 5) {
                int c = bmp.getPixel(x, y) & 0xFFFFFF;
                int red = (c >> 16) & 255;
                int grn = (c >> 8) & 255;
                int blu = c & 255;
                int bright = red + grn + blu;
                if (bright < 30 || bright > 320) continue;
                int spread = Math.abs(red - grn) + Math.abs(grn - blu);
                if (spread > 90) continue;

                int around = brightnessAround(bmp, x, y, 14);
                int contrast = around - bright;
                int score = (contrast > 20 ? contrast : 0) + (280 - bright) / 3;
                int prior = Math.abs(x - (int) (w * 0.17)) + Math.abs(y - (int) (h * 0.78));
                score += Math.max(0, 70 - prior / 5);

                if (score > best) {
                    best = score;
                    bx = x;
                    by = y;
                }
            }
        }
        if (best > 90) {
            r.joyX = bx;
            r.joyY = by;
            r.joyOk = true;
        }
    }

    // ------------------------------------------------------------------ convert

    private static void senseConvert(Bitmap bmp, int w, int h, Result r) {
        int left = (int) (w * 0.50f);
        int top = (int) (h * 0.28f);
        int bottom = (int) (h * 0.78f);
        long best = -1;
        int bx = 0, by = 0;

        for (int y = top; y < bottom; y += 6) {
            for (int x = left; x < w - 24; x += 6) {
                int c = bmp.getPixel(x, y) & 0xFFFFFF;
                int red = (c >> 16) & 255;
                int grn = (c >> 8) & 255;
                int blu = c & 255;
                int bright = red + grn + blu;
                boolean warm = red > 150 && grn > 100 && blu < 130 && red >= grn;
                boolean brightBtn = bright > 380 && red > 140;
                if (!warm && !brightBtn) continue;

                int local = warmCount(bmp, x, y, 10);
                int score = (warm ? 60 : 20) + bright / 4 + local * 3;
                int midDist = Math.abs(y - h / 2);
                score += Math.max(0, 35 - midDist / 10);

                if (score > best) {
                    best = score;
                    bx = x;
                    by = y;
                }
            }
        }
        if (best > 160) {
            r.convX = bx;
            r.convY = by;
            r.convOk = true;
        }
    }

    // ------------------------------------------------------------------ scene

    private static void classifyScene(Bitmap bmp, int w, int h, Result r) {
        boolean hasBag = r.bagOk;
        boolean hasConv = r.convOk;

        if (!hasBag) {
            int hits = 0;
            for (int y = 8; y < Math.min(h / 6, 180); y += 4) {
                for (int x = 8; x < w / 3; x += 4) {
                    if (BagReader.percentFromColor(bmp.getPixel(x, y) & 0xFFFFFF) > 0) hits++;
                }
            }
            hasBag = hits >= 6;
        }
        if (!hasConv) {
            int warmHits = 0;
            int left = (int) (w * 0.55f);
            for (int y = (int) (h * 0.35f); y < (int) (h * 0.7f); y += 8) {
                for (int x = left; x < w - 20; x += 8) {
                    int c = bmp.getPixel(x, y) & 0xFFFFFF;
                    int red = (c >> 16) & 255, grn = (c >> 8) & 255, blu = c & 255;
                    if (red > 150 && grn > 100 && blu < 130 && red >= grn) warmHits++;
                }
            }
            hasConv = warmHits >= 8;
        }

        int greenHits = 0;
        int cx0 = w / 4, cx1 = (w * 3) / 4;
        int cy0 = h / 4, cy1 = (h * 3) / 4;
        for (int y = cy0; y < cy1; y += 12) {
            for (int x = cx0; x < cx1; x += 12) {
                int c = bmp.getPixel(x, y) & 0xFFFFFF;
                int red = (c >> 16) & 255, grn = (c >> 8) & 255, blu = c & 255;
                if (grn > red + 15 && grn > blu + 10 && grn > 60) greenHits++;
            }
        }
        boolean lotsOfGreen = greenHits > 25;

        // Field tokens / flowers: bright saturated blobs in the mid band (not UI chrome)
        int tokenHits = 0;
        for (int y = h / 5; y < (h * 3) / 5; y += 10) {
            for (int x = w / 6; x < (w * 5) / 6; x += 10) {
                int c = bmp.getPixel(x, y) & 0xFFFFFF;
                int red = (c >> 16) & 255, grn = (c >> 8) & 255, blu = c & 255;
                int max = Math.max(red, Math.max(grn, blu));
                int min = Math.min(red, Math.min(grn, blu));
                // Saturated bright colors (flowers, tokens, pollen piles)
                if (max > 160 && (max - min) > 50) tokenHits++;
            }
        }
        boolean fieldTokens = tokenHits > 18;

        if (hasBag && hasConv) {
            r.scene = SCENE_AT_HIVE;
            // Prefer a darker/wooden patch near bottom-center over a pure ratio
            int bestPad = -1;
            int px = w / 2, py = (int) (h * 0.72f);
            int padTop = (int) (h * 0.58f);
            int padBot = (int) (h * 0.88f);
            int padLeft = (int) (w * 0.30f);
            int padRight = (int) (w * 0.70f);
            for (int y = padTop; y < padBot; y += 8) {
                for (int x = padLeft; x < padRight; x += 8) {
                    int c = bmp.getPixel(x, y) & 0xFFFFFF;
                    int red = (c >> 16) & 255, grn = (c >> 8) & 255, blu = c & 255;
                    // Wood / dirt / pad: mid brightness, red-ish or brown
                    int bright = red + grn + blu;
                    boolean brown = red > grn && red > blu && bright > 80 && bright < 420;
                    boolean grayPad = Math.abs(red - grn) < 25 && Math.abs(grn - blu) < 25
                            && bright > 100 && bright < 380;
                    if (!brown && !grayPad) continue;
                    int score = (brown ? 30 : 10) + (300 - Math.abs(bright - 220)) / 4;
                    int dist = Math.abs(x - w / 2) + Math.abs(y - (int) (h * 0.72f));
                    score += Math.max(0, 40 - dist / 6);
                    if (score > bestPad) {
                        bestPad = score;
                        px = x;
                        py = y;
                    }
                }
            }
            r.hivePadX = px;
            r.hivePadY = py;
            r.hivePadOk = true;
        } else if (hasBag && (lotsOfGreen || fieldTokens) && !hasConv) {
            r.scene = SCENE_ON_FIELD;
        } else if (hasBag) {
            r.scene = (lotsOfGreen || fieldTokens) ? SCENE_ON_FIELD : SCENE_UNKNOWN;
        } else {
            r.scene = SCENE_UNKNOWN;
        }
    }




    /**
     * BSS quest board progress (from real screenshots):
     *  - Red/coral row with a thin green fill = still in progress → ignore
     *  - Full solid green row ("Complete! Talk to ...") = done → turn in
     * We require a WIDE green horizontal run so a partial progress bar does not count.
     */
    private static void senseClaim(Bitmap bmp, int w, int h, Result r) {
        int top = (int) (h * 0.12f);
        int bottom = (int) (h * 0.72f);
        int left = (int) (w * 0.02f);
        int right = (int) (w * 0.38f);

        int bestRun = 0;
        int bestX = 0, bestY = 0;
        int solidGreenRows = 0;
        int redHits = 0;

        // Scan row-by-row for long horizontal green runs (full Complete rows)
        for (int y = top; y < bottom; y += 3) {
            int run = 0;
            int runStart = left;
            int maxRun = 0;
            int maxRunStart = left;
            for (int x = left; x < right; x += 2) {
                int c = bmp.getPixel(x, y) & 0xFFFFFF;
                int red = (c >> 16) & 255;
                int grn = (c >> 8) & 255;
                int blu = c & 255;

                boolean redRow = red > 160 && grn < 140 && blu < 140 && red > grn + 30;
                if (redRow) redHits++;

                // Strong green panel pixel (not just a tiny progress notch)
                boolean green = grn > 150 && grn > red + 28 && grn > blu + 22
                        && red < 165 && blu < 165;
                if (green) {
                    if (run == 0) runStart = x;
                    run += 2;
                    if (run > maxRun) {
                        maxRun = run;
                        maxRunStart = runStart;
                    }
                } else {
                    run = 0;
                }
            }
            // A full Complete row spans most of the left panel (~25%+ of panel width)
            int panelW = right - left;
            if (maxRun >= panelW * 0.35f) {
                solidGreenRows++;
                if (maxRun > bestRun) {
                    bestRun = maxRun;
                    bestX = maxRunStart + maxRun / 2;
                    bestY = y;
                }
            }
        }

        // Need multiple solid-green scanlines so a thin progress fill never triggers
        if (solidGreenRows >= 4 && bestRun > 0) {
            r.claimX = bestX;
            r.claimY = bestY;
            r.claimOk = true;
        }
        r.questUiLikely = r.claimOk || solidGreenRows >= 2 || redHits >= 20;
    }

    private static int claimBlob(Bitmap b, int cx, int cy, int radius) {
        // Kept for any leftover callers; main logic is the horizontal run scan above.
        int n = 0;
        int w = b.getWidth(), h = b.getHeight();
        for (int dy = -radius; dy <= radius; dy += 3) {
            for (int dx = -radius; dx <= radius; dx += 3) {
                int x = Math.max(0, Math.min(w - 1, cx + dx));
                int y = Math.max(0, Math.min(h - 1, cy + dy));
                int c = b.getPixel(x, y) & 0xFFFFFF;
                int red = (c >> 16) & 255, grn = (c >> 8) & 255, blu = c & 255;
                if (grn > 145 && grn > red + 22 && grn > blu + 18 && red < 175) n++;
            }
        }
        return n;
    }



    private static int brightnessAround(Bitmap b, int cx, int cy, int radius) {
        long sum = 0;
        int n = 0;
        int w = b.getWidth(), h = b.getHeight();
        for (int dy = -radius; dy <= radius; dy += 4) {
            for (int dx = -radius; dx <= radius; dx += 4) {
                if (dx == 0 && dy == 0) continue;
                int x = Math.max(0, Math.min(w - 1, cx + dx));
                int y = Math.max(0, Math.min(h - 1, cy + dy));
                int c = b.getPixel(x, y) & 0xFFFFFF;
                sum += ((c >> 16) & 255) + ((c >> 8) & 255) + (c & 255);
                n++;
            }
        }
        return n == 0 ? 0 : (int) (sum / n);
    }

    private static int warmCount(Bitmap b, int cx, int cy, int radius) {
        int n = 0;
        int w = b.getWidth(), h = b.getHeight();
        for (int dy = -radius; dy <= radius; dy += 3) {
            for (int dx = -radius; dx <= radius; dx += 3) {
                int x = Math.max(0, Math.min(w - 1, cx + dx));
                int y = Math.max(0, Math.min(h - 1, cy + dy));
                int c = b.getPixel(x, y) & 0xFFFFFF;
                int red = (c >> 16) & 255, grn = (c >> 8) & 255, blu = c & 255;
                if (red > 140 && grn > 90 && blu < 140 && red >= grn) n++;
            }
        }
        return n;
    }
}
