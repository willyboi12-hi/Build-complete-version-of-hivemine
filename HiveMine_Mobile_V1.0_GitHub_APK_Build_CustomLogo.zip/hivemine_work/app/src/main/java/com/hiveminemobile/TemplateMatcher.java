package com.hiveminemobile;

/**
 * Finds a small grayscale picture inside a screenshot. Both are read on a grid, one sample every STEP pixels,
 * so a match is found to within STEP pixels. Pure Java, with no Android classes, so it can be tested alone.
 */
public final class TemplateMatcher {
    /** Pixels between samples. Used for both the screenshot and the picture. */
    public static final int STEP = 4;
    /** A place counts as a match at or above this score (1 = identical). */
    public static final double MIN_SCORE = 0.85;
    /** A picture whose lightest and darkest samples differ by less than this is too plain to find reliably. */
    public static final int MIN_CONTRAST = 24;

    private TemplateMatcher() {}

    /** Grayscale value (0-255) of an ARGB or RGB color. */
    public static int gray(int argb) {
        int r = (argb >> 16) & 255, g = (argb >> 8) & 255, b = argb & 255;
        return (r * 299 + g * 587 + b * 114) / 1000;
    }

    /** True if the picture has enough light and dark parts to be found reliably. */
    public static boolean isPlain(int[] v) {
        if (v == null || v.length == 0) return true;
        int lo = 255, hi = 0;
        for (int p : v) {
            if (p < lo) lo = p;
            if (p > hi) hi = p;
        }
        return hi - lo < MIN_CONTRAST;
    }

    /** Where the picture was found: top-left in grid cells, and how close it is (1 = identical). */
    public static final class Match {
        public final int x, y;
        public final double score;
        Match(int x, int y, double score) { this.x = x; this.y = y; this.score = score; }
    }

    /** A saved picture: width and height in grid cells, then the grayscale values row by row. */
    public static final class Template {
        public final int w, h;
        public final int[] v;
        Template(int w, int h, int[] v) { this.w = w; this.h = h; this.v = v; }
    }

    /** Best place the picture appears on the grid, whatever its score. Null for a plain or misfit picture. */
    public static Match best(int[] grid, int gw, int gh, int[] pic, int pw, int ph) {
        if (pic == null || pw <= 0 || ph <= 0 || pic.length != pw * ph || gw < pw || gh < ph) return null;
        if (isPlain(pic)) return null;
        Match best = null;
        double bestScore = -1;
        for (int y = 0; y + ph <= gh; y++) {
            for (int x = 0; x + pw <= gw; x++) {
                long sum = 0;
                for (int j = 0; j < ph; j++) {
                    int g = (y + j) * gw + x, p = j * pw;
                    for (int i = 0; i < pw; i++) sum += Math.abs(grid[g + i] - pic[p + i]);
                }
                double score = 1.0 - (double) sum / ((double) pw * ph * 255.0);
                if (score > bestScore) {
                    bestScore = score;
                    best = new Match(x, y, score);
                }
            }
        }
        return best;
    }

    /**
     * Best place the picture appears on the grid, or null if nothing reaches MIN_SCORE.
     * A plain picture (see isPlain) never matches, because a flat patch fits too many places.
     */
    public static Match find(int[] grid, int gw, int gh, int[] pic, int pw, int ph) {
        Match b = best(grid, gw, gh, pic, pw, ph);
        return b != null && b.score >= MIN_SCORE ? b : null;
    }

    /** Text form of a picture, for saving in preferences. */
    public static String encode(int w, int h, int[] v) {
        StringBuilder sb = new StringBuilder();
        sb.append(w).append(',').append(h);
        for (int p : v) sb.append(',').append(p);
        return sb.toString();
    }

    /** Reads a picture saved with encode(). Returns null if the text is empty or damaged. */
    public static Template decode(String s) {
        if (s == null || s.length() == 0) return null;
        String[] parts = s.split(",");
        if (parts.length < 3) return null;
        try {
            int w = Integer.parseInt(parts[0]), h = Integer.parseInt(parts[1]);
            if (w <= 0 || h <= 0 || parts.length != 2 + w * h) return null;
            int[] v = new int[w * h];
            for (int i = 0; i < v.length; i++) v[i] = Integer.parseInt(parts[2 + i]);
            return new Template(w, h, v);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
