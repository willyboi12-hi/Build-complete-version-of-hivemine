package com.hiveminemobile;

import com.hiveminemobile.ai.control.MacroPort;
import com.hiveminemobile.ai.control.MacroStatus;

/**
 * HiveMine Mobile's implementation of the HiveMine AI boundary (see hivemine-ai/INTEGRATION_GUIDE.md).
 * Each call maps onto an existing user-visible macro action in MacroAccessibilityService.
 * Nothing here runs without the service being bound, and stop is always forwarded.
 */
public final class AiMacroPort implements MacroPort {

    @Override public void start() {
        MacroAccessibilityService s = MacroAccessibilityService.instance;
        if (s != null) s.startMacro();
    }

    @Override public void stop() {
        MacroAccessibilityService s = MacroAccessibilityService.instance;
        if (s != null) s.stopMacro();
    }

    @Override public void recover() {
        MacroAccessibilityService s = MacroAccessibilityService.instance;
        if (s != null) s.rejoinNow();
    }

    @Override public MacroStatus readStatus() {
        MacroAccessibilityService s = MacroAccessibilityService.instance;
        if (s == null) return MacroStatus.disconnected("Accessibility service is not bound.");
        String note = MacroAccessibilityService.status + " | " + MacroAccessibilityService.bagLine;
        return MacroStatus.connected(s.isRunning(), note, s.getRecoveryGeneration(), s.isRecoveryInProgress(),
            s.getBagPercent(), s.getSceneName(), s.getLastObservationAtMillis());
    }
}
