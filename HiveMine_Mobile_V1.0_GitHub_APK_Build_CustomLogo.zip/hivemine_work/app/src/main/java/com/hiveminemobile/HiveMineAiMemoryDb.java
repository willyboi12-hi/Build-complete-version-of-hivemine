package com.hiveminemobile;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Android persistence for HiveMine AI's operational memory. This stores bounded, non-chat event
 * summaries (command lifecycle, connectivity, configuration outcomes) in SQLite. Raw user prompts
 * and screenshots are deliberately not persisted here.
 */
public final class HiveMineAiMemoryDb extends SQLiteOpenHelper {
    private static final String DB_NAME = "hivemine_ai_memory.db";
    private static final int DB_VERSION = 2;
    private static final String TABLE = "manager_events";
    private static final String LEARNING = "learning_outcomes";

    public static final class Event {
        public final long id;
        public final long atMillis;
        public final String type;
        public final String detail;

        Event(long id, long atMillis, String type, String detail) {
            this.id = id;
            this.atMillis = atMillis;
            this.type = type;
            this.detail = detail;
        }

        public String asLogLine() {
            return atMillis + " [" + type + "] " + detail;
        }
    }

    public HiveMineAiMemoryDb(Context context) {
        super(context.getApplicationContext(), DB_NAME, null, DB_VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE + " (id INTEGER PRIMARY KEY AUTOINCREMENT, at_ms INTEGER NOT NULL, event_type TEXT NOT NULL, detail TEXT NOT NULL)");
        db.execSQL("CREATE INDEX idx_manager_events_at ON " + TABLE + " (at_ms)");
        db.execSQL("CREATE TABLE " + LEARNING + " (id INTEGER PRIMARY KEY AUTOINCREMENT, at_ms INTEGER NOT NULL, capability TEXT NOT NULL, specialist TEXT NOT NULL, success INTEGER NOT NULL, detail TEXT NOT NULL)");
        db.execSQL("CREATE INDEX idx_learning_at ON " + LEARNING + " (at_ms)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS " + LEARNING + " (id INTEGER PRIMARY KEY AUTOINCREMENT, at_ms INTEGER NOT NULL, capability TEXT NOT NULL, specialist TEXT NOT NULL, success INTEGER NOT NULL, detail TEXT NOT NULL)");
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_learning_at ON " + LEARNING + " (at_ms)");
        }
    }

    public synchronized boolean appendLearningOutcome(String capability, String specialist, boolean success, String detail, long atMillis) {
        if (capability == null || capability.trim().isEmpty() || specialist == null || specialist.trim().isEmpty()) return false;
        try {
            ContentValues values = new ContentValues();
            values.put("at_ms", Math.max(0L, atMillis));
            values.put("capability", trim(capability, 80));
            values.put("specialist", trim(specialist, 80));
            values.put("success", success ? 1 : 0);
            values.put("detail", trim(detail == null ? "" : detail, 500));
            SQLiteDatabase db = getWritableDatabase();
            return db.insert(LEARNING, null, values) != -1L;
        } catch (RuntimeException failure) { return false; }
    }

    public synchronized List<LearningOutcome> learningHistory(int requestedLimit) {
        int limit = Math.max(1, Math.min(500, requestedLimit));
        List<LearningOutcome> out = new ArrayList<LearningOutcome>();
        Cursor cursor = null;
        try {
            cursor = getReadableDatabase().query(LEARNING, new String[] {"at_ms","capability","specialist","success","detail"},
                null, null, null, null, "id DESC", String.valueOf(limit));
            while (cursor.moveToNext()) out.add(new LearningOutcome(cursor.getLong(0), cursor.getString(1),
                cursor.getString(2), cursor.getLong(3) != 0, cursor.getString(4)));
        } finally { if (cursor != null) cursor.close(); }
        return Collections.unmodifiableList(out);
    }

    public static final class LearningOutcome {
        public final long atMillis; public final String capability; public final String specialist;
        public final boolean success; public final String detail;
        LearningOutcome(long atMillis, String capability, String specialist, boolean success, String detail) {
            this.atMillis = atMillis; this.capability = capability; this.specialist = specialist; this.success = success; this.detail = detail;
        }
    }

    private static String trim(String value, int max) {
        String v = value == null ? "" : value.trim();
        return v.length() > max ? v.substring(0, max) : v;
    }

    /** Returns false if the database cannot commit the event. */
    public synchronized boolean append(String type, String detail, long atMillis) {
        if (type == null || type.trim().isEmpty() || detail == null) return false;
        String safeType = type.trim();
        String safeDetail = detail.trim();
        if (safeType.length() > 48) safeType = safeType.substring(0, 48);
        if (safeDetail.length() > 512) safeDetail = safeDetail.substring(0, 512);
        try {
            ContentValues values = new ContentValues();
            values.put("at_ms", Math.max(0L, atMillis));
            values.put("event_type", safeType);
            values.put("detail", safeDetail);
            SQLiteDatabase db = getWritableDatabase();
            boolean inserted = db.insert(TABLE, null, values) != -1L;
            if (inserted) db.execSQL("DELETE FROM " + TABLE + " WHERE id NOT IN (SELECT id FROM " + TABLE + " ORDER BY id DESC LIMIT 2000)");
            return inserted;
        } catch (RuntimeException failure) {
            return false;
        }
    }

    /** Newest first. A small hard limit protects the UI and database read path. */
    public synchronized List<Event> recent(int requestedLimit) {
        int limit = Math.max(1, Math.min(100, requestedLimit));
        List<Event> events = new ArrayList<Event>();
        Cursor cursor = null;
        try {
            cursor = getReadableDatabase().query(TABLE,
                new String[] {"id", "at_ms", "event_type", "detail"},
                null, null, null, null, "id DESC", String.valueOf(limit));
            while (cursor.moveToNext()) {
                events.add(new Event(cursor.getLong(0), cursor.getLong(1),
                    cursor.getString(2), cursor.getString(3)));
            }
        } finally {
            if (cursor != null) cursor.close();
        }
        return Collections.unmodifiableList(events);
    }
}
