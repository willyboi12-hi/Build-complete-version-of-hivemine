package com.hiveminemobile.overlay;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Persistent overlay settings. Uses the same prefs style as the rest of the project.
 */
public final class OverlaySettings {

    private static final String PREFS = "natro_overlay";
    private final SharedPreferences p;

    public OverlaySettings(Context c) {
        p = c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public int getBubbleX() { return p.getInt("bubble_x", -1); }
    public int getBubbleY() { return p.getInt("bubble_y", -1); }
    public void setBubblePos(int x, int y) {
        p.edit().putInt("bubble_x", x).putInt("bubble_y", y).apply();
    }

    public int getPanelX() { return p.getInt("panel_x", -1); }
    public int getPanelY() { return p.getInt("panel_y", -1); }
    public void setPanelPos(int x, int y) {
        p.edit().putInt("panel_x", x).putInt("panel_y", y).apply();
    }

    public float getTransparency() { return p.getFloat("transparency", 0.92f); }
    public void setTransparency(float v) {
        p.edit().putFloat("transparency", Math.max(0.4f, Math.min(1f, v))).apply();
    }

    public int getBubbleSizeDp() { return p.getInt("bubble_size", 58); }
    public void setBubbleSizeDp(int dp) {
        p.edit().putInt("bubble_size", Math.max(44, Math.min(72, dp))).apply();
    }

    public boolean getAnimations() { return p.getBoolean("animations", true); }
    public void setAnimations(boolean on) {
        p.edit().putBoolean("animations", on).apply();
    }

    public int getLastTab() { return p.getInt("last_tab", 0); }
    public void setLastTab(int tab) {
        p.edit().putInt("last_tab", tab).apply();
    }

    public void resetPositions() {
        p.edit()
            .remove("bubble_x").remove("bubble_y")
            .remove("panel_x").remove("panel_y")
            .apply();
    }
}
