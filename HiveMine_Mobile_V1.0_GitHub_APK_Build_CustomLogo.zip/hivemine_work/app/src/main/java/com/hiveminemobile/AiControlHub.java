package com.hiveminemobile;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;
import java.util.Map;

import com.hiveminemobile.ai.android.AndroidIntegrationManager;
import com.hiveminemobile.ai.android.AndroidMacroCommunicationBridge;
import com.hiveminemobile.ai.control.AutomationController;
import com.hiveminemobile.ai.control.MacroStatus;
import com.hiveminemobile.ai.android.AndroidMacroCommunicationBridge.Request;
import com.hiveminemobile.ai.android.AndroidMacroCommunicationBridge.Status;
import com.hiveminemobile.ai.ui.chat.AiManagerService;
import com.hiveminemobile.ai.ui.screens.ScreenState;
import com.hiveminemobile.ai.manager.runtime.ManagerRuntimeService;
import com.hiveminemobile.ai.AIConfiguration;
import com.hiveminemobile.ai.modules.VisionAI;

/**
 * Owns the one AutomationController that HiveMine AI uses, the user's AI-control switch, the macro command
 * bridge (phase 089), and the integration readiness check (phase 085).
 * The switch is stored under "ai_control_enabled" (see hivemine-ai HiveMineMobileContract) in the same
 * preferences file as Config. It is off by default. Only the Setup screen may call setEnabled().
 */
public final class AiControlHub {
    static final String PREF_FILE = "natro_mobile";
    static final String KEY = "ai_control_enabled";
    static final long BRIDGE_TIMEOUT_MS = 15000L;

    private static AutomationController controller;
    private static AndroidMacroCommunicationBridge bridge;
    private static AndroidIntegrationManager integration;
    private static AiManagerService managerService;
    private static ScreenState managerState;
    private static HiveMineAiMemoryDb persistentMemory;
    private static ManagerRuntimeService managerRuntime;
    private static final VisionAI visionAI = new VisionAI();
    private static long lastVisionHash;
    private static MacroStatus lastRuntimeStatus;
    private static final Map<String, Status> observedRequestStates = new HashMap<String, Status>();

    private AiControlHub() {}

    /** Test-only: forget the cached objects, as an app restart would. */
    static synchronized void resetForTesting() {
        controller = null; bridge = null; integration = null; managerService = null; managerState = null; managerRuntime = null;
        if (persistentMemory != null) persistentMemory.close();
        persistentMemory = null;
        lastVisionHash = 0L;
        lastRuntimeStatus = null; observedRequestStates.clear();
    }

    public static synchronized AutomationController controller(Context c) {
        if (controller == null) {
            controller = new AutomationController(new AiMacroPort());
            controller.setAiControlEnabled(isEnabled(c));
        }
        return controller;
    }

    /** Live user-facing AI Manager bound to the same authorized controller as the dashboard controls. */
    public static synchronized AiManagerService manager(Context c) {
        if (managerService == null) {
            managerService = new AiManagerService();
            managerService.bind(new AiMacroPort(), controller(c));
            managerService.bindCommunicationBridge(bridge(c));
            managerService.bindConfigurationApplier(settings -> applyAiSettings(c, settings));
            managerService.bindEventLogger((type, detail) -> persistEvent(c, type, detail, System.currentTimeMillis()));
            managerRuntime = new ManagerRuntimeService(AIConfiguration.empty(), controller(c), new AiMacroPort());
            try {
                for (HiveMineAiMemoryDb.LearningOutcome outcome : memoryDb(c).learningHistory(500)) {
                    managerRuntime.recordOutcome(outcome.capability, outcome.specialist, outcome.success, outcome.detail, outcome.atMillis);
                }
            } catch (RuntimeException ignored) {
                // Operational memory remains available even if historical learning data is unreadable.
            }
            managerService.bindManagerRuntime(managerRuntime);
            managerState = new ScreenState();
            loadMacroSettings(c, managerState);
            loadPersistentEvents(c, managerState);
        }
        managerState.aiControlEnabled = controller(c).isAiControlEnabled();
        managerState.bindMacro(controller(c).readStatus());
        return managerService;
    }

    /** Persistent in-process state for the live AI Manager conversation/session. */
    private static void loadMacroSettings(Context c, ScreenState state) {
        Config cfg = new Config(c);
        state.settings.set("field", cfg.field);
        state.settings.set("questSmart", String.valueOf(cfg.questSmart));
        state.settings.set("fullAction", String.valueOf(cfg.fullAction));
        state.settings.set("fullPercent", String.valueOf(cfg.fullPercent));
        state.settings.set("pattern", cfg.pattern);
        state.settings.set("size", cfg.size);
        state.settings.set("walkFirst", String.valueOf(cfg.walkFirst));
        state.settings.set("returnToField", String.valueOf(cfg.returnToField));
        state.settings.set("humanMode", String.valueOf(cfg.humanMode));
        state.settings.set("humanLevel", String.valueOf(cfg.humanLevel));
        state.settings.set("moveSpeed", String.valueOf(cfg.moveSpeed));
        state.settings.set("runMinutes", String.valueOf(cfg.runMinutes));
    }

    private static void applyAiSettings(Context c, Map<String, String> values) {
        if (values == null) throw new IllegalArgumentException("Settings proposal is missing.");
        Config previous = new Config(c);
        Config cfg = new Config(c);
        if (values.containsKey("field")) cfg.field = requiredText(values.get("field"), "field", 80);
        if (values.containsKey("questSmart")) cfg.questSmart = parseBoolean(values.get("questSmart"), "questSmart");
        if (values.containsKey("fullAction")) cfg.fullAction = parseInt(values.get("fullAction"), "fullAction", 0, 2);
        if (values.containsKey("fullPercent")) cfg.fullPercent = parseInt(values.get("fullPercent"), "fullPercent", 1, 100);
        if (values.containsKey("pattern")) cfg.pattern = requiredText(values.get("pattern"), "pattern", 40);
        if (values.containsKey("size")) cfg.size = requiredText(values.get("size"), "size", 12);
        if (values.containsKey("walkFirst")) cfg.walkFirst = parseBoolean(values.get("walkFirst"), "walkFirst");
        if (values.containsKey("returnToField")) cfg.returnToField = parseBoolean(values.get("returnToField"), "returnToField");
        if (values.containsKey("humanMode")) cfg.humanMode = parseBoolean(values.get("humanMode"), "humanMode");
        if (values.containsKey("humanLevel")) cfg.humanLevel = parseInt(values.get("humanLevel"), "humanLevel", 0, 2);
        if (values.containsKey("moveSpeed")) cfg.moveSpeed = parseFloat(values.get("moveSpeed"), "moveSpeed", 1f, 100f);
        if (values.containsKey("runMinutes")) cfg.runMinutes = parseInt(values.get("runMinutes"), "runMinutes", 0, 1440);

        // Reject unknown keys before touching persistence; never partially apply a mixed proposal.
        for (String key : values.keySet()) {
            if (!"aiControlEnabled".equals(key) && configValue(cfg, key) == null)
                throw new IllegalArgumentException("Unsupported AI setting: " + key);
        }
        boolean committed;
        try { committed = cfg.save(); }
        catch (RuntimeException failure) {
            throw rollbackSettings(previous, "Settings persistence failed: " + failure.getMessage());
        }
        if (!committed) throw rollbackSettings(previous, "Android did not confirm the settings commit.");

        Config persisted;
        try { persisted = new Config(c); }
        catch (RuntimeException failure) {
            throw rollbackSettings(previous, "Could not read settings back after commit: " + failure.getMessage());
        }
        for (Map.Entry<String, String> entry : values.entrySet()) {
            // This is a UI/control flag, not a Config.java macro setting.
            if ("aiControlEnabled".equals(entry.getKey())) continue;
            String actual = configValue(persisted, entry.getKey());
            String expected = "moveSpeed".equals(entry.getKey())
                ? String.valueOf(cfg.moveSpeed) : entry.getValue();
            if (actual == null || !actual.equals(expected))
                throw rollbackSettings(previous, "Settings verification failed for " + entry.getKey() + ".");
        }
        if (managerState != null) {
            for (Map.Entry<String, String> entry : values.entrySet()) {
                if (!"aiControlEnabled".equals(entry.getKey())) {
                    managerState.settings.set(entry.getKey(), entry.getValue());
                }
            }
        }
    }

    private static IllegalStateException rollbackSettings(Config previous, String reason) {
        boolean restored = false;
        try { restored = previous.save(); } catch (RuntimeException ignored) {}
        return new IllegalStateException(reason + (restored
            ? " Previous settings were restored."
            : " The previous settings could not be confirmed; inspect app configuration before restarting."));
    }

    private static String requiredText(String value, String name, int maxLength) {
        if (value == null || value.trim().isEmpty() || value.trim().length() > maxLength)
            throw new IllegalArgumentException("Invalid " + name + " setting.");
        return value.trim();
    }

    private static boolean parseBoolean(String value, String name) {
        if ("true".equalsIgnoreCase(value)) return true;
        if ("false".equalsIgnoreCase(value)) return false;
        throw new IllegalArgumentException("Invalid boolean for " + name + ".");
    }

    private static int parseInt(String value, String name, int min, int max) {
        try {
            int parsed = Integer.parseInt(value);
            if (parsed < min || parsed > max) throw new IllegalArgumentException(name + " must be " + min + "-" + max + ".");
            return parsed;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid number for " + name + ".");
        }
    }

    private static float parseFloat(String value, String name, float min, float max) {
        try {
            float parsed = Float.parseFloat(value);
            if (Float.isNaN(parsed) || Float.isInfinite(parsed) || parsed < min || parsed > max)
                throw new IllegalArgumentException(name + " must be " + min + "-" + max + ".");
            return parsed;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid number for " + name + ".");
        }
    }

    private static String configValue(Config cfg, String key) {
        if ("field".equals(key)) return cfg.field;
        if ("questSmart".equals(key)) return String.valueOf(cfg.questSmart);
        if ("fullAction".equals(key)) return String.valueOf(cfg.fullAction);
        if ("fullPercent".equals(key)) return String.valueOf(cfg.fullPercent);
        if ("pattern".equals(key)) return cfg.pattern;
        if ("size".equals(key)) return cfg.size;
        if ("walkFirst".equals(key)) return String.valueOf(cfg.walkFirst);
        if ("returnToField".equals(key)) return String.valueOf(cfg.returnToField);
        if ("humanMode".equals(key)) return String.valueOf(cfg.humanMode);
        if ("humanLevel".equals(key)) return String.valueOf(cfg.humanLevel);
        if ("moveSpeed".equals(key)) return String.valueOf(cfg.moveSpeed);
        if ("runMinutes".equals(key)) return String.valueOf(cfg.runMinutes);
        return null;
    }

    /** Feeds a real Android screenshot frame into the core VisionAI without retaining the pixels. */
    public static synchronized void observeVisionFrame(Context c, int[] pixels, int width, int height, long nowMillis) {
        if (pixels == null || width < 1 || height < 1 || (long) pixels.length != (long) width * height) return;
        VisionAI.Frame frame = new VisionAI.Frame(width, height, pixels);
        VisionAI.FrameAnalysis analysis = visionAI.analyzeFrame(frame);
        if (analysis.getContentHash() != lastVisionHash) {
            lastVisionHash = analysis.getContentHash();
            persistEvent(c, "VISION_FRAME", "VisionAI analyzed " + width + "x" + height
                + " frame; luminance=" + Math.round(analysis.getMeanLuminance())
                + ", deviation=" + Math.round(analysis.getLuminanceDeviation()), nowMillis);
        }
        if (managerState != null) {
            managerState.systemHealth.put("Vision AI", "AVAILABLE");
        }
    }

    /**
     * Called by the Android service on a dedicated one-second ticker. This closes the command loop:
     * every request is reconciled against the live MacroPort state and terminal outcomes are logged.
     */
    public static synchronized void refreshRuntime(Context c, long nowMillis) {
        MacroStatus current = controller(c).readStatus();
        bridge(c).observe(current, nowMillis);
        if (managerService != null && managerRuntime != null) {
            String decision = managerService.tickManager(current, nowMillis);
            if (decision != null && !decision.isEmpty()) persistEvent(c, "MANAGER_DECISION", decision, nowMillis);
        }
        if (managerState != null) {
            managerState.aiControlEnabled = controller(c).isAiControlEnabled();
            managerState.bindMacro(current);
        }
        if (lastRuntimeStatus != null) {
            if (lastRuntimeStatus.isConnected() != current.isConnected()) {
                String event = current.isConnected() ? "Macro service connected" : "Macro service disconnected";
                if (managerState != null) managerState.log(event);
                persistEvent(c, "MACRO_CONNECTION", event, nowMillis);
            }
            if (lastRuntimeStatus.isRunning() != current.isRunning()) {
                String event = current.isRunning() ? "Macro confirmed running" : "Macro confirmed stopped";
                if (managerState != null) {
                    managerState.currentTask = current.isRunning() ? "Macro running" : "Idle";
                    managerState.log(event);
                }
                persistEvent(c, "MACRO_STATE", event, nowMillis);
            }
        }
        for (Request request : bridge(c).requests()) {
            Status previous = observedRequestStates.put(request.id, request.status());
            if (previous != request.status()) {
                String event = "Command " + request.id + " " + request.command + " → " + request.status();
                if (managerState != null) {
                    managerState.log(event);
                    if (request.status() == Status.TIMED_OUT) managerState.currentTask = "Command timed out: " + request.command;
                }
                persistEvent(c, "COMMAND_" + request.status().name(), event, nowMillis);
                if (request.status() == Status.COMPLETED || request.status() == Status.TIMED_OUT) {
                    boolean success = request.status() == Status.COMPLETED;
                    String capability = request.command.name().toLowerCase(java.util.Locale.US);
                    String specialist = request.command == AndroidMacroCommunicationBridge.Command.RECOVER
                        ? "recovery" : request.command == AndroidMacroCommunicationBridge.Command.STOP ? "safety" : "farming";
                    String detail = success ? "Android command confirmed by live macro status"
                        : "Android command timed out before live macro confirmation";
                    if (managerRuntime != null) managerRuntime.recordOutcome(capability, specialist, success, detail, nowMillis);
                    memoryDb(c).appendLearningOutcome(capability, specialist, success, detail, nowMillis);
                }
            }
        }
        // Bound the local transition cache to avoid growing for the lifetime of the app process.
        if (observedRequestStates.size() > 256) {
            observedRequestStates.clear();
            for (Request request : bridge(c).requests()) observedRequestStates.put(request.id, request.status());
        }
        lastRuntimeStatus = current;
    }

    private static synchronized HiveMineAiMemoryDb memoryDb(Context c) {
        if (persistentMemory == null) persistentMemory = new HiveMineAiMemoryDb(c);
        return persistentMemory;
    }

    private static void persistEvent(Context c, String type, String detail, long atMillis) {
        boolean saved;
        try { saved = memoryDb(c).append(type, detail, atMillis); }
        catch (RuntimeException failure) { saved = false; }
        if (managerState != null) managerState.systemHealth.put("Persistent Memory", saved ? "AVAILABLE" : "UNAVAILABLE");
    }

    private static void loadPersistentEvents(Context c, ScreenState state) {
        try {
            java.util.List<HiveMineAiMemoryDb.Event> events = memoryDb(c).recent(40);
            for (int i = events.size() - 1; i >= 0; i--) state.activityLog.add(events.get(i).asLogLine());
            state.systemHealth.put("Persistent Memory", "AVAILABLE");
        } catch (RuntimeException failure) {
            state.systemHealth.put("Persistent Memory", "UNAVAILABLE");
        }
    }

    public static synchronized ScreenState managerState(Context c) {
        manager(c);
        return managerState;
    }

    /** Phase 089: sends START, STOP, or RECOVER through the macro port and tracks each request. */
    public static synchronized AndroidMacroCommunicationBridge bridge(Context c) {
        if (bridge == null) bridge = new AndroidMacroCommunicationBridge(controller(c), BRIDGE_TIMEOUT_MS);
        return bridge;
    }

    /**
     * Phase 085: refreshes what the AI can see of the app and returns the current integration state.
     * Unbound service means UNAVAILABLE, never AVAILABLE.
     */
    public static synchronized AndroidIntegrationManager integration(Context c) {
        if (integration == null) {
            integration = new AndroidIntegrationManager();
            for (String r : AndroidIntegrationManager.REQUIRED) integration.register(r, AndroidIntegrationManager.Status.UNKNOWN);
        }
        AndroidIntegrationManager.Status svc = MacroAccessibilityService.instance != null
            ? AndroidIntegrationManager.Status.AVAILABLE : AndroidIntegrationManager.Status.UNAVAILABLE;
        integration.update("macro-port", svc);
        integration.update("accessibility-service", svc);
        integration.update("configuration-storage", storageReadable(c)
            ? AndroidIntegrationManager.Status.AVAILABLE : AndroidIntegrationManager.Status.UNAVAILABLE);
        return integration;
    }

    private static boolean storageReadable(Context c) {
        try {
            c.getApplicationContext().getSharedPreferences(PREF_FILE, Context.MODE_PRIVATE).getBoolean(KEY, false);
            return true;
        } catch (RuntimeException e) {
            return false;
        }
    }

    public static boolean isEnabled(Context c) {
        try {
            SharedPreferences p = c.getApplicationContext().getSharedPreferences(PREF_FILE, Context.MODE_PRIVATE);
            return p.getBoolean(KEY, false);
        } catch (RuntimeException e) {
            return false;
        }
    }

    public static synchronized boolean setEnabled(Context c, boolean on) {
        SharedPreferences prefs = null;
        boolean previous = false;
        boolean havePrevious = false;
        try {
            prefs = c.getApplicationContext().getSharedPreferences(PREF_FILE, Context.MODE_PRIVATE);
            previous = prefs.getBoolean(KEY, false);
            havePrevious = true;
            boolean committed = prefs.edit().putBoolean(KEY, on).commit();
            boolean readBack = prefs.getBoolean(KEY, !on);
            if (!committed || readBack != on) {
                prefs.edit().putBoolean(KEY, previous).commit();
                controller(c).setAiControlEnabled(previous);
                if (managerState != null) managerState.aiControlEnabled = previous;
                return false;
            }
        } catch (RuntimeException failure) {
            if (havePrevious && prefs != null) {
                try { prefs.edit().putBoolean(KEY, previous).commit(); } catch (RuntimeException ignored) {}
                try { controller(c).setAiControlEnabled(previous); } catch (RuntimeException ignored) {}
                if (managerState != null) managerState.aiControlEnabled = previous;
            }
            return false;
        }
        controller(c).setAiControlEnabled(on);
        if (managerState != null) managerState.aiControlEnabled = on;
        return true;
    }
}
