package com.hiveminemobile.overlay;

import com.hiveminemobile.MacroAccessibilityService;

/**
 * Thin safe bridge between overlay UI and the real macro engine.
 * Only exposes supported public methods. No internal access.
 */
public final class OverlayMacroController {

    public boolean isConnected() {
        return MacroAccessibilityService.instance != null;
    }

    public boolean isRunning() {
        MacroAccessibilityService s = MacroAccessibilityService.instance;
        return s != null && s.isRunning();
    }

    public String getStatus() {
        return MacroAccessibilityService.status != null ? MacroAccessibilityService.status : "Not connected";
    }

    public String getBagLine() {
        return MacroAccessibilityService.bagLine != null ? MacroAccessibilityService.bagLine : "Bag: --";
    }

    public void start() {
        MacroAccessibilityService s = MacroAccessibilityService.instance;
        if (s != null) s.startMacro();
    }

    public void startDelayed(long ms) {
        MacroAccessibilityService s = MacroAccessibilityService.instance;
        if (s != null) s.startDelayed(ms);
    }

    public void stop() {
        MacroAccessibilityService s = MacroAccessibilityService.instance;
        if (s != null) s.stopMacro();
    }

    public void emergencyStop() {
        stop();
    }

    public void runSavedTaps(String kind, long delayMs) {
        MacroAccessibilityService s = MacroAccessibilityService.instance;
        if (s == null) return;
s.runSavedTapsNow(kind, delayMs);
    }

    public boolean supportsPause() {
        return true;
    }

    public boolean isPaused() {
        MacroAccessibilityService s = MacroAccessibilityService.instance;
        return s != null && s.isPaused();
    }

    public boolean pause() {
        MacroAccessibilityService s = MacroAccessibilityService.instance;
        return s != null && s.pauseMacro();
    }

    public boolean resume() {
        MacroAccessibilityService s = MacroAccessibilityService.instance;
        return s != null && s.resumeMacro();
    }
}
