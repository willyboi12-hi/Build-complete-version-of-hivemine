# Android device validation matrix

Record device model, Android version, display size/density, test date, tester, result (PASS/FAIL/NOT RUN), and notes for each test.

| Test | Expected result | Status |
|---|---|---|
| Fresh install | App installs and launches | NOT RUN |
| Accessibility setup | User can enable service in Android settings | NOT RUN |
| Service disconnect | Automation stops and reports unavailable state | NOT RUN |
| Emergency stop | Active gesture is stopped/released as supported; no new work starts | NOT RUN |
| Screenshot capture | Valid screenshot is delivered and closed/recycled safely | NOT RUN |
| Screenshot failure | Error is reported; no false recognition is accepted | NOT RUN |
| Gesture success/failure | Callback result is handled accurately | NOT RUN |
| App pause/resume | State remains safe across lifecycle changes | NOT RUN |
| Screen rotation | Coordinates are recalibrated or automation pauses safely | NOT RUN |
| Config persistence | Settings survive process restart | NOT RUN |
| Route/preset load | Valid data loads; invalid data is rejected safely | NOT RUN |
| Conversion transition | Bag-full decision interrupts farming at a safe boundary | NOT RUN |
| Quest transition | Quest work does not override higher priorities | NOT RUN |
| 60-minute supervised run | No crash, runaway input, or unbounded resource growth | NOT RUN |

A test is PASS only when run on the stated physical device and evidence is recorded. The software sandbox does not satisfy this matrix.
