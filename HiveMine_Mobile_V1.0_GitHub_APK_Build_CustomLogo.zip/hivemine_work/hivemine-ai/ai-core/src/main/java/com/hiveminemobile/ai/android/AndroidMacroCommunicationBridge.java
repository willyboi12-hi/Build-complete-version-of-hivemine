package com.hiveminemobile.ai.android;

import com.hiveminemobile.ai.control.AutomationController;
import com.hiveminemobile.ai.control.AutomationController.Decision;
import com.hiveminemobile.ai.control.MacroStatus;
import java.util.*;

/**
 * Phase 089: sends supported commands to the macro through MacroPort and tracks each request until it finishes.
 * A request is ACCEPTED only when the macro is connected; it is COMPLETED only when the macro state confirms it.
 */
public final class AndroidMacroCommunicationBridge {
    public enum Command { START, STOP, RECOVER }
    public enum Status { REJECTED, ACCEPTED, EXECUTING, COMPLETED, TIMED_OUT }

    public static final class Request {
        public final String id; public final Command command; public final long sentAtMillis;
        public final long baselineRecoveryGeneration;
        public final Decision decision;
        volatile Status status;
        Request(String id, Command c, long at, Status s, long baselineRecoveryGeneration, Decision decision) {
            this.id = id; command = c; sentAtMillis = at; status = s;
            this.baselineRecoveryGeneration = baselineRecoveryGeneration;
            this.decision = decision;
        }
        public Status status() { return status; }
    }

    private final AutomationController controller;
    private final long timeoutMillis;
    private final Map<String, Request> requests = new LinkedHashMap<>();
    private int nextId = 1;
    private static final int MAX_HISTORY = 200;

    public AndroidMacroCommunicationBridge(AutomationController controller, long timeoutMillis) {
        if (controller == null || timeoutMillis <= 0) throw new IllegalArgumentException("bad bridge arguments");
        this.controller = controller;
        this.timeoutMillis = timeoutMillis;
    }


    /** Returns the request, or null when an identical request is already pending (duplicate prevention). */
    public synchronized Request send(Command c, long nowMillis) {
        if (c == null) return null;
        for (Request r : requests.values())
            if (r.command == c && (r.status == Status.ACCEPTED || r.status == Status.EXECUTING)) return null;
        MacroStatus before = controller.readStatus();
        if (!before.isConnected() && c != Command.STOP) {
            Request r = new Request("R" + nextId++, c, nowMillis, Status.REJECTED,
                before.getRecoveryGeneration(), Decision.REFUSED_NOT_CONNECTED);
            requests.put(r.id, r);
            return r;
        }
        Decision d;
        switch (c) {
            case START: d = controller.requestStart(); break;
            case STOP: d = controller.requestStop(); break;
            case RECOVER: d = controller.requestRecover(); break;
            default: d = null;
        }
        boolean accepted = d == Decision.START_REQUESTED || d == Decision.STOP_REQUESTED || d == Decision.RECOVER_REQUESTED;
        Request r = new Request("R" + nextId++, c, nowMillis, accepted ? Status.ACCEPTED : Status.REJECTED,
            before.getRecoveryGeneration(), d);
        requests.put(r.id, r);
        trimHistory();
        return r;
    }

    /** Call with the latest macro state. It moves pending requests forward or times them out. */
    public synchronized void observe(MacroStatus s, long nowMillis) {
        if (s == null) return;
        for (Request r : requests.values()) {
            if (r.status != Status.ACCEPTED && r.status != Status.EXECUTING) continue;
            if (nowMillis - r.sentAtMillis > timeoutMillis) { r.status = Status.TIMED_OUT; continue; }
            if (!s.isConnected()) continue;
            if (r.command == Command.START && s.isRunning()) r.status = Status.COMPLETED;
            else if (r.command == Command.STOP && !s.isRunning()) r.status = Status.COMPLETED;
            else if (r.command == Command.RECOVER) {
                // A recover request is not complete merely because it was dispatched.
                // Completion requires a newer recovery generation and a running macro.
                if (s.getRecoveryGeneration() > r.baselineRecoveryGeneration && s.isRunning() && !s.isRecoveryInProgress()) {
                    r.status = Status.COMPLETED;
                } else {
                    r.status = Status.EXECUTING;
                }
            } else r.status = Status.EXECUTING;
        }
    }

    public synchronized List<Request> requests() { return Collections.unmodifiableList(new ArrayList<>(requests.values())); }

    /** Retain bounded history while never evicting a command that is still pending. */
    private void trimHistory() {
        if (requests.size() <= MAX_HISTORY) return;
        Iterator<Map.Entry<String, Request>> it = requests.entrySet().iterator();
        while (requests.size() > MAX_HISTORY && it.hasNext()) {
            Request r = it.next().getValue();
            if (r.status != Status.ACCEPTED && r.status != Status.EXECUTING) it.remove();
        }
    }
}
