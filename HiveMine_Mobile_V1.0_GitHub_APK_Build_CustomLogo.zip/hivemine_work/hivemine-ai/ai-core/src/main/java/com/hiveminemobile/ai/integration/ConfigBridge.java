package com.hiveminemobile.ai.integration;
import java.util.HashMap;
import java.util.Map;
/** Phase 095 — Name-level bridge between AI settings and macro setting keys. */
public final class ConfigBridge {
    private final HashMap<String, String> aiToMacro = new HashMap<String, String>();
    public ConfigBridge() {
        aiToMacro.put("farm.enabled", "walkFirst");
        aiToMacro.put("farm.return", "returnToField");
        aiToMacro.put("ai.control", "ai_control_enabled");
        aiToMacro.put("human.mode", "humanMode");
    }
    public String macroKey(String aiKey) { return aiToMacro.get(aiKey); }
    public void put(String aiKey, String macroKey) {
        if (aiKey != null && macroKey != null) aiToMacro.put(aiKey, macroKey);
    }
    public Map<String, String> snapshot() { return new HashMap<String, String>(aiToMacro); }
}
