package com.hiveminemobile.ai.modules;

import com.hiveminemobile.ai.state.GlobalStateManager;
import com.hiveminemobile.ai.state.StateConflict;
import com.hiveminemobile.ai.state.StateFact;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Phase 012. Interprets the shared Bee Swarm state into one view. A value is used only when it is
 * observed, fresh and confident enough. Anything else is listed as unusable rather than guessed.
 */
public final class StateAI extends BaseSpecialist {
    public static final String ID = "state";
    public static final String KEY_FIELD = "field.current";
    public static final String KEY_POLLEN = "pollen.percent";
    public static final String KEY_QUEST = "quest.active";
    private static final List<String> WATCHED =
        Collections.unmodifiableList(Arrays.asList(KEY_FIELD, KEY_POLLEN, KEY_QUEST));

    public enum Reliability { RELIABLE, PARTIAL, UNRELIABLE }

    public static final class View {
        private final String field;
        private final Integer pollenPercent;
        private final String quest;
        private final List<String> unusable;
        private final int recentConflicts;
        private final Reliability reliability;

        View(String field, Integer pollenPercent, String quest, List<String> unusable,
             int recentConflicts, Reliability reliability) {
            this.field = field;
            this.pollenPercent = pollenPercent;
            this.quest = quest;
            this.unusable = unusable;
            this.recentConflicts = recentConflicts;
            this.reliability = reliability;
        }

        /** Null when the field is not usable. */
        public String getField() { return field; }
        /** Null when the pollen value is not usable. */
        public Integer getPollenPercent() { return pollenPercent; }
        public String getQuest() { return quest; }
        /** Human-readable reasons for each watched key that could not be used. */
        public List<String> getUnusable() { return unusable; }
        public int getRecentConflicts() { return recentConflicts; }
        public Reliability getReliability() { return reliability; }
    }

    private final double minimumConfidence;
    private final long conflictWindowMillis;

    public StateAI() {
        this(0.6, 120_000L);
    }

    public StateAI(double minimumConfidence, long conflictWindowMillis) {
        super(ID, "analyze.state");
        if (minimumConfidence < 0.0 || minimumConfidence > 1.0) {
            throw new IllegalArgumentException("minimumConfidence must be 0-1");
        }
        if (conflictWindowMillis < 0L) throw new IllegalArgumentException("conflictWindowMillis must not be negative");
        this.minimumConfidence = minimumConfidence;
        this.conflictWindowMillis = conflictWindowMillis;
    }

    public View interpret(GlobalStateManager state, long nowMillis) {
        List<String> unusable = new ArrayList<>();
        String field = usable(state, KEY_FIELD, nowMillis, unusable);
        String quest = usable(state, KEY_QUEST, nowMillis, unusable);
        Integer pollen = null;
        String pollenText = usable(state, KEY_POLLEN, nowMillis, unusable);
        if (pollenText != null) {
            pollen = parsePercent(pollenText);
            if (pollen == null) unusable.add(KEY_POLLEN + ": not a percentage from 0 to 100");
        }
        int conflicts = 0;
        for (StateConflict conflict : state.getConflicts()) {
            long observedAt = conflict.getIncoming().getObservedAtMillis();
            if (WATCHED.contains(conflict.getKey()) && nowMillis - observedAt <= conflictWindowMillis) conflicts++;
        }
        int usableCount = (field != null ? 1 : 0) + (pollen != null ? 1 : 0);
        Reliability reliability;
        if (usableCount == 2 && conflicts == 0) reliability = Reliability.RELIABLE;
        else if (usableCount > 0) reliability = Reliability.PARTIAL;
        else reliability = Reliability.UNRELIABLE;
        return new View(field, pollen, quest, Collections.unmodifiableList(unusable), conflicts, reliability);
    }

    private String usable(GlobalStateManager state, String key, long nowMillis, List<String> unusable) {
        StateFact fact = state.get(key);
        if (fact == null) {
            unusable.add(key + ": not observed");
            return null;
        }
        if (!state.isFresh(key, nowMillis)) {
            unusable.add(key + ": stale");
            return null;
        }
        if (fact.getConfidence() < minimumConfidence) {
            unusable.add(key + ": confidence below " + minimumConfidence);
            return null;
        }
        return fact.getValue();
    }

    private static Integer parsePercent(String text) {
        String digits = text.trim();
        if (digits.endsWith("%")) digits = digits.substring(0, digits.length() - 1).trim();
        try {
            int value = Integer.parseInt(digits);
            return value >= 0 && value <= 100 ? Integer.valueOf(value) : null;
        } catch (NumberFormatException notANumber) {
            return null;
        }
    }
}
