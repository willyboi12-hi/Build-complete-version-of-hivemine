package com.hiveminemobile.ai.modules;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Phase 017. Fits a straight line to timed readings and forecasts when a value will reach a target
 * (for example a full pollen bag) or where it will be later. Confidence reflects the number of
 * readings and how closely they follow the line.
 */
public final class PredictionAI extends BaseSpecialist {
    public static final String ID = "prediction";
    private static final int MIN_POINTS = 3;
    private static final int FULL_CONFIDENCE_POINTS = 10;
    private static final long MINUTE = 60_000L;

    public static final class Point {
        private final long atMillis;
        private final double value;

        public Point(long atMillis, double value) {
            if (Double.isNaN(value) || Double.isInfinite(value)) throw new IllegalArgumentException("value must be finite");
            this.atMillis = atMillis;
            this.value = value;
        }
    }

    public static final class Fit {
        private final int points;
        private final double slopePerMinute;
        private final double rSquared;
        private final double lastValue;
        private final long lastAtMillis;

        Fit(int points, double slopePerMinute, double rSquared, double lastValue, long lastAtMillis) {
            this.points = points;
            this.slopePerMinute = slopePerMinute;
            this.rSquared = rSquared;
            this.lastValue = lastValue;
            this.lastAtMillis = lastAtMillis;
        }

        public int getPoints() { return points; }
        public double getSlopePerMinute() { return slopePerMinute; }
        public double getRSquared() { return rSquared; }
        public double getLastValue() { return lastValue; }
        public long getLastAtMillis() { return lastAtMillis; }
    }

    public static final class Forecast {
        private final Double minutesToTarget;
        private final double ratePerMinute;
        private final double confidence;
        private final String note;

        Forecast(Double minutesToTarget, double ratePerMinute, double confidence, String note) {
            this.minutesToTarget = minutesToTarget;
            this.ratePerMinute = ratePerMinute;
            this.confidence = confidence;
            this.note = note;
        }

        /** Null when no estimate can be made. */
        public Double getMinutesToTarget() { return minutesToTarget; }
        public double getRatePerMinute() { return ratePerMinute; }
        /** 0 to 1: grows with readings and with how closely they follow the line. */
        public double getConfidence() { return confidence; }
        public String getNote() { return note; }
    }

    public PredictionAI() {
        super(ID, "analyze.forecast");
    }

    /** Least-squares line through the readings, or null with fewer than three distinct times. */
    public Fit fit(List<Point> series) {
        List<Point> sorted = sorted(series);
        int n = sorted.size();
        if (n < MIN_POINTS) return null;
        long origin = sorted.get(0).atMillis;
        double meanT = 0.0;
        double meanY = 0.0;
        for (Point point : sorted) {
            meanT += minutesSince(origin, point);
            meanY += point.value;
        }
        meanT /= n;
        meanY /= n;
        double sxx = 0.0;
        double sxy = 0.0;
        double syy = 0.0;
        for (Point point : sorted) {
            double dt = minutesSince(origin, point) - meanT;
            double dy = point.value - meanY;
            sxx += dt * dt;
            sxy += dt * dy;
            syy += dy * dy;
        }
        if (sxx == 0.0) return null;
        double slope = sxy / sxx;
        double intercept = meanY - slope * meanT;
        double residual = 0.0;
        for (Point point : sorted) {
            double error = point.value - (intercept + slope * minutesSince(origin, point));
            residual += error * error;
        }
        double rSquared = syy == 0.0 ? 1.0 : Math.max(0.0, 1.0 - residual / syy);
        Point last = sorted.get(n - 1);
        return new Fit(n, slope, rSquared, last.value, last.atMillis);
    }

    /**
     * Minutes until the latest rise reaches the target. The rise starts at the last reading that
     * dropped, so a bag that was emptied at the hive is forecast from its new start.
     */
    public Forecast timeToTarget(List<Point> series, double target) {
        List<Point> sorted = sorted(series);
        int start = 0;
        for (int i = 1; i < sorted.size(); i++) {
            if (sorted.get(i).value < sorted.get(i - 1).value) start = i;
        }
        Fit fit = fit(sorted.subList(start, sorted.size()));
        if (fit == null) return new Forecast(null, 0.0, 0.0, "need at least 3 readings since the last drop");
        if (fit.slopePerMinute <= 0.0) return new Forecast(null, fit.slopePerMinute, 0.0, "not rising, so no time to target");
        double confidence = confidence(fit);
        if (fit.lastValue >= target) return new Forecast(0.0, fit.slopePerMinute, confidence, "already at or past the target");
        double minutes = (target - fit.lastValue) / fit.slopePerMinute;
        return new Forecast(minutes, fit.slopePerMinute, confidence, "estimate from the latest rise");
    }

    /** Projects the fitted line forward from the last reading, or null when no fit is possible. */
    public Double projectValue(List<Point> series, double minutesAhead) {
        Fit fit = fit(series);
        if (fit == null) return null;
        return fit.lastValue + fit.slopePerMinute * minutesAhead;
    }

    private static double confidence(Fit fit) {
        double coverage = Math.min(1.0, fit.points / (double) FULL_CONFIDENCE_POINTS);
        return coverage * fit.rSquared;
    }

    private static double minutesSince(long origin, Point point) {
        return (point.atMillis - origin) / (double) MINUTE;
    }

    private static List<Point> sorted(List<Point> series) {
        List<Point> copy = new ArrayList<>(series);
        Collections.sort(copy, new Comparator<Point>() {
            @Override public int compare(Point left, Point right) {
                return Long.compare(left.atMillis, right.atMillis);
            }
        });
        return copy;
    }
}
