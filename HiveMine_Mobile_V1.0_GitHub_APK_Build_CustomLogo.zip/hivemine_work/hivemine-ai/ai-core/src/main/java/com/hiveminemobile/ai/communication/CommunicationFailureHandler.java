package com.hiveminemobile.ai.communication;
import java.util.ArrayList;
import java.util.List;
public final class CommunicationFailureHandler {
    private final ArrayList<String> failures = new ArrayList<String>();
    public void onFailure(String reason) {
        failures.add(reason == null ? "unknown" : reason);
        while (failures.size() > 40) failures.remove(0);
    }
    public int count() { return failures.size(); }
    public List<String> recent() { return new ArrayList<String>(failures); }
    public boolean shouldDegrade() { return failures.size() >= 5; }
}
