package com.hiveminemobile.ai.modules;

import com.hiveminemobile.ai.Identifiers;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Phase 024. Ranks strategies by a weighted score over named criteria. A strategy that lacks a score
 * for a criterion gets zero for it and the gap is reported, so missing data cannot look like a win.
 */
public final class StrategyAI extends BaseSpecialist {
    public static final String ID = "strategy";

    public static final class Criterion {
        private final String name;
        private final double weight;

        public Criterion(String name, double weight) {
            if (!Identifiers.isValid(name)) throw new IllegalArgumentException("criterion name is invalid");
            if (!(weight > 0.0) || Double.isInfinite(weight)) throw new IllegalArgumentException("weight must be positive");
            this.name = name;
            this.weight = weight;
        }
    }

    public static final class Option {
        private final String name;
        private final Map<String, Double> scores;

        public Option(String name, Map<String, Double> scores) {
            if (!Identifiers.isValid(name)) throw new IllegalArgumentException("option name is invalid");
            Map<String, Double> copy = new LinkedHashMap<>();
            for (Map.Entry<String, Double> entry : scores.entrySet()) {
                double value = entry.getValue();
                if (!(value >= 0.0 && value <= 1.0)) throw new IllegalArgumentException("scores must be 0-1");
                copy.put(entry.getKey(), value);
            }
            this.name = name;
            this.scores = Collections.unmodifiableMap(copy);
        }
    }

    public static final class Scored {
        private final String name;
        private final double score;
        private final int missingCriteria;

        Scored(String name, double score, int missingCriteria) {
            this.name = name;
            this.score = score;
            this.missingCriteria = missingCriteria;
        }

        public String getName() { return name; }
        /** Weighted score from 0 to 1. */
        public double getScore() { return score; }
        public int getMissingCriteria() { return missingCriteria; }
    }

    public StrategyAI() {
        super(ID, "analyze.strategy");
    }

    public List<Scored> rank(List<Criterion> criteria, List<Option> options) {
        if (criteria == null || criteria.isEmpty()) throw new IllegalArgumentException("at least one criterion is required");
        double totalWeight = 0.0;
        for (Criterion criterion : criteria) totalWeight += criterion.weight;
        List<Scored> ranked = new ArrayList<>();
        for (Option option : options) {
            double weighted = 0.0;
            int missing = 0;
            for (Criterion criterion : criteria) {
                Double score = option.scores.get(criterion.name);
                if (score == null) missing++;
                else weighted += criterion.weight * score;
            }
            ranked.add(new Scored(option.name, weighted / totalWeight, missing));
        }
        Collections.sort(ranked, new Comparator<Scored>() {
            @Override public int compare(Scored left, Scored right) {
                int byScore = Double.compare(right.score, left.score);
                if (byScore != 0) return byScore;
                int byMissing = Integer.compare(left.missingCriteria, right.missingCriteria);
                return byMissing != 0 ? byMissing : left.name.compareTo(right.name);
            }
        });
        return Collections.unmodifiableList(ranked);
    }
}
