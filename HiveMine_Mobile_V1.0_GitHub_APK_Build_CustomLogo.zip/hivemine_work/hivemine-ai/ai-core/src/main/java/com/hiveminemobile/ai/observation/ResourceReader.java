package com.hiveminemobile.ai.observation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/** Phase 045. Turns OCR text for each resource into a count. Unreadable text is reported, never guessed. */
public final class ResourceReader {
    public static final class Reading {
        private final String resource;
        private final Long count;
        private final String raw;

        Reading(String resource, Long count, String raw) {
            this.resource = resource;
            this.count = count;
            this.raw = raw;
        }

        public String getResource() { return resource; }
        /** Null when the text could not be read as a count. */
        public Long getCount() { return count; }
        public String getRaw() { return raw; }
    }

    public List<Reading> read(Map<String, String> textByResource) {
        List<Reading> readings = new ArrayList<>();
        for (Map.Entry<String, String> entry : new TreeMap<>(textByResource).entrySet()) {
            readings.add(new Reading(entry.getKey(), TextReader.parseCount(entry.getValue()), entry.getValue()));
        }
        return Collections.unmodifiableList(readings);
    }
}
