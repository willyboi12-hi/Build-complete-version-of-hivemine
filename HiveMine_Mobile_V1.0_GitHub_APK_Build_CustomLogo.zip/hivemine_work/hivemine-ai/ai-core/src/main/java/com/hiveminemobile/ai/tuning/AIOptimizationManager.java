package com.hiveminemobile.ai.tuning;

import java.util.*;

/**
 * Phase 084: measures subsystem time, memory, and repeated work, then reports recommendations.
 * It only recommends. It never changes which subsystems run.
 */
public final class AIOptimizationManager {
    private final long slowMillis, memoryLimitBytes;
    private final Map<String, List<Long>> subsystemMillis = new TreeMap<>();
    private final Map<String, Integer> taskRuns = new TreeMap<>();
    private long peakMemory;

    public AIOptimizationManager(long slowMillis, long memoryLimitBytes) {
        if (slowMillis < 0 || memoryLimitBytes <= 0) throw new IllegalArgumentException("thresholds must be positive");
        this.slowMillis = slowMillis;
        this.memoryLimitBytes = memoryLimitBytes;
    }

    public synchronized void recordSubsystem(String subsystem, long millis) {
        if (blank(subsystem) || millis < 0) return;
        subsystemMillis.computeIfAbsent(subsystem.trim(), k -> new ArrayList<>()).add(millis);
    }

    public synchronized void recordTask(String taskKey) { if (!blank(taskKey)) taskRuns.merge(taskKey.trim(), 1, Integer::sum); }

    public synchronized void sampleMemory(long bytes) { if (bytes > peakMemory) peakMemory = bytes; }

    public synchronized double averageMillis(String subsystem) {
        List<Long> l = subsystemMillis.get(subsystem);
        if (l == null || l.isEmpty()) return Double.NaN;
        long sum = 0; for (long v : l) sum += v;
        return (double) sum / l.size();
    }

    public synchronized List<String> recommendations() {
        List<String> out = new ArrayList<>();
        for (String s : subsystemMillis.keySet()) {
            double avg = averageMillis(s);
            if (avg > slowMillis) out.add("Slow subsystem " + s + " (avg " + Math.round(avg) + " ms): reduce how often it runs");
        }
        for (Map.Entry<String, Integer> e : taskRuns.entrySet())
            if (e.getValue() > 1) out.add("Repeated work " + e.getKey() + " x" + e.getValue() + ": cache the result");
        if (peakMemory > memoryLimitBytes) out.add("Peak memory " + peakMemory + " B exceeds limit: reduce retained data");
        return out;
    }

    private static boolean blank(String s) { return s == null || s.trim().isEmpty(); }
}
