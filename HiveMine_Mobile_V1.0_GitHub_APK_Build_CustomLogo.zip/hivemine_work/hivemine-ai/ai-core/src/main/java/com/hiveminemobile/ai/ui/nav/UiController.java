package com.hiveminemobile.ai.ui.nav;

import com.hiveminemobile.ai.control.AutomationController;
import com.hiveminemobile.ai.control.MacroPort;
import com.hiveminemobile.ai.loot.LootManager;
import com.hiveminemobile.ai.ui.chat.AiManagerService;
import com.hiveminemobile.ai.ui.screens.ScreenContent;
import com.hiveminemobile.ai.ui.screens.ScreenState;

/** Central UI controller — every nav section routes here. */
public final class UiController {
    private final ScreenState state = new ScreenState();
    private final ScreenContent content = new ScreenContent();
    private final AiManagerService ai = new AiManagerService();
    private final LootManager loot = new LootManager();
    private AutomationController controller;

    public void bindMacro(MacroPort port) {
        if (port == null) return;
        controller = new AutomationController(port);
        ai.bind(port, controller);
        state.bindMacro(port.readStatus());
        state.log("Macro port bound");
    }

    public ScreenState state() { return state; }

    public ScreenContent.Model open(NavSection section) {
        state.section = section == null ? NavSection.HOME : section;
        state.log("Open " + state.section.title);
        return content.render(state);
    }

    public String runAction(String action) {
        if (action == null) return "";
        if (action.startsWith("Recipe:")) {
            String name = action.substring(7).trim();
            int qty = 1;
            int x = name.lastIndexOf(" x");
            if (x > 0) {
                try { qty = Integer.parseInt(name.substring(x + 2).trim()); name = name.substring(0, x).trim(); } catch (Exception ignored) {}
            }
            loot.selectRecipe(name, qty);
            loot.applyTo(state.settings);
            state.currentTask = "Farm for " + name + " x" + qty;
            state.log("Recipe " + name + " x" + qty);
            return loot.statusReport();
        }
        if (action.startsWith("Plan:")) {
            String mat = action.substring(5).trim();
            loot.setGoal(mat, 0);
            loot.applyTo(state.settings);
            state.currentTask = "Farm materials: " + loot.activeGoal();
            state.log("Loot plan " + mat + " -> " + (loot.activePlan() == null ? "?" : loot.activePlan().primaryField));
            return loot.statusReport();
        }
        if (action.startsWith("Preset:")) {
            state.settings.applyPreset(action.substring(7).trim());
            state.log("Preset applied: " + action);
            return "Preset applied (supported settings only).";
        }
        if ("Start Macro".equals(action)) {
            if (controller == null) return "No macro connection.";
            if (!state.aiControlEnabled) return "Enable AI control in Settings first.";
            controller.setAiControlEnabled(true);
            AutomationController.Decision d = controller.requestStart();
            state.log("Start: " + d);
            return "Start result: " + d;
        }
        if ("Stop Macro".equals(action)) {
            if (controller == null) return "No macro connection.";
            AutomationController.Decision d = controller.requestStop();
            state.log("Stop: " + d);
            return "Stop result: " + d;
        }
        if ("Enable AI Control".equals(action) || "Toggle AI Control".equals(action)) {
            state.aiControlEnabled = !state.aiControlEnabled;
            if (controller != null) controller.setAiControlEnabled(state.aiControlEnabled);
            state.settings.set("aiControlEnabled", String.valueOf(state.aiControlEnabled));
            state.log("AI control=" + state.aiControlEnabled);
            return "AI control: " + state.aiControlEnabled;
        }
        if ("Enable Quest Smart".equals(action)) {
            state.settings.set("questSmart", "true");
            return "questSmart=true";
        }
        if ("Disable Quest Smart".equals(action)) {
            state.settings.set("questSmart", "false");
            return "questSmart=false";
        }
        return "Action not mapped: " + action;
    }

    public String chat(String text, boolean apply, boolean allowStart) {
        return ai.handle(text, state, apply, allowStart);
    }
}
