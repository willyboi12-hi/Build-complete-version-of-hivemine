package com.hiveminemobile.ai.release;
import java.util.ArrayList;
import java.util.List;
/** Release gate checklist for V2. */
public final class ReleaseChecklist {
    public static final class Item {
        public final String id; public final boolean done; public final String note;
        public Item(String id, boolean done, String note) {
            this.id = id; this.done = done; this.note = note == null ? "" : note;
        }
    }
    private final ArrayList<Item> items = new ArrayList<Item>();
    public void add(String id, boolean done, String note) { items.add(new Item(id, done, note)); }
    public boolean allCriticalDone(String... criticalIds) {
        for (String id : criticalIds) {
            boolean found = false, ok = false;
            for (Item i : items) {
                if (i.id.equals(id)) { found = true; ok = i.done; break; }
            }
            if (!found || !ok) return false;
        }
        return true;
    }
    public List<Item> items() { return new ArrayList<Item>(items); }
    public String toMarkdown() {
        StringBuilder sb = new StringBuilder("# Release checklist\n\n");
        for (Item i : items) sb.append(i.done ? "- [x] " : "- [ ] ").append(i.id).append(" ").append(i.note).append('\n');
        return sb.toString();
    }
}
