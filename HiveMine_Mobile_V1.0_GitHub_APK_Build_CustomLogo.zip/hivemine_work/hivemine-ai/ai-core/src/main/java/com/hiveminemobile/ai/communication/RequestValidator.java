package com.hiveminemobile.ai.communication;
/** Validates request ids and payloads. */
public final class RequestValidator {
    public boolean validId(String id) { return id != null && id.length() > 0 && id.length() <= 64; }
    public boolean validPayload(String payload) { return payload != null && payload.length() <= 8192; }
    public boolean valid(String id, String payload) { return validId(id) && validPayload(payload); }
}
