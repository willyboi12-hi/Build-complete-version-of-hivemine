package com.hiveminemobile.ai.manager;
import com.hiveminemobile.ai.merge.SpecialistCatalogFactory;
import com.hiveminemobile.ai.modules.BaseSpecialist;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
/** Manager-owned specialist registry backed by the V2 catalog. */
public final class ManagerSpecialistRegistry {
    private final LinkedHashMap<String, BaseSpecialist> map = new LinkedHashMap<String, BaseSpecialist>();
    public void loadDefaults() {
        map.clear();
        for (BaseSpecialist s : new SpecialistCatalogFactory().all()) map.put(s.getId(), s);
    }
    public void register(BaseSpecialist s) { if (s != null) map.put(s.getId(), s); }
    public BaseSpecialist get(String id) { return map.get(id); }
    public int size() { return map.size(); }
    public List<String> ids() { return new ArrayList<String>(map.keySet()); }
}
