package com.hiveminemobile.ai.ui.chat;

import com.hiveminemobile.ai.bss.BssIntentParser;
import com.hiveminemobile.ai.bss.BssPlanBuilder;
import com.hiveminemobile.ai.control.AutomationController;
import com.hiveminemobile.ai.control.MacroPort;
import com.hiveminemobile.ai.control.MacroStatus;
import com.hiveminemobile.ai.manager.runtime.ManagerRuntimeService;
import com.hiveminemobile.ai.AIConfiguration;
import com.hiveminemobile.ai.android.AndroidMacroCommunicationBridge;
import com.hiveminemobile.ai.loot.LootManager;
import com.hiveminemobile.ai.ui.screens.ScreenState;

/**
 * User-facing AI Manager: parse NL, propose plan, apply supported config, optional macro control.
 */
public final class AiManagerService {
    private final BssIntentParser parser = new BssIntentParser();
    private final BssPlanBuilder plans = new BssPlanBuilder();
    private final LootManager loot = new LootManager();
    public interface ConfigurationApplier {
        void apply(java.util.Map<String, String> settings);
    }
    public interface EventLogger {
        void record(String eventType, String detail);
    }

    private MacroPort port;
    private AutomationController controller;
    private ConfigurationApplier configurationApplier;
    private AndroidMacroCommunicationBridge communicationBridge;
    private EventLogger eventLogger;
    private ManagerRuntimeService managerRuntime;

    public void bind(MacroPort port, AutomationController controller) {
        this.port = port;
        this.controller = controller;
    }

    public LootManager loot() { return loot; }

    public void bindConfigurationApplier(ConfigurationApplier applier) {
        this.configurationApplier = applier;
    }

    /** Binds commands to the same verified request/completion bridge used by the Android runtime monitor. */
    public void bindCommunicationBridge(AndroidMacroCommunicationBridge bridge) {
        this.communicationBridge = bridge;
    }

    public void bindEventLogger(EventLogger logger) { this.eventLogger = logger; }

    /** Binds the closed-loop Manager -> specialist -> scheduler -> authorized macro runtime. */
    public synchronized void bindManagerRuntime(ManagerRuntimeService runtime) { this.managerRuntime = runtime; }

    /** Advances the manager runtime from the authoritative live macro status. */
    public synchronized String tickManager(MacroStatus status, long nowMillis) {
        if (managerRuntime == null || status == null) return "";
        if (!managerRuntime.isStarted()) {
            try { managerRuntime.start(); } catch (Exception failure) { return "Manager runtime unavailable: " + failure.getMessage(); }
        }
        String decision = managerRuntime.lastDecision();
        managerRuntime.tick(status, nowMillis);
        return managerRuntime.lastDecision().equals(decision) ? "" : managerRuntime.lastDecision();
    }

    private void log(ScreenState state, String type, String detail) {
        state.log(detail);
        if (eventLogger != null) eventLogger.record(type, detail);
    }

    public String handle(String userText, ScreenState state, boolean apply, boolean allowStart) {
        if (state == null) return "No UI state.";
        state.chatHistory.add("You: " + userText);
        BssIntentParser.Intent intent = parser.parse(userText);
        BssPlanBuilder.Plan plan = plans.build(intent, state.settings);
        StringBuilder summary = new StringBuilder("Plan:\n");
        for (BssPlanBuilder.Step s : plan.steps) {
            summary.append(s.supported ? "  [OK] " : "  [NO] ").append(s.action)
                    .append(" — ").append(s.detail).append('\n');
        }
        if (intent.materialGoal != null) {
            loot.setGoal(intent.materialGoal, 0);
            summary.append("  [OK] LOOT_PLAN field=").append(loot.activePlan().primaryField)
                    .append(" strategy=").append(loot.activePlan().strategy).append('\n');
            for (String n : loot.activePlan().notes) {
                summary.append("  note: ").append(n).append('\n');
            }
        }
        state.lastPlanSummary = summary.toString();
        if (!apply) {
            String msg = summary + "\nSay apply/confirm to run supported config changes.";
            state.chatHistory.add("AI: " + msg);
            log(state, "PLAN_PROPOSED", "AI proposed plan");
            return msg;
        }
        java.util.Map<String, String> previousSettings = state.settings.snapshot();
        plans.applySupported(plan, state.settings);
        if (intent.materialGoal != null) {
            loot.setGoal(intent.materialGoal, 0);
            loot.applyTo(state.settings);
        }
        java.util.Map<String, String> proposedSettings = state.settings.snapshot();
        boolean settingsChanged = !previousSettings.equals(proposedSettings);
        String settingsFailure = null;
        boolean settingsPersisted = false;
        if (settingsChanged) {
            if (configurationApplier == null) {
                // Headless/JVM UI instances have no Android persistence layer. Keep the
                // proposed settings in the in-memory ScreenState instead of falsely reporting
                // a storage failure. Android binds a real ConfigurationApplier at startup.
                log(state, "SETTINGS_APPLIED_SESSION", "AI settings applied to the current in-memory session; no Android persistence layer is bound");
            } else try {
                // Apply once after the complete proposal has been assembled, avoiding partial loot/config writes.
                configurationApplier.apply(proposedSettings);
                settingsPersisted = true;
            } catch (RuntimeException failure) {
                restoreSettings(state, previousSettings);
                settingsFailure = "Settings were not saved: " + safeMessage(failure);
                log(state, "SETTINGS_FAILED", "Settings save failed: " + safeMessage(failure));
            }
        }
        if (intent.materialGoal != null && settingsFailure == null) {
            state.currentTask = "Farm materials: " + loot.activeGoal();
            log(state, "LOOT_PLAN_APPLIED", "Loot plan applied: " + loot.activeGoal() + " @ " + loot.activePlan().primaryField);
        }
        if (settingsChanged) log(state, "SETTINGS_APPLIED", settingsPersisted
            ? "AI settings committed and verified"
            : "AI settings applied to the current in-memory session");
        StringBuilder result = new StringBuilder(summary);
        if (settingsFailure != null) result.append("\n").append(settingsFailure).append('\n');
        else result.append(settingsChanged
            ? (settingsPersisted ? "\nSettings saved and verified.\n"
                : "\nSettings applied to the current session (not persisted outside this UI instance).\n")
            : "\nNo configuration changes were needed.\n");
        if (managerRuntime != null && settingsFailure == null && (intent.startMacro || intent.materialGoal != null)) managerRuntime.setUserWantsFarm(true);
        if (managerRuntime != null && intent.stopMacro) managerRuntime.setUserWantsFarm(false);
        if (intent.stopMacro && controller != null) {
            if (communicationBridge != null) {
                AndroidMacroCommunicationBridge.Request request = communicationBridge.send(
                    AndroidMacroCommunicationBridge.Command.STOP, System.currentTimeMillis());
                appendRequestResult(result, state, "Stop", request);
            } else {
                AutomationController.Decision d = controller.requestStop();
                result.append("Stop request: ").append(d).append(" (awaiting status confirmation)\n");
                log(state, "COMMAND_REQUESTED", "Stop requested: " + d);
            }
        } else if (intent.startMacro && allowStart && controller != null) {
            if (settingsFailure != null) {
                result.append("Start not executed because the requested settings failed to save.\n");
            } else if (!state.aiControlEnabled) {
                result.append("Start blocked: enable AI control in Settings first.\n");
            } else if (communicationBridge != null) {
                AndroidMacroCommunicationBridge.Request request = communicationBridge.send(
                    AndroidMacroCommunicationBridge.Command.START, System.currentTimeMillis());
                appendRequestResult(result, state, "Start", request);
            } else {
                AutomationController.Decision d = controller.requestStart();
                result.append("Start request: ").append(d).append(" (awaiting status confirmation)\n");
                log(state, "COMMAND_REQUESTED", "Start requested: " + d);
            }
        } else if (intent.startMacro && !allowStart) {
            result.append("Start not executed (confirmation required).\n");
        }
        for (String u : intent.unsupported) result.append("Unavailable: ").append(u).append('\n');
        String msg = result.toString();
        state.chatHistory.add("AI: " + msg);
        return msg;
    }

    private static void restoreSettings(ScreenState state, java.util.Map<String, String> values) {
        for (java.util.Map.Entry<String, String> entry : values.entrySet()) {
            state.settings.set(entry.getKey(), entry.getValue());
        }
    }

    private static String safeMessage(RuntimeException failure) {
        String detail = failure.getMessage();
        if (detail == null || detail.trim().isEmpty()) detail = failure.getClass().getSimpleName();
        return detail.length() > 180 ? detail.substring(0, 180) : detail;
    }

    private void appendRequestResult(StringBuilder result, ScreenState state, String label,
                                            AndroidMacroCommunicationBridge.Request request) {
        if (request == null) {
            result.append(label).append(" not sent: an identical command is already pending.\n");
            log(state, "COMMAND_DUPLICATE", label + " command already pending; duplicate suppressed");
            return;
        }
        result.append(label).append(" request ").append(request.id).append(": ")
            .append(request.status()).append(" (waiting for macro confirmation).\n");
        log(state, "COMMAND_REQUESTED", label + " request " + request.id + " " + request.status());
    }

}
