package com.hiveminemobile.ai.modules;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.List;

/**
 * V2 specialist (safety). Blocks actions when safety flags are raised.
 * Analyzer only — no Android, no macro control.
 */
public final class SafetyAI extends BaseSpecialist {
    public static final String ID = "safety";

    public SafetyAI() {
        super(ID, "safety-block");
    }

    public static final class Finding {
        public final String code;
        public final String detail;
        public final double score;
        public Finding(String code, String detail, double score) {
            this.code = code == null ? "" : code;
            this.detail = detail == null ? "" : detail;
            this.score = score;
        }
    }

    /** Generic ranked findings from labeled numeric signals. */
    public List<Finding> analyze(Map<String, Double> signals) {
        ArrayList<Finding> out = new ArrayList<Finding>();
        if (signals == null || signals.isEmpty()) {
            out.add(new Finding("empty", "no signals", 0));
            return Collections.unmodifiableList(out);
        }
        for (Map.Entry<String, Double> e : signals.entrySet()) {
            double v = e.getValue() == null ? 0 : e.getValue();
            out.add(new Finding(e.getKey(), "value=" + v, v));
        }
        return Collections.unmodifiableList(out);
    }

    public Finding best(Map<String, Double> signals) {
        List<Finding> all = analyze(signals);
        Finding top = all.get(0);
        for (Finding f : all) if (f.score > top.score) top = f;
        return top;
    }

    /** Smarter ordering using SignalIntelligence spread-aware ranking. */
    public List<String> rankedInsights(Map<String, Double> signals) {
        return SignalIntelligence.rankedKeys(signals);
    }

    public double confidenceSpread(Map<String, Double> signals) {
        return SignalIntelligence.spread(signals);
    }
}
