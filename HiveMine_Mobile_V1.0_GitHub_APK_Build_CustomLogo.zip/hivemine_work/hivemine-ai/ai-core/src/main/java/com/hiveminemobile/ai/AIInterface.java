package com.hiveminemobile.ai;

import java.util.Set;

/**
 * Contract implemented by an independently managed AI subsystem.
 * This phase defines lifecycle and capability metadata only; it does not grant
 * a subsystem permission to control Android or interact with Roblox.
 */
public interface AIInterface {
    /** Stable lower-case identifier, for example "vision" or "state". */
    String getId();

    /** Module-owned version string. */
    String getVersion();

    /** Immutable or defensive-copy set of capabilities offered by this module. */
    Set<String> getCapabilities();

    /** Called once during engine initialization. */
    void onInitialize(AIConfiguration configuration) throws Exception;

    /** Called during shutdown; implementations should release owned resources. */
    void onShutdown() throws Exception;
}
