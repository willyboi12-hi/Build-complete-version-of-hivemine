package com.hiveminemobile.ai.task;

/** Kind of work a task represents. None of these categories performs a game or device action. */
public enum TaskCategory { OBSERVATION, ANALYSIS, RECOVERY, MAINTENANCE }
