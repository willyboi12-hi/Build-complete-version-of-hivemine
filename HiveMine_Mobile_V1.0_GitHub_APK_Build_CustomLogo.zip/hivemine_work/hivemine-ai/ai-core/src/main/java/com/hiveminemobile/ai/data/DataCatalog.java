package com.hiveminemobile.ai.data;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
/** Catalog of logical datasets the AI may read. */
public final class DataCatalog {
    private final LinkedHashSet<String> datasets = new LinkedHashSet<String>();
    public void register(String name) { if (name != null) datasets.add(name); }
    public boolean has(String name) { return datasets.contains(name); }
    public List<String> list() { return Collections.unmodifiableList(new ArrayList<String>(datasets)); }
}
