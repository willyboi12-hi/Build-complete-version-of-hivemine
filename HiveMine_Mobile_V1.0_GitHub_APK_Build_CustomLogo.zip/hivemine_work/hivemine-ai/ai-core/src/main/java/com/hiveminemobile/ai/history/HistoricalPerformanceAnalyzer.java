package com.hiveminemobile.ai.history;

import com.hiveminemobile.ai.memory.DecisionRecord;
import java.util.*;

/** Phase 081: analyzes recorded decisions. Incomplete records are counted, never guessed at. */
public final class HistoricalPerformanceAnalyzer {

    public static final class Stat {
        public int success, failure;
        public double successRate() { int n = success + failure; return n == 0 ? 0.0 : (double) success / n; }
    }

    public static final class Report {
        public final Map<String, Stat> byCapability;
        public final List<String> repeatedFailures;
        public final List<String> successfulDecisions;
        public final int incomplete;
        Report(Map<String, Stat> c, List<String> f, List<String> s, int inc) {
            byCapability = Collections.unmodifiableMap(c);
            repeatedFailures = Collections.unmodifiableList(f);
            successfulDecisions = Collections.unmodifiableList(s);
            incomplete = inc;
        }
        public String toMarkdown() {
            StringBuilder b = new StringBuilder("# Performance report\n\n");
            for (Map.Entry<String, Stat> e : byCapability.entrySet())
                b.append("- ").append(e.getKey()).append(": ").append(e.getValue().success).append(" ok, ")
                 .append(e.getValue().failure).append(" failed\n");
            b.append("\nRepeated failures: ").append(repeatedFailures).append('\n');
            b.append("Successful decisions: ").append(successfulDecisions).append('\n');
            b.append("Incomplete records: ").append(incomplete).append('\n');
            return b.toString();
        }
    }

    public Report analyze(List<DecisionRecord> records) {
        Map<String, Stat> byCap = new TreeMap<>();
        Map<String, Stat> byDecision = new TreeMap<>();
        int incomplete = 0;
        if (records != null) for (DecisionRecord r : records) {
            if (r == null || r.getOutcome() == null || blank(r.getCapability()) || blank(r.getDecision())) { incomplete++; continue; }
            if (r.getOutcome() == DecisionRecord.Outcome.UNKNOWN) continue;
            boolean ok = r.getOutcome() == DecisionRecord.Outcome.SUCCESS;
            add(byCap, r.getCapability().trim(), ok);
            add(byDecision, r.getDecision().trim(), ok);
        }
        List<String> repeated = new ArrayList<>(), good = new ArrayList<>();
        for (Map.Entry<String, Stat> e : byDecision.entrySet()) {
            if (e.getValue().failure >= 2 && e.getValue().failure > e.getValue().success) repeated.add(e.getKey());
            if (e.getValue().success >= 2 && e.getValue().success > e.getValue().failure) good.add(e.getKey());
        }
        return new Report(byCap, repeated, good, incomplete);
    }

    /** Success rate of each decision, to compare two configuration profiles. Missing profiles give NaN. */
    public double rateOf(List<DecisionRecord> records, String decision) {
        Stat s = new Stat();
        if (records != null) for (DecisionRecord r : records) {
            if (r == null || r.getOutcome() == null || blank(r.getDecision())) continue;
            if (!r.getDecision().trim().equals(decision)) continue;
            if (r.getOutcome() == DecisionRecord.Outcome.SUCCESS) s.success++;
            else if (r.getOutcome() == DecisionRecord.Outcome.FAILURE) s.failure++;
        }
        return s.success + s.failure == 0 ? Double.NaN : s.successRate();
    }

    private static void add(Map<String, Stat> m, String k, boolean ok) {
        Stat s = m.get(k);
        if (s == null) { s = new Stat(); m.put(k, s); }
        if (ok) s.success++; else s.failure++;
    }
    private static boolean blank(String s) { return s == null || s.trim().isEmpty(); }
}
