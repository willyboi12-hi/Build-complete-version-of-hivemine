package com.hiveminemobile.ai.modules;

import com.hiveminemobile.ai.memory.DecisionRecord;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Phase 019. Summarises past outcomes per capability so the manager can see which work has been
 * reliable. It draws conclusions only after enough evidence and never changes policy on its own.
 */
public final class LearningAI extends BaseSpecialist {
    public static final String ID = "learning";
    private static final double STRONG = 0.8;
    private static final double WEAK = 0.5;
    private static final double TREND_SHIFT = 0.2;

    public static final class Insight {
        private final String capability;
        private final int evidence;
        private final double successRate;
        private final String trend;
        private final String advice;

        Insight(String capability, int evidence, double successRate, String trend, String advice) {
            this.capability = capability;
            this.evidence = evidence;
            this.successRate = successRate;
            this.trend = trend;
            this.advice = advice;
        }

        public String getCapability() { return capability; }
        /** Number of SUCCESS and FAILURE results considered. */
        public int getEvidence() { return evidence; }
        public double getSuccessRate() { return successRate; }
        public String getTrend() { return trend; }
        public String getAdvice() { return advice; }
    }

    private final int minimumEvidence;

    public LearningAI() {
        this(5);
    }

    public LearningAI(int minimumEvidence) {
        super(ID, "analyze.history");
        if (minimumEvidence < 1) throw new IllegalArgumentException("minimumEvidence must be at least 1");
        this.minimumEvidence = minimumEvidence;
    }

    public List<Insight> learn(List<DecisionRecord> history) {
        List<DecisionRecord> ordered = new ArrayList<>(history);
        Collections.sort(ordered, new Comparator<DecisionRecord>() {
            @Override public int compare(DecisionRecord left, DecisionRecord right) {
                return Long.compare(left.getSequence(), right.getSequence());
            }
        });
        Map<String, List<DecisionRecord.Outcome>> byCapability = new TreeMap<>();
        for (DecisionRecord record : ordered) {
            if (record.getCapability() == null || record.getOutcome() == DecisionRecord.Outcome.UNKNOWN) continue;
            List<DecisionRecord.Outcome> outcomes = byCapability.get(record.getCapability());
            if (outcomes == null) {
                outcomes = new ArrayList<>();
                byCapability.put(record.getCapability(), outcomes);
            }
            outcomes.add(record.getOutcome());
        }
        List<Insight> insights = new ArrayList<>();
        for (Map.Entry<String, List<DecisionRecord.Outcome>> entry : byCapability.entrySet()) {
            List<DecisionRecord.Outcome> outcomes = entry.getValue();
            if (outcomes.size() < minimumEvidence) continue;
            double rate = successRate(outcomes, 0, outcomes.size());
            insights.add(new Insight(entry.getKey(), outcomes.size(), rate, trend(outcomes), advice(rate)));
        }
        return Collections.unmodifiableList(insights);
    }

    private static double successRate(List<DecisionRecord.Outcome> outcomes, int from, int to) {
        int successes = 0;
        for (int i = from; i < to; i++) {
            if (outcomes.get(i) == DecisionRecord.Outcome.SUCCESS) successes++;
        }
        return successes / (double) (to - from);
    }

    private static String trend(List<DecisionRecord.Outcome> outcomes) {
        int half = outcomes.size() / 2;
        if (half < 2) return "too few results to judge the trend";
        double first = successRate(outcomes, 0, half);
        double second = successRate(outcomes, outcomes.size() - half, outcomes.size());
        if (second - first >= TREND_SHIFT) return "improving";
        if (first - second >= TREND_SHIFT) return "declining";
        return "steady";
    }

    private static String advice(double rate) {
        if (rate >= STRONG) return "reliable so far; keep using it";
        if (rate < WEAK) return "unreliable so far; review its results before trusting it";
        return "mixed results; keep watching it";
    }
}
