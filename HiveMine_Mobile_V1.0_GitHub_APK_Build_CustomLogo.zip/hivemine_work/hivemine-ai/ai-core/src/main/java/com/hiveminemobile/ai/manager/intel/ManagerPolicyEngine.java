package com.hiveminemobile.ai.manager.intel;

/**
 * Phase 076 — Rule layer over observation flags (bag full, quest ready, disconnected).
 * Does not call the macro.
 */
public final class ManagerPolicyEngine {
    public static final class WorldFlags {
        public boolean bagFull;
        public boolean questComplete;
        public boolean disconnected;
        public boolean userWantsFarm;
        public boolean faulted;
    }

    public ManagerGoal evaluate(WorldFlags f) {
        if (f == null) return ManagerGoal.STANDBY;
        if (f.faulted) return ManagerGoal.SHUTDOWN;
        if (f.disconnected) return ManagerGoal.RECOVER_SESSION;
        if (f.questComplete) return ManagerGoal.TURN_IN_QUEST;
        if (f.bagFull) return ManagerGoal.CONVERT_HONEY;
        if (f.userWantsFarm) return ManagerGoal.FARM_POLLEN;
        return ManagerGoal.STANDBY;
    }
}
