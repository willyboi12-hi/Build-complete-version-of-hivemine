package com.hiveminemobile.ai.manager.intel;

/**
 * Phase 079 — Last decision snapshot for diagnostics (Markdown-friendly).
 */
public final class ManagerIntelligenceReport {
    private ManagerGoal lastChosen = ManagerGoal.STANDBY;
    private ManagerGoal lastPolicy = ManagerGoal.STANDBY;
    private ManagerGoal lastFused = ManagerGoal.STANDBY;
    private String lastArbiter = "";
    private EscalationManager.Level lastEscalation = EscalationManager.Level.NONE;
    private int steps;

    void record(ManagerGoal chosen, ManagerGoal policy, DecisionFusion.Result fused,
                SpecialistVote arb, EscalationManager.Level esc) {
        lastChosen = chosen;
        lastPolicy = policy;
        lastFused = fused == null ? ManagerGoal.STANDBY : fused.goal;
        lastArbiter = arb == null ? "" : arb.specialistId + ":" + arb.goal;
        lastEscalation = esc == null ? EscalationManager.Level.NONE : esc;
        steps++;
    }

    public ManagerGoal lastChosen() { return lastChosen; }
    public int steps() { return steps; }

    public String toMarkdown() {
        StringBuilder sb = new StringBuilder();
        sb.append("# Manager intelligence\n\n");
        sb.append("- steps: ").append(steps).append('\n');
        sb.append("- chosen: ").append(lastChosen).append('\n');
        sb.append("- policy: ").append(lastPolicy).append('\n');
        sb.append("- fused: ").append(lastFused).append('\n');
        sb.append("- arbiter: ").append(lastArbiter).append('\n');
        sb.append("- escalation: ").append(lastEscalation).append('\n');
        return sb.toString();
    }
}
