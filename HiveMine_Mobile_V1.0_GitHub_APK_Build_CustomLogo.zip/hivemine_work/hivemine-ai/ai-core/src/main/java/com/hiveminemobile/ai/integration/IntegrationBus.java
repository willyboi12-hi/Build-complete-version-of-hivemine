package com.hiveminemobile.ai.integration;
import java.util.ArrayList;
import java.util.List;
/** Phase 092 — In-process pub/sub for integration events. */
public final class IntegrationBus {
    public interface Listener { void onEvent(IntegrationEvent e); }
    private final ArrayList<Listener> listeners = new ArrayList<Listener>();
    private final ArrayList<IntegrationEvent> history = new ArrayList<IntegrationEvent>();
    private final int historyLimit;
    public IntegrationBus(int historyLimit) { this.historyLimit = Math.max(1, historyLimit); }
    public synchronized void subscribe(Listener l) { if (l != null) listeners.add(l); }
    public synchronized void publish(IntegrationEvent e) {
        if (e == null) return;
        history.add(e);
        while (history.size() > historyLimit) history.remove(0);
        for (Listener l : listeners) l.onEvent(e);
    }
    public synchronized List<IntegrationEvent> history() {
        return new ArrayList<IntegrationEvent>(history);
    }
}
