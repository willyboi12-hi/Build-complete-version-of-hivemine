package com.hiveminemobile.ai.release;
/** Project version metadata. */
public final class VersionInfo {
    public static final String VERSION = "2.00";
    public static final int PHASE_COMPLETE_THROUGH = 250;
    public static String banner() {
        return "HiveMineAI V" + VERSION + " (phases through " + PHASE_COMPLETE_THROUGH + " on JVM baseline)";
    }
}
