package com.hiveminemobile.ai.manager.intel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Phase 075 — Linear plan for v1 (graph can grow later). Cursor advances on complete.
 */
public final class PlanGraph {
    private final ArrayList<PlanNode> nodes = new ArrayList<PlanNode>();
    private int cursor;

    public void setPlan(List<PlanNode> plan) {
        nodes.clear();
        if (plan != null) nodes.addAll(plan);
        cursor = 0;
    }

    public PlanNode current() {
        if (cursor < 0 || cursor >= nodes.size()) return null;
        return nodes.get(cursor);
    }

    public boolean advance() {
        if (cursor >= nodes.size()) return false;
        cursor++;
        return cursor < nodes.size();
    }

    public boolean isComplete() {
        return cursor >= nodes.size();
    }

    public int size() { return nodes.size(); }
    public int cursor() { return cursor; }

    public List<PlanNode> snapshot() {
        return Collections.unmodifiableList(new ArrayList<PlanNode>(nodes));
    }
}
