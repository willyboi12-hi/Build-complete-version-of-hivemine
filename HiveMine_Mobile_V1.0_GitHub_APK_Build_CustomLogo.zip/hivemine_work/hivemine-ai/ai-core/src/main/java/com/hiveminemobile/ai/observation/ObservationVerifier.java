package com.hiveminemobile.ai.observation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Phase 049. Checks observations for problems before they are trusted: timestamps in the future,
 * the same key reporting two values at the same instant, and numeric values changing faster than a
 * configured rate.
 */
public final class ObservationVerifier {
    public static final class Issue {
        private final String key;
        private final String code;
        private final String message;

        Issue(String key, String code, String message) {
            this.key = key;
            this.code = code;
            this.message = message;
        }

        public String getKey() { return key; }
        public String getCode() { return code; }
        public String getMessage() { return message; }
    }

    private final double maxChangePerMinute;

    public ObservationVerifier(double maxChangePerMinute) {
        if (!(maxChangePerMinute > 0.0)) throw new IllegalArgumentException("maxChangePerMinute must be positive");
        this.maxChangePerMinute = maxChangePerMinute;
    }

    public List<Issue> verify(List<Observation> observations, long nowMillis) {
        List<Issue> issues = new ArrayList<>();
        for (Observation observation : observations) {
            if (observation.getAtMillis() > nowMillis) {
                issues.add(new Issue(observation.getKey(), "FUTURE_TIMESTAMP",
                    "observed after the current time: " + observation.getValue()));
            }
        }
        List<Observation> sorted = new ArrayList<>(observations);
        Collections.sort(sorted, new Comparator<Observation>() {
            @Override public int compare(Observation left, Observation right) {
                int byKey = left.getKey().compareTo(right.getKey());
                return byKey != 0 ? byKey : Long.compare(left.getAtMillis(), right.getAtMillis());
            }
        });
        for (int i = 1; i < sorted.size(); i++) {
            Observation before = sorted.get(i - 1);
            Observation after = sorted.get(i);
            if (!before.getKey().equals(after.getKey())) continue;
            if (before.getAtMillis() == after.getAtMillis() && !before.getValue().equals(after.getValue())) {
                issues.add(new Issue(after.getKey(), "CONTRADICTION", "two values at one instant: "
                    + before.getValue() + " and " + after.getValue()));
                continue;
            }
            Long previous = number(before.getValue());
            Long current = number(after.getValue());
            long gap = after.getAtMillis() - before.getAtMillis();
            if (previous == null || current == null || gap <= 0L) continue;
            double perMinute = Math.abs(current - previous) / (gap / 60_000.0);
            if (perMinute > maxChangePerMinute) {
                issues.add(new Issue(after.getKey(), "IMPLAUSIBLE_CHANGE", "changed by " + (current - previous)
                    + " in " + gap + " ms"));
            }
        }
        return Collections.unmodifiableList(issues);
    }

    private static Long number(String text) {
        return TextReader.parseCount(text);
    }
}
