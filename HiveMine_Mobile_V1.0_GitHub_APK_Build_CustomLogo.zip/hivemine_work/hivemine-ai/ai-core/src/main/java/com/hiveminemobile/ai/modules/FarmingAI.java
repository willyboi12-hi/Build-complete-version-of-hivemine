package com.hiveminemobile.ai.modules;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Phase 013. Measures pollen collection and honey change from timed observations, and notes where
 * the bag sat full. It only reports; it never suggests changing what the game does on its own.
 */
public final class FarmingAI extends BaseSpecialist {
    public static final String ID = "farming";
    private static final int FULL = 100;
    private static final int CONVERSION_DROP = 50;
    private static final long MINUTE = 60_000L;
    private static final long FULL_NOTICE_MILLIS = MINUTE;

    /** One reading: pollen bag percentage and, when visible, the honey total at that time. */
    public static final class Sample {
        private final long atMillis;
        private final int pollenPercent;
        private final Long honey;

        public Sample(long atMillis, int pollenPercent, Long honey) {
            if (pollenPercent < 0 || pollenPercent > FULL) throw new IllegalArgumentException("pollen must be 0-100");
            if (honey != null && honey < 0L) throw new IllegalArgumentException("honey must not be negative");
            this.atMillis = atMillis;
            this.pollenPercent = pollenPercent;
            this.honey = honey;
        }

        public long getAtMillis() { return atMillis; }
        public int getPollenPercent() { return pollenPercent; }
        /** Null when honey was not visible in this reading. */
        public Long getHoney() { return honey; }
    }

    public static final class Report {
        private final int samples;
        private final double pollenPerMinute;
        private final int conversions;
        private final long fullMillis;
        private final Long honeyChange;
        private final List<String> recommendations;

        Report(int samples, double pollenPerMinute, int conversions, long fullMillis,
               Long honeyChange, List<String> recommendations) {
            this.samples = samples;
            this.pollenPerMinute = pollenPerMinute;
            this.conversions = conversions;
            this.fullMillis = fullMillis;
            this.honeyChange = honeyChange;
            this.recommendations = recommendations;
        }

        public int getSamples() { return samples; }
        /** Percentage points gained per minute while the bag was filling. */
        public double getPollenPerMinute() { return pollenPerMinute; }
        /** Drops of at least 50 points, read as the bag being emptied at the hive. */
        public int getConversions() { return conversions; }
        public long getFullMillis() { return fullMillis; }
        /** Honey change between the first and last reading that showed honey; null with fewer than two readings. */
        public Long getHoneyChange() { return honeyChange; }
        public List<String> getRecommendations() { return recommendations; }
    }

    public FarmingAI() {
        super(ID, "analyze.farming");
    }

    public Report analyze(List<Sample> input) {
        List<Sample> samples = new ArrayList<>(input);
        Collections.sort(samples, new Comparator<Sample>() {
            @Override public int compare(Sample left, Sample right) {
                return Long.compare(left.atMillis, right.atMillis);
            }
        });
        long fillingMillis = 0L;
        long fullMillis = 0L;
        int gained = 0;
        int conversions = 0;
        for (int i = 1; i < samples.size(); i++) {
            Sample before = samples.get(i - 1);
            Sample after = samples.get(i);
            long elapsed = after.atMillis - before.atMillis;
            if (elapsed <= 0L) continue;
            int change = after.pollenPercent - before.pollenPercent;
            if (change > 0) {
                fillingMillis += elapsed;
                gained += change;
            } else if (-change >= CONVERSION_DROP) {
                conversions++;
            }
            if (before.pollenPercent == FULL && after.pollenPercent == FULL) fullMillis += elapsed;
        }
        double perMinute = fillingMillis > 0L ? gained / (fillingMillis / (double) MINUTE) : 0.0;
        List<String> advice = new ArrayList<>();
        if (samples.size() < 2) advice.add("Not enough samples to measure the farming rate.");
        if (fullMillis >= FULL_NOTICE_MILLIS) {
            advice.add("The bag sat at 100% for " + (fullMillis / MINUTE)
                + " minute(s); converting a little earlier would avoid that idle time.");
        }
        return new Report(samples.size(), perMinute, conversions, fullMillis,
            honeyChange(samples), Collections.unmodifiableList(advice));
    }

    private static Long honeyChange(List<Sample> samples) {
        Long first = null;
        Long last = null;
        int readings = 0;
        for (Sample sample : samples) {
            if (sample.honey == null) continue;
            if (first == null) first = sample.honey;
            last = sample.honey;
            readings++;
        }
        return readings >= 2 ? Long.valueOf(last - first) : null;
    }
}
