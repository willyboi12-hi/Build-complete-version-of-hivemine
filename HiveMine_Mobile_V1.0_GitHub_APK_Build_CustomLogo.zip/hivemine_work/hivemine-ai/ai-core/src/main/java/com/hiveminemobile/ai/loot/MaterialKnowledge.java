package com.hiveminemobile.ai.loot;

import com.hiveminemobile.ai.bss.BssFields;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * BSS-oriented material sources. Recommendations only use real macro fields from FieldRoutes.
 * Does not invent shop purchase automation.
 */
public final class MaterialKnowledge {

    public static final class SourcePlan {
        public final CraftMaterial material;
        public final String primaryField;
        public final List<String> altFields;
        public final String strategy;
        public final boolean needsTokenFocus;
        public final boolean needsQuestFocus;
        public final List<String> notes;

        public SourcePlan(CraftMaterial material, String primaryField, List<String> altFields,
                          String strategy, boolean needsTokenFocus, boolean needsQuestFocus,
                          List<String> notes) {
            this.material = material;
            this.primaryField = primaryField;
            this.altFields = altFields;
            this.strategy = strategy;
            this.needsTokenFocus = needsTokenFocus;
            this.needsQuestFocus = needsQuestFocus;
            this.notes = notes;
        }
    }

    public CraftMaterial parseMaterial(String text) {
        if (text == null) return CraftMaterial.UNKNOWN;
        String t = text.toLowerCase(Locale.US);
        if (t.contains("glue")) return CraftMaterial.GLUE;
        if (t.contains("gumm")) return CraftMaterial.GUMDROPS;
        if (t.contains("ticket")) return CraftMaterial.TICKETS;
        if (t.contains("treat")) return CraftMaterial.TREATS;
        if (t.contains("sunflower seed") || t.contains("seeds")) return CraftMaterial.SUNFLOWER_SEED;
        if (t.contains("strawberr")) return CraftMaterial.STRAWBERRY;
        if (t.contains("pineapple")) return CraftMaterial.PINEAPPLE;
        if (t.contains("blueberr")) return CraftMaterial.BLUEBERRY;
        if (t.contains("coconut")) return CraftMaterial.COCONUT;
        if (t.contains("enzyme")) return CraftMaterial.ENZYMES;
        if (t.contains("oil")) return CraftMaterial.OIL;
        if (t.contains("extract")) return CraftMaterial.EXTRACTS;
        if (t.contains("glitter")) return CraftMaterial.GLITTER;
        if (t.contains("soft wax")) return CraftMaterial.SOFT_WAX;
        if (t.contains("hard wax")) return CraftMaterial.HARD_WAX;
        if (t.contains("token")) return CraftMaterial.TOKENS_GENERIC;
        if (t.contains("honey")) return CraftMaterial.HONEY;
        return CraftMaterial.UNKNOWN;
    }

    public SourcePlan planFor(CraftMaterial mat) {
        List<String> notes = new ArrayList<String>();
        switch (mat) {
            case GLUE:
                notes.add("Glue is often crafted from gumdrops + soft wax style mats; farm gummy-related fields and gather tokens.");
                notes.add("Macro can farm fields and pick up tokens along gather paths; it cannot auto-craft in the blender.");
                return new SourcePlan(mat, "Spider", list("Pine Tree", "Strawberry", "Blue Flower"),
                        "Field farm + token pickup while gathering", true, false, notes);
            case GUMDROPS:
            case GUMMY_BEE_EGG_RELATED:
                notes.add("Favor fields that pair well with gummy-style farming; keep bag converting so runs stay long.");
                return new SourcePlan(mat, "Spider", list("Strawberry", "Pine Tree", "Clover"),
                        "Sustained field pollen + token focus", true, false, notes);
            case SUNFLOWER_SEED:
                return new SourcePlan(mat, "Sunflower", list("Dandelion", "Mushroom"),
                        "Farm Sunflower for seeds/tokens", true, false, notes);
            case STRAWBERRY:
                return new SourcePlan(mat, "Strawberry", list("Pepper", "Rose"),
                        "Farm Strawberry field", true, false, notes);
            case PINEAPPLE:
                return new SourcePlan(mat, "Pineapple", list("Pumpkin", "Pine Tree"),
                        "Farm Pineapple field", true, false, notes);
            case BLUEBERRY:
                return new SourcePlan(mat, "Blue Flower", list("Pine Tree", "Stump"),
                        "Farm Blue Flower", true, false, notes);
            case COCONUT:
                notes.add("Coconut field is jump-heavy on some routes; expect more drift.");
                return new SourcePlan(mat, "Coconut", list("Pepper", "Mountain Top"),
                        "Farm Coconut with caution", true, false, notes);
            case ENZYMES:
            case OIL:
            case EXTRACTS:
            case GLITTER:
            case SOFT_WAX:
            case HARD_WAX:
                notes.add("Many of these are crafted or drop from mixed mid/late activities.");
                notes.add("Best macro support: efficient honey + token-rich field loops, quests when needed.");
                return new SourcePlan(mat, "Pine Tree", list("Spider", "Pepper", "Mountain Top"),
                        "High-efficiency farm + token collection", true, true, notes);
            case TICKETS:
            case TREATS:
                notes.add("Tickets/treats often come from quests, codes, or special events — not pure field pollen.");
                return new SourcePlan(mat, "Clover", list("Sunflower", "Dandelion", "Mushroom"),
                        "Quest-smart + beginner-friendly fields", false, true, notes);
            case TOKENS_GENERIC:
                notes.add("Stay in dense token fields; human-like path helps pass over token spawns.");
                return new SourcePlan(mat, "Spider", list("Pepper", "Pine Tree", "Mountain Top"),
                        "Token-focused field farming", true, false, notes);
            case HONEY:
                return new SourcePlan(mat, "Pine Tree", list("Spider", "Pepper", "Bamboo"),
                        "Max pollen then convert at hive", false, false, notes);
            default:
                notes.add("Material not recognized. Pick a field manually.");
                return new SourcePlan(mat, "Pine Tree", list("Sunflower", "Clover"),
                        "Default farm", false, false, notes);
        }
    }

    private static List<String> list(String... fields) {
        ArrayList<String> out = new ArrayList<String>();
        for (String f : fields) if (BssFields.isKnown(f)) out.add(f);
        return Collections.unmodifiableList(out);
    }

    public Map<String, String> toMacroSettings(SourcePlan plan) {
        LinkedHashMap<String, String> m = new LinkedHashMap<String, String>();
        if (plan == null) return m;
        m.put("field", plan.primaryField);
        m.put("walkFirst", "true");
        m.put("returnToField", "true");
        m.put("fullAction", "2");
        m.put("fullPercent", plan.needsTokenFocus ? "95" : "90");
        m.put("questSmart", plan.needsQuestFocus ? "true" : "false");
        m.put("humanMode", "true");
        // denser gather helps token pickup
        m.put("pattern", plan.needsTokenFocus ? "Snake" : "Snake");
        m.put("size", plan.needsTokenFocus ? "L" : "M");
        return m;
    }
}
