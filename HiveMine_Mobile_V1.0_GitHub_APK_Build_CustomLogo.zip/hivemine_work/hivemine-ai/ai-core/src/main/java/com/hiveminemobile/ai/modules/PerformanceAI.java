package com.hiveminemobile.ai.modules;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Phase 021. Summarises CPU, memory and battery samples and reports where they exceed the limits.
 * It observes only; it never changes a setting or stops work.
 */
public final class PerformanceAI extends BaseSpecialist {
    public static final String ID = "performance";

    public static final class Sample {
        private final long atMillis;
        private final double cpuPercent;
        private final long memoryMb;
        private final double batteryPerHour;

        public Sample(long atMillis, double cpuPercent, long memoryMb, double batteryPerHour) {
            if (!(cpuPercent >= 0.0 && cpuPercent <= 100.0)) throw new IllegalArgumentException("cpu must be 0-100");
            if (memoryMb < 0L) throw new IllegalArgumentException("memory must not be negative");
            if (!(batteryPerHour >= 0.0)) throw new IllegalArgumentException("battery drain must not be negative");
            this.atMillis = atMillis;
            this.cpuPercent = cpuPercent;
            this.memoryMb = memoryMb;
            this.batteryPerHour = batteryPerHour;
        }
    }

    public static final class Report {
        private final int samples;
        private final double averageCpu;
        private final double peakCpu;
        private final long peakMemoryMb;
        private final double averageBatteryPerHour;
        private final List<String> findings;

        Report(int samples, double averageCpu, double peakCpu, long peakMemoryMb,
               double averageBatteryPerHour, List<String> findings) {
            this.samples = samples;
            this.averageCpu = averageCpu;
            this.peakCpu = peakCpu;
            this.peakMemoryMb = peakMemoryMb;
            this.averageBatteryPerHour = averageBatteryPerHour;
            this.findings = findings;
        }

        public int getSamples() { return samples; }
        public double getAverageCpu() { return averageCpu; }
        public double getPeakCpu() { return peakCpu; }
        public long getPeakMemoryMb() { return peakMemoryMb; }
        public double getAverageBatteryPerHour() { return averageBatteryPerHour; }
        public List<String> getFindings() { return findings; }
    }

    private final double cpuLimit;
    private final long memoryLimitMb;
    private final double batteryLimitPerHour;

    public PerformanceAI() {
        this(80.0, 1024L, 15.0);
    }

    public PerformanceAI(double cpuLimit, long memoryLimitMb, double batteryLimitPerHour) {
        super(ID, "analyze.performance");
        if (!(cpuLimit > 0.0 && cpuLimit <= 100.0)) throw new IllegalArgumentException("cpuLimit must be 0-100");
        if (memoryLimitMb < 1L) throw new IllegalArgumentException("memoryLimitMb must be positive");
        if (!(batteryLimitPerHour > 0.0)) throw new IllegalArgumentException("batteryLimitPerHour must be positive");
        this.cpuLimit = cpuLimit;
        this.memoryLimitMb = memoryLimitMb;
        this.batteryLimitPerHour = batteryLimitPerHour;
    }

    public Report analyze(List<Sample> samples) {
        if (samples == null || samples.isEmpty()) throw new IllegalArgumentException("no samples to analyse");
        double cpuSum = 0.0;
        double batterySum = 0.0;
        double peakCpu = 0.0;
        long peakMemory = 0L;
        for (Sample sample : samples) {
            cpuSum += sample.cpuPercent;
            batterySum += sample.batteryPerHour;
            peakCpu = Math.max(peakCpu, sample.cpuPercent);
            peakMemory = Math.max(peakMemory, sample.memoryMb);
        }
        double averageCpu = cpuSum / samples.size();
        double averageBattery = batterySum / samples.size();
        List<String> findings = new ArrayList<>();
        if (averageCpu > cpuLimit) {
            findings.add(String.format("CPU averages %.1f%%, above the %.1f%% limit", averageCpu, cpuLimit));
        }
        if (peakMemory > memoryLimitMb) {
            findings.add("Memory peaked at " + peakMemory + " MB, above the " + memoryLimitMb + " MB limit");
        }
        if (averageBattery > batteryLimitPerHour) {
            findings.add(String.format("Battery drain averages %.1f%%/h, above the %.1f%%/h limit",
                averageBattery, batteryLimitPerHour));
        }
        if (findings.isEmpty()) findings.add("Within limits");
        return new Report(samples.size(), averageCpu, peakCpu, peakMemory, averageBattery,
            Collections.unmodifiableList(findings));
    }
}
