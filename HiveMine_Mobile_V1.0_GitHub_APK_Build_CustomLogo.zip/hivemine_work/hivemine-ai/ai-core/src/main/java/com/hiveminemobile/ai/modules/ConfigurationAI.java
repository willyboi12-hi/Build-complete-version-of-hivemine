package com.hiveminemobile.ai.modules;

import com.hiveminemobile.ai.Identifiers;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Phase 022. Validates settings against a schema and merges profiles. Unknown keys are reported,
 * never silently kept, and no setting is applied by this module itself.
 */
public final class ConfigurationAI extends BaseSpecialist {
    public static final String ID = "configuration";

    public enum Type { INTEGER, BOOLEAN, TEXT }

    public static final class Rule {
        private final String key;
        private final Type type;
        private final long min;
        private final long max;

        private Rule(String key, Type type, long min, long max) {
            if (!Identifiers.isValid(key)) throw new IllegalArgumentException("setting key is invalid: " + key);
            this.key = key;
            this.type = type;
            this.min = min;
            this.max = max;
        }

        public static Rule integer(String key, long min, long max) {
            if (min > max) throw new IllegalArgumentException("min must not exceed max for " + key);
            return new Rule(key, Type.INTEGER, min, max);
        }

        public static Rule bool(String key) {
            return new Rule(key, Type.BOOLEAN, 0L, 0L);
        }

        public static Rule text(String key, int maxLength) {
            if (maxLength < 1) throw new IllegalArgumentException("maxLength must be at least 1");
            return new Rule(key, Type.TEXT, 0L, maxLength);
        }

        public String getKey() { return key; }
    }

    public static final class Problem {
        private final String key;
        private final String message;

        Problem(String key, String message) {
            this.key = key;
            this.message = message;
        }

        public String getKey() { return key; }
        public String getMessage() { return message; }
    }

    public ConfigurationAI() {
        super(ID, "analyze.configuration");
    }

    /** Every rule is required. Returns no problems when the configuration is valid. */
    public List<Problem> validate(Map<String, String> config, List<Rule> schema) {
        Map<String, Rule> rules = new LinkedHashMap<>();
        for (Rule rule : schema) rules.put(rule.key, rule);
        List<Problem> problems = new ArrayList<>();
        for (Rule rule : rules.values()) {
            String value = config.get(rule.key);
            if (value == null) {
                problems.add(new Problem(rule.key, "missing"));
                continue;
            }
            String problem = check(rule, value);
            if (problem != null) problems.add(new Problem(rule.key, problem));
        }
        for (String key : config.keySet()) {
            if (!rules.containsKey(key)) problems.add(new Problem(key, "unknown key"));
        }
        return Collections.unmodifiableList(problems);
    }

    /** Returns base with overrides applied. Override keys must be valid identifiers. */
    public Map<String, String> merge(Map<String, String> base, Map<String, String> overrides) {
        for (String key : overrides.keySet()) {
            if (!Identifiers.isValid(key)) throw new IllegalArgumentException("setting key is invalid: " + key);
        }
        Map<String, String> merged = new LinkedHashMap<>(base);
        merged.putAll(overrides);
        return Collections.unmodifiableMap(merged);
    }

    private static String check(Rule rule, String value) {
        switch (rule.type) {
            case INTEGER:
                try {
                    long number = Long.parseLong(value.trim());
                    if (number < rule.min || number > rule.max) {
                        return "must be between " + rule.min + " and " + rule.max;
                    }
                    return null;
                } catch (NumberFormatException notANumber) {
                    return "must be a whole number";
                }
            case BOOLEAN:
                return "true".equals(value) || "false".equals(value) ? null : "must be true or false";
            default:
                return value.length() > rule.max ? "longer than " + rule.max + " characters" : null;
        }
    }
}
