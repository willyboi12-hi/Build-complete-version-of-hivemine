package com.hiveminemobile.ai.task;

/** Decides whether a specialist may take a task. Return null to allow, or the refusal reason. */
public interface AssignmentGate {
    AssignmentGate ALLOW_ALL = new AssignmentGate() {
        @Override public String refuse(Task task, String specialistId) { return null; }
    };

    String refuse(Task task, String specialistId);
}
