package com.hiveminemobile.ai.automation;

import com.hiveminemobile.ai.control.MacroStatus;

/**
 * Phase 065 — Decides when a recover request is warranted.
 */
public final class RecoveryPolicy {
    private final int maxRecoveriesPerSession;
    private int recoveriesThisSession;

    public RecoveryPolicy(int maxRecoveriesPerSession) {
        this.maxRecoveriesPerSession = Math.max(0, maxRecoveriesPerSession);
    }

    public int recoveriesThisSession() { return recoveriesThisSession; }

    public void resetSession() { recoveriesThisSession = 0; }

    /**
     * @param disconnectedHint true when observation layer believes Roblox is gone
     */
    public boolean shouldRecover(MacroStatus status, boolean disconnectedHint) {
        if (recoveriesThisSession >= maxRecoveriesPerSession) return false;
        if (status == null || !status.isConnected()) return false;
        if (status.isRunning()) return false;
        return disconnectedHint;
    }

    public void recordRecoveryAttempt() { recoveriesThisSession++; }
}
