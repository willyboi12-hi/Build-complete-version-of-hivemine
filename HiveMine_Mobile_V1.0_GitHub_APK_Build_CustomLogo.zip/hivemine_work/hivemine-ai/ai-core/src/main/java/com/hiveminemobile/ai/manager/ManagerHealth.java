package com.hiveminemobile.ai.manager;

/** Health summary. It reports readiness; it does not authorize gameplay actions. */
public final class ManagerHealth {
    public enum Status { HEALTHY, DEGRADED, UNAVAILABLE }

    private final Status status;
    private final int registeredModules;
    private final int initializedModules;
    private final int errorCount;
    private final String detail;
    private final long checkedAtMillis;

    ManagerHealth(Status status, int registeredModules, int initializedModules,
                  int errorCount, String detail, long checkedAtMillis) {
        this.status = status;
        this.registeredModules = registeredModules;
        this.initializedModules = initializedModules;
        this.errorCount = errorCount;
        this.detail = detail == null ? "" : detail;
        this.checkedAtMillis = checkedAtMillis;
    }

    public Status getStatus() { return status; }
    public int getRegisteredModules() { return registeredModules; }
    public int getInitializedModules() { return initializedModules; }
    public int getErrorCount() { return errorCount; }
    public String getDetail() { return detail; }
    public long getCheckedAtMillis() { return checkedAtMillis; }
}
