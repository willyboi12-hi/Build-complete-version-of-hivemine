package com.hiveminemobile.ai.modules;

import com.hiveminemobile.ai.Identifiers;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Phase 029. Estimates output per hour for a strategy under a scenario, so strategies can be compared
 * before anything is tried. The model is a deterministic expected-value calculation, not a game run.
 */
public final class SimulationAI extends BaseSpecialist {
    public static final String ID = "simulation";

    public static final class Strategy {
        private final String name;
        private final double ratePerMinute;
        private final double cycleMinutes;
        private final double downtimeMinutes;

        public Strategy(String name, double ratePerMinute, double cycleMinutes, double downtimeMinutes) {
            if (!Identifiers.isValid(name)) throw new IllegalArgumentException("strategy name is invalid");
            if (!(ratePerMinute > 0.0)) throw new IllegalArgumentException("rate must be positive");
            if (!(cycleMinutes > 0.0)) throw new IllegalArgumentException("cycle must be positive");
            if (!(downtimeMinutes >= 0.0)) throw new IllegalArgumentException("downtime must not be negative");
            this.name = name;
            this.ratePerMinute = ratePerMinute;
            this.cycleMinutes = cycleMinutes;
            this.downtimeMinutes = downtimeMinutes;
        }
    }

    public static final class Scenario {
        private final String name;
        private final double disruptionsPerHour;
        private final double minutesLostPerDisruption;

        public Scenario(String name, double disruptionsPerHour, double minutesLostPerDisruption) {
            if (!Identifiers.isValid(name)) throw new IllegalArgumentException("scenario name is invalid");
            if (!(disruptionsPerHour >= 0.0)) throw new IllegalArgumentException("disruptions must not be negative");
            if (!(minutesLostPerDisruption >= 0.0 && minutesLostPerDisruption <= 60.0)) {
                throw new IllegalArgumentException("minutes lost must be 0-60");
            }
            this.name = name;
            this.disruptionsPerHour = disruptionsPerHour;
            this.minutesLostPerDisruption = minutesLostPerDisruption;
        }
    }

    public static final class Outcome {
        private final String strategy;
        private final String scenario;
        private final double unitsPerHour;

        Outcome(String strategy, String scenario, double unitsPerHour) {
            this.strategy = strategy;
            this.scenario = scenario;
            this.unitsPerHour = unitsPerHour;
        }

        public String getStrategy() { return strategy; }
        public String getScenario() { return scenario; }
        public double getUnitsPerHour() { return unitsPerHour; }
    }

    public static final class Ranked {
        private final String strategy;
        private final double averageUnitsPerHour;

        Ranked(String strategy, double averageUnitsPerHour) {
            this.strategy = strategy;
            this.averageUnitsPerHour = averageUnitsPerHour;
        }

        public String getStrategy() { return strategy; }
        public double getAverageUnitsPerHour() { return averageUnitsPerHour; }
    }

    public SimulationAI() {
        super(ID, "simulate.scenario");
    }

    /** Expected units per hour: each cycle produces rate times cycle minutes, then pays its downtime. */
    public Outcome simulate(Strategy strategy, Scenario scenario) {
        double perCycle = strategy.ratePerMinute * strategy.cycleMinutes;
        double productivePerHour = perCycle * 60.0 / (strategy.cycleMinutes + strategy.downtimeMinutes);
        double lostShare = Math.min(1.0, scenario.disruptionsPerHour * scenario.minutesLostPerDisruption / 60.0);
        return new Outcome(strategy.name, scenario.name, productivePerHour * (1.0 - lostShare));
    }

    /** Average expected output of each strategy across the scenarios, best first. */
    public List<Ranked> compare(List<Strategy> strategies, List<Scenario> scenarios) {
        if (scenarios == null || scenarios.isEmpty()) throw new IllegalArgumentException("at least one scenario is required");
        List<Ranked> ranked = new ArrayList<>();
        for (Strategy strategy : strategies) {
            double total = 0.0;
            for (Scenario scenario : scenarios) total += simulate(strategy, scenario).unitsPerHour;
            ranked.add(new Ranked(strategy.name, total / scenarios.size()));
        }
        Collections.sort(ranked, new Comparator<Ranked>() {
            @Override public int compare(Ranked left, Ranked right) {
                int byOutput = Double.compare(right.averageUnitsPerHour, left.averageUnitsPerHour);
                return byOutput != 0 ? byOutput : left.strategy.compareTo(right.strategy);
            }
        });
        return Collections.unmodifiableList(ranked);
    }
}
