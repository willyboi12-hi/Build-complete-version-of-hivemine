package com.hiveminemobile.ai.modules;

import com.hiveminemobile.ai.policy.PolicySupervisor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Phase 027. Audits granted capabilities against the hard-deny rules and removes sensitive values
 * from text before it is logged or shown. It never grants or revokes anything itself.
 */
public final class SecurityAI extends BaseSpecialist {
    public static final String ID = "security";

    private static final Pattern EMAIL = Pattern.compile("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}");
    private static final Pattern SECRET =
        Pattern.compile("(?i)(password|passwd|token|secret|cookie|api[_-]?key)\\s*[=:]\\s*\\S+");
    private static final Pattern LONG_NUMBER = Pattern.compile("\\b\\d{13,19}\\b");

    public static final class Finding {
        private final String code;
        private final String message;

        Finding(String code, String message) {
            this.code = code;
            this.message = message;
        }

        public String getCode() { return code; }
        public String getMessage() { return message; }
    }

    public SecurityAI() {
        super(ID, "audit.security");
    }

    /** Flags any granted capability that falls under a hard-denied prefix. An empty list is a clean audit. */
    public List<Finding> auditGrants(Set<String> granted) {
        List<Finding> findings = new ArrayList<>();
        for (String capability : granted) {
            if (PolicySupervisor.isHardDenied(capability)) {
                findings.add(new Finding("HARD_DENIED_GRANTED", "Hard-denied capability is granted: " + capability));
            }
        }
        return Collections.unmodifiableList(findings);
    }

    public boolean containsSensitive(String text) {
        return text != null && (SECRET.matcher(text).find() || EMAIL.matcher(text).find()
            || LONG_NUMBER.matcher(text).find());
    }

    /** Replaces e-mail addresses, secret values and long number runs. Null becomes an empty string. */
    public String redact(String text) {
        if (text == null) return "";
        String cleaned = SECRET.matcher(text).replaceAll("$1=[redacted]");
        cleaned = EMAIL.matcher(cleaned).replaceAll("[email]");
        return LONG_NUMBER.matcher(cleaned).replaceAll("[number]");
    }
}
