package com.hiveminemobile.ai.observation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Phase 047. Reads buff lines such as "Haste 3:20" into names and remaining time, longest first. */
public final class BuffReader {
    public static final class Buff {
        private final String name;
        private final long remainingMillis;

        Buff(String name, long remainingMillis) {
            this.name = name;
            this.remainingMillis = remainingMillis;
        }

        public String getName() { return name; }
        public long getRemainingMillis() { return remainingMillis; }
    }

    private static final Pattern LINE = Pattern.compile("^(.+?)\\s+(\\d{1,2}:\\d{2}(?::\\d{2})?)$");

    public List<Buff> read(List<String> ocrLines) {
        List<Buff> buffs = new ArrayList<>();
        for (String line : ocrLines) {
            Matcher m = LINE.matcher(line == null ? "" : line.trim());
            if (!m.matches()) continue;
            Long remaining = TextReader.parseDurationMillis(m.group(2));
            if (remaining == null) continue;
            buffs.add(new Buff(m.group(1).trim(), remaining));
        }
        Collections.sort(buffs, new Comparator<Buff>() {
            @Override public int compare(Buff left, Buff right) {
                int byTime = Long.compare(right.remainingMillis, left.remainingMillis);
                return byTime != 0 ? byTime : left.name.compareTo(right.name);
            }
        });
        return Collections.unmodifiableList(buffs);
    }
}
