package com.hiveminemobile.ai.automation;

/**
 * Phase 061 — Automation session identity and wall-clock bookkeeping.
 * Pure data; no macro calls.
 */
public final class AutomationSession {
    public enum Phase { CREATED, ACTIVE, ENDED }

    private final String id;
    private final long createdAtMs;
    private long startedAtMs = -1;
    private long endedAtMs = -1;
    private Phase phase = Phase.CREATED;
    private String endReason = "";

    public AutomationSession(String id, long createdAtMs) {
        if (id == null || id.isEmpty()) throw new IllegalArgumentException("id required");
        this.id = id;
        this.createdAtMs = createdAtMs;
    }

    public String id() { return id; }
    public long createdAtMs() { return createdAtMs; }
    public long startedAtMs() { return startedAtMs; }
    public long endedAtMs() { return endedAtMs; }
    public Phase phase() { return phase; }
    public String endReason() { return endReason; }

    public void markActive(long nowMs) {
        if (phase != Phase.CREATED) return;
        phase = Phase.ACTIVE;
        startedAtMs = nowMs;
    }

    public void markEnded(long nowMs, String reason) {
        if (phase == Phase.ENDED) return;
        phase = Phase.ENDED;
        endedAtMs = nowMs;
        endReason = reason == null ? "" : reason;
    }

    public long activeDurationMs(long nowMs) {
        if (startedAtMs < 0) return 0;
        long end = endedAtMs > 0 ? endedAtMs : nowMs;
        return Math.max(0, end - startedAtMs);
    }
}
