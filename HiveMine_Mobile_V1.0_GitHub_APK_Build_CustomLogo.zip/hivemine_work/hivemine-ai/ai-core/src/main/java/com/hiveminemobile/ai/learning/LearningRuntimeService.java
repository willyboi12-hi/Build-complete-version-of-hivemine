package com.hiveminemobile.ai.learning;

import com.hiveminemobile.ai.memory.DecisionRecord;
import com.hiveminemobile.ai.memory.ManagerMemory;
import com.hiveminemobile.ai.modules.LearningAI;
import java.util.List;

/** Persistent-runtime adapter for LearningAI. It owns only evidence and recommendations; it never mutates user settings. */
public final class LearningRuntimeService {
    private final ManagerMemory memory;
    private final LearningIntelligenceManager intelligence;

    public LearningRuntimeService(int capacity, int minimumEvidence) {
        memory = new ManagerMemory(Math.max(1, capacity));
        intelligence = new LearningIntelligenceManager(new LearningAI(Math.max(1, minimumEvidence)));
    }

    public synchronized void recordOutcome(String capability, String specialistId, boolean success,
                                           String detail, long nowMillis) {
        memory.record("runtime-" + nowMillis, capability == null ? "unknown" : capability,
            specialistId == null ? "manager" : specialistId,
            success ? "runtime command completed" : "runtime command failed",
            success ? DecisionRecord.Outcome.SUCCESS : DecisionRecord.Outcome.FAILURE,
            detail, nowMillis);
        intelligence.refresh(memory.recent(memory.size()));
    }

    public synchronized List<Recommendation> recommendations() {
        return intelligence.recommendations();
    }

    public synchronized List<DecisionRecord> evidence() {
        return memory.recent(Math.max(1, memory.size()));
    }

    public synchronized double successRate(String capability) {
        java.util.OptionalDouble value = memory.successRate(capability);
        return value.isPresent() ? value.getAsDouble() : -1.0;
    }
}
