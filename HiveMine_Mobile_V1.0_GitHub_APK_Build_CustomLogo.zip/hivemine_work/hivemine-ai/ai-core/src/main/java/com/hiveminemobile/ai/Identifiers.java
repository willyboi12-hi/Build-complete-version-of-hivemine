package com.hiveminemobile.ai;

import java.util.regex.Pattern;

/** Shared identifier rule for module, address, message type, scope and capability names. */
public final class Identifiers {
    private static final Pattern VALID = Pattern.compile("[a-z][a-z0-9._-]{0,63}");

    private Identifiers() { }

    public static boolean isValid(String value) {
        return value != null && VALID.matcher(value).matches();
    }
}
