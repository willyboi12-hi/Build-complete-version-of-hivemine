package com.hiveminemobile.ai.integration;
/** Phase 092 — Bus event between manager and automation layers. */
public final class IntegrationEvent {
    public final String type;
    public final String payload;
    public final long atMs;
    public IntegrationEvent(String type, String payload, long atMs) {
        this.type = type == null ? "" : type;
        this.payload = payload == null ? "" : payload;
        this.atMs = atMs;
    }
}
