package com.hiveminemobile.ai.feedback;

import java.util.*;
import java.util.function.Consumer;

/** Phase 083: stores verified execution feedback and tells listeners about it. Incomplete feedback is rejected. */
public final class LearningFeedbackController {

    public static final class Feedback {
        public final String taskId, configVersion;
        public final boolean success;
        public final long atMillis;
        Feedback(String t, String v, boolean s, long at) { taskId = t; configVersion = v; success = s; atMillis = at; }
    }

    private final List<Feedback> repository = new ArrayList<>();
    private final List<Consumer<Feedback>> listeners = new ArrayList<>();
    private int rejected;

    public synchronized void subscribe(Consumer<Feedback> l) { if (l != null) listeners.add(l); }

    /** outcome must be "SUCCESS" or "FAILURE". Returns false and counts the report when it is incomplete. */
    public synchronized boolean submit(String taskId, String configVersion, String outcome, long nowMillis) {
        boolean valid = !blank(taskId) && !blank(configVersion)
            && ("SUCCESS".equals(outcome) || "FAILURE".equals(outcome));
        if (!valid) { rejected++; return false; }
        Feedback f = new Feedback(taskId.trim(), configVersion.trim(), "SUCCESS".equals(outcome), nowMillis);
        repository.add(f);
        for (Consumer<Feedback> l : listeners) {
            try { l.accept(f); } catch (RuntimeException ignored) { /* one bad listener must not stop the others */ }
        }
        return true;
    }

    public synchronized List<Feedback> history() { return Collections.unmodifiableList(new ArrayList<>(repository)); }
    public synchronized int rejectedCount() { return rejected; }

    public synchronized OptionalDouble successRate(String configVersion) {
        int ok = 0, n = 0;
        for (Feedback f : repository) if (f.configVersion.equals(configVersion)) { n++; if (f.success) ok++; }
        return n == 0 ? OptionalDouble.empty() : OptionalDouble.of((double) ok / n);
    }
    private static boolean blank(String s) { return s == null || s.trim().isEmpty(); }
}
