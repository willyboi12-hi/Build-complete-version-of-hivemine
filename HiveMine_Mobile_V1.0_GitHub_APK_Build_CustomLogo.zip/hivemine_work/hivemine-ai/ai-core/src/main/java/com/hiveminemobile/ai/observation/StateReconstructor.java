package com.hiveminemobile.ai.observation;

import com.hiveminemobile.ai.shared.ConfidenceEngine;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Phase 048. Rebuilds the current state from many observations. For each key, every distinct value is
 * scored with the confidence engine; the best value wins only if its combined confidence reaches the
 * threshold. Otherwise the key is reported as unknown, with the confidence that was reached.
 */
public final class StateReconstructor {
    public static final class Estimate {
        private final String value;
        private final double confidence;
        private final int evidence;

        Estimate(String value, double confidence, int evidence) {
            this.value = value;
            this.confidence = confidence;
            this.evidence = evidence;
        }

        /** Null when the key is unknown. */
        public String getValue() { return value; }
        public double getConfidence() { return confidence; }
        public int getEvidence() { return evidence; }
    }

    private final ConfidenceEngine engine;
    private final double threshold;

    public StateReconstructor(ConfidenceEngine engine, double threshold) {
        if (engine == null) throw new IllegalArgumentException("engine must not be null");
        if (!(threshold >= 0.0 && threshold <= 1.0)) throw new IllegalArgumentException("threshold must be 0-1");
        this.engine = engine;
        this.threshold = threshold;
    }

    public Map<String, Estimate> reconstruct(List<Observation> observations, long nowMillis) {
        Map<String, Map<String, List<ConfidenceEngine.Evidence>>> byKey = new TreeMap<>();
        for (Observation observation : observations) {
            Map<String, List<ConfidenceEngine.Evidence>> byValue = byKey.get(observation.getKey());
            if (byValue == null) {
                byValue = new HashMap<>();
                byKey.put(observation.getKey(), byValue);
            }
            List<ConfidenceEngine.Evidence> list = byValue.get(observation.getValue());
            if (list == null) {
                list = new ArrayList<>();
                byValue.put(observation.getValue(), list);
            }
            list.add(new ConfidenceEngine.Evidence(observation.getSource(), observation.getConfidence(), observation.getAtMillis()));
        }
        Map<String, Estimate> state = new TreeMap<>();
        for (Map.Entry<String, Map<String, List<ConfidenceEngine.Evidence>>> key : byKey.entrySet()) {
            String bestValue = null;
            double bestConfidence = -1.0;
            int bestEvidence = 0;
            for (Map.Entry<String, List<ConfidenceEngine.Evidence>> candidate : key.getValue().entrySet()) {
                double combined = engine.combine(candidate.getValue(), nowMillis);
                if (combined > bestConfidence) {
                    bestConfidence = combined;
                    bestValue = candidate.getKey();
                    bestEvidence = candidate.getValue().size();
                }
            }
            boolean known = bestConfidence >= threshold;
            state.put(key.getKey(), new Estimate(known ? bestValue : null, Math.max(0.0, bestConfidence), bestEvidence));
        }
        return state;
    }
}
