package com.hiveminemobile.ai.modules;

import com.hiveminemobile.ai.Identifiers;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Phase 026. Keeps the user's alert inbox readable: repeated alerts on a topic are suppressed for a
 * while, and ordinary alerts are rate-limited. Critical alerts skip the rate limit, not the de-duplication.
 */
public final class NotificationAI extends BaseSpecialist {
    public static final String ID = "notification";
    private static final int INBOX_LIMIT = 100;
    private static final int TEXT_LIMIT = 200;

    public enum Level { INFO, WARNING, CRITICAL }

    public enum Decision { DELIVERED, DUPLICATE, RATE_LIMITED }

    public static final class Alert {
        private final long sequence;
        private final Level level;
        private final String topic;
        private final String text;
        private final long atMillis;

        Alert(long sequence, Level level, String topic, String text, long atMillis) {
            this.sequence = sequence;
            this.level = level;
            this.topic = topic;
            this.text = text;
            this.atMillis = atMillis;
        }

        public long getSequence() { return sequence; }
        public Level getLevel() { return level; }
        public String getTopic() { return topic; }
        public String getText() { return text; }
        public long getAtMillis() { return atMillis; }
    }

    private final long dedupeMillis;
    private final int maxPerWindow;
    private final long windowMillis;
    private final Map<String, Long> lastByTopic = new HashMap<>();
    private final ArrayDeque<Long> deliveries = new ArrayDeque<>();
    private final List<Alert> inbox = new ArrayList<>();
    private long nextSequence = 1L;

    public NotificationAI() {
        this(60_000L, 5, 300_000L);
    }

    public NotificationAI(long dedupeMillis, int maxPerWindow, long windowMillis) {
        super(ID, "report.notify");
        if (dedupeMillis < 0L) throw new IllegalArgumentException("dedupeMillis must not be negative");
        if (maxPerWindow < 1) throw new IllegalArgumentException("maxPerWindow must be at least 1");
        if (windowMillis < 1L) throw new IllegalArgumentException("windowMillis must be positive");
        this.dedupeMillis = dedupeMillis;
        this.maxPerWindow = maxPerWindow;
        this.windowMillis = windowMillis;
    }

    public synchronized Decision notify(Level level, String topic, String text, long nowMillis) {
        if (level == null) throw new IllegalArgumentException("level must not be null");
        if (!Identifiers.isValid(topic)) throw new IllegalArgumentException("topic is invalid");
        if (text == null || text.trim().isEmpty() || text.length() > TEXT_LIMIT) {
            throw new IllegalArgumentException("text must be 1-" + TEXT_LIMIT + " characters");
        }
        Long last = lastByTopic.get(topic);
        if (last != null && nowMillis - last < dedupeMillis) return Decision.DUPLICATE;
        while (!deliveries.isEmpty() && nowMillis - deliveries.peekFirst() >= windowMillis) deliveries.removeFirst();
        if (level != Level.CRITICAL && deliveries.size() >= maxPerWindow) return Decision.RATE_LIMITED;
        lastByTopic.put(topic, nowMillis);
        deliveries.addLast(nowMillis);
        inbox.add(new Alert(nextSequence++, level, topic, text.trim(), nowMillis));
        if (inbox.size() > INBOX_LIMIT) inbox.remove(0);
        return Decision.DELIVERED;
    }

    public synchronized List<Alert> inbox() {
        return Collections.unmodifiableList(new ArrayList<>(inbox));
    }
}
