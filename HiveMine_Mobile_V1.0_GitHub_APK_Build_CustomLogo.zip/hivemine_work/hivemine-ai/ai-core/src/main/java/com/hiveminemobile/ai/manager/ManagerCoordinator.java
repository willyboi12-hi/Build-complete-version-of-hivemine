package com.hiveminemobile.ai.manager;

import com.hiveminemobile.ai.AIConfiguration;
import com.hiveminemobile.ai.AIException;
import com.hiveminemobile.ai.AIInterface;
import com.hiveminemobile.ai.comm.AIMessage;
import com.hiveminemobile.ai.comm.MessageBus;
import com.hiveminemobile.ai.health.HealthMonitor;
import com.hiveminemobile.ai.memory.DecisionRecord;
import com.hiveminemobile.ai.memory.ManagerMemory;
import com.hiveminemobile.ai.policy.PolicySupervisor;
import com.hiveminemobile.ai.task.AssignmentGate;
import com.hiveminemobile.ai.task.Priority;
import com.hiveminemobile.ai.task.Task;
import com.hiveminemobile.ai.task.TaskCategory;
import com.hiveminemobile.ai.task.TaskManager;
import com.hiveminemobile.ai.task.TaskStatus;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Stage 1 entry point. It wires messaging, tasks, priority, memory, policy and health around
 * HiveMineManagerAI. Work and messages move only while the manager is RUNNING. Nothing here touches
 * Android or Roblox: specialists report results back through completeTask and failTask.
 */
public final class ManagerCoordinator {
    public static final String MANAGER_ADDRESS = "manager";

    private final ManagerController manager;
    private final MessageBus bus;
    private final PolicySupervisor policy = new PolicySupervisor();
    private final TaskManager tasks;
    private final ManagerMemory memory;
    private final HealthMonitor monitor;
    private volatile Set<String> unavailable = Collections.emptySet();

    /**
     * Reads these optional keys: comm.mailboxCapacity (64), memory.capacity (500),
     * tasks.maxAttempts (3), tasks.maxOpen (100), health.heartbeatTimeoutMillis (30000),
     * health.errorThreshold (5). Values below 1 fall back to the default.
     */
    public ManagerCoordinator(AIConfiguration configuration) {
        if (configuration == null) throw new IllegalArgumentException("configuration must not be null");
        this.manager = new ManagerController(configuration);
        this.bus = new MessageBus(positive(configuration, "comm.mailboxCapacity", 64));
        this.bus.register(MANAGER_ADDRESS);
        this.memory = new ManagerMemory(positive(configuration, "memory.capacity", 500));
        this.monitor = new HealthMonitor(
            positive(configuration, "health.heartbeatTimeoutMillis", 30_000),
            positive(configuration, "health.errorThreshold", 5));
        AssignmentGate gate = new AssignmentGate() {
            @Override public String refuse(Task task, String specialistId) {
                if (unavailable.contains(specialistId)) return "Specialist is unavailable: " + specialistId;
                return policy.refuse(task, specialistId);
            }
        };
        this.tasks = new TaskManager(manager.getSpecialistRegistry(), gate,
            positive(configuration, "tasks.maxAttempts", 3),
            positive(configuration, "tasks.maxOpen", 100));
    }

    public void registerSpecialist(AIInterface specialist) {
        registerSpecialist(specialist, Collections.<String>emptySet());
    }

    public void registerSpecialist(AIInterface specialist, Set<String> dependencies) {
        if (specialist == null) throw new IllegalArgumentException("specialist must not be null");
        if (MANAGER_ADDRESS.equals(specialist.getId())) {
            throw new IllegalArgumentException("'manager' is reserved for HiveMineManagerAI");
        }
        manager.registerSpecialist(specialist, dependencies);
        bus.register(specialist.getId());
    }

    public void start() throws AIException {
        manager.start();
    }

    public void shutdown() {
        manager.shutdown();
        unavailable = Collections.emptySet();
    }

    public MessageBus.Receipt send(String sender, String recipient, String type,
                                   Map<String, String> payload, long nowMillis) {
        if (!isRunning()) return MessageBus.Receipt.rejected(MessageBus.Status.REJECTED_NOT_RUNNING, NOT_RUNNING);
        return bus.send(sender, recipient, type, payload, nowMillis);
    }

    public List<AIMessage> drain(String address, int max) {
        return isRunning() ? bus.drain(address, max) : Collections.<AIMessage>emptyList();
    }

    public TaskManager.Result createTask(String title, String capability, Priority priority,
                                         TaskCategory category, long nowMillis) {
        if (!isRunning()) return notRunning();
        return tasks.create(title, capability, priority, category, nowMillis);
    }

    /** Refreshes health first, so a specialist with missed heartbeats is not given new work. */
    public TaskManager.Result assignTask(String taskId, long nowMillis) {
        if (!isRunning()) return notRunning();
        checkHealth(nowMillis);
        return tasks.assign(taskId, nowMillis);
    }

    public TaskManager.Result startTask(String taskId, String specialistId, long nowMillis) {
        if (!isRunning()) return notRunning();
        return tasks.start(taskId, specialistId, nowMillis);
    }

    public TaskManager.Result completeTask(String taskId, String specialistId, String summary, long nowMillis) {
        if (!isRunning()) return notRunning();
        TaskManager.Result result = tasks.complete(taskId, specialistId, summary, nowMillis);
        if (result.isOk()) {
            memory.record(taskId, result.getTask().getCapability(), specialistId, "task completed",
                DecisionRecord.Outcome.SUCCESS, summary, nowMillis);
        }
        return result;
    }

    public TaskManager.Result failTask(String taskId, String specialistId, String reason, long nowMillis) {
        if (!isRunning()) return notRunning();
        TaskManager.Result result = tasks.fail(taskId, specialistId, reason, nowMillis);
        if (result.isOk()) {
            String decision = result.getTask().getStatus() == TaskStatus.FAILED
                ? "task failed permanently" : "attempt failed, will retry";
            memory.record(taskId, result.getTask().getCapability(), specialistId, decision,
                DecisionRecord.Outcome.FAILURE, reason, nowMillis);
        }
        return result;
    }

    public TaskManager.Result cancelTask(String taskId, long nowMillis) {
        if (!isRunning()) return notRunning();
        TaskManager.Result result = tasks.cancel(taskId, nowMillis);
        if (result.isOk()) {
            memory.record(taskId, result.getTask().getCapability(), result.getTask().getAssignee(),
                "task cancelled", DecisionRecord.Outcome.UNKNOWN, "", nowMillis);
        }
        return result;
    }

    public List<Task> nextTasks(long nowMillis, int limit) {
        return tasks.nextPending(nowMillis, limit);
    }

    public void heartbeat(String componentId, long nowMillis) {
        monitor.heartbeat(componentId, nowMillis);
    }

    /** Evaluates health and updates which specialists are refused new work. */
    public HealthMonitor.Report checkHealth(long nowMillis) {
        HealthMonitor.Report report = monitor.evaluate(manager.checkHealth().getStatus(),
            manager.getSpecialistRegistry(), manager.getErrorHandler(), nowMillis);
        Set<String> down = new HashSet<>();
        for (HealthMonitor.ComponentHealth component : report.getComponents()) {
            if (component.getLevel() == HealthMonitor.Level.UNAVAILABLE) down.add(component.getComponentId());
        }
        unavailable = Collections.unmodifiableSet(down);
        return report;
    }

    public ManagerController getManager() { return manager; }
    public PolicySupervisor getPolicy() { return policy; }
    public ManagerMemory getMemory() { return memory; }
    public TaskManager getTasks() { return tasks; }
    public MessageBus getBus() { return bus; }

    private static final String NOT_RUNNING = "Manager is not running";

    private boolean isRunning() {
        return manager.canCoordinate();
    }

    private static TaskManager.Result notRunning() {
        return TaskManager.Result.of(TaskManager.Outcome.NOT_RUNNING, null, NOT_RUNNING);
    }

    private static int positive(AIConfiguration configuration, String key, int fallback) {
        int value = configuration.getInt(key, fallback);
        return value < 1 ? fallback : value;
    }
}
