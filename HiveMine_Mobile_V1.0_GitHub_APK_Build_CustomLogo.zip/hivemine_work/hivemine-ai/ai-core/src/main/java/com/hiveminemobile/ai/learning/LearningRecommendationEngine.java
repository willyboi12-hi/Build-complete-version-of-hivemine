package com.hiveminemobile.ai.learning;

import com.hiveminemobile.ai.modules.LearningAI;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Turns Learning AI insights into recommendations. Invalid and duplicate insights are skipped. */
public final class LearningRecommendationEngine {

    public List<Recommendation> fromInsights(List<LearningAI.Insight> insights) {
        List<Recommendation> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        if (insights == null) return out;
        for (LearningAI.Insight in : insights) {
            if (in == null || in.getCapability() == null || in.getAdvice() == null) continue;
            String advice = in.getAdvice().trim();
            if (advice.isEmpty() || in.getEvidence() < 1) continue;
            double rate = in.getSuccessRate();
            if (Double.isNaN(rate) || rate < 0.0 || rate > 1.0) continue;
            String key = (in.getCapability().trim() + "|" + advice).toLowerCase(Locale.ROOT);
            if (!seen.add(key)) continue;
            out.add(new Recommendation(key, in.getCapability().trim(), advice, in.getEvidence(), rate));
        }
        return out;
    }
}
