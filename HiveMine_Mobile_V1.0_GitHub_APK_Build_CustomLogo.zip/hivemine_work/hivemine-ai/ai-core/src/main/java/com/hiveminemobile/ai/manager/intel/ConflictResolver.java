package com.hiveminemobile.ai.manager.intel;

/**
 * Phase 074 — Resolves incompatible goals (e.g. FARM vs SHUTDOWN).
 */
public final class ConflictResolver {
    public ManagerGoal resolve(ManagerGoal a, ManagerGoal b) {
        if (a == null) return b == null ? ManagerGoal.STANDBY : b;
        if (b == null) return a;
        if (a == b) return a;
        // Hard overrides
        if (a == ManagerGoal.SHUTDOWN || b == ManagerGoal.SHUTDOWN) return ManagerGoal.SHUTDOWN;
        if (a == ManagerGoal.RECOVER_SESSION || b == ManagerGoal.RECOVER_SESSION) {
            return ManagerGoal.RECOVER_SESSION;
        }
        // Quest turn-in beats pure farming when both present
        if ((a == ManagerGoal.TURN_IN_QUEST && b == ManagerGoal.FARM_POLLEN)
                || (b == ManagerGoal.TURN_IN_QUEST && a == ManagerGoal.FARM_POLLEN)) {
            return ManagerGoal.TURN_IN_QUEST;
        }
        // Convert before more farming if bag pressure implied by CONVERT
        if ((a == ManagerGoal.CONVERT_HONEY && b == ManagerGoal.FARM_POLLEN)
                || (b == ManagerGoal.CONVERT_HONEY && a == ManagerGoal.FARM_POLLEN)) {
            return ManagerGoal.CONVERT_HONEY;
        }
        // Default: keep first (active hierarchy bias)
        return a;
    }
}
