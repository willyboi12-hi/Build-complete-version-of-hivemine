package com.hiveminemobile.ai.manager;

/** Immutable runtime snapshot for the HiveMineManagerAI supervisor. */
public final class ManagerRuntime {
    public enum State { NEW, INITIALIZING, READY, RUNNING, DEGRADED, STOPPING, STOPPED, FAILED }

    private final State state;
    private final long startedAtMillis;
    private final long lastStateChangeMillis;
    private final String message;
    private final int registeredModules;
    private final int initializedModules;

    ManagerRuntime(State state, long startedAtMillis, long lastStateChangeMillis,
                   String message, int registeredModules, int initializedModules) {
        this.state = state;
        this.startedAtMillis = startedAtMillis;
        this.lastStateChangeMillis = lastStateChangeMillis;
        this.message = message == null ? "" : message;
        this.registeredModules = registeredModules;
        this.initializedModules = initializedModules;
    }

    public State getState() { return state; }
    public long getStartedAtMillis() { return startedAtMillis; }
    public long getLastStateChangeMillis() { return lastStateChangeMillis; }
    public String getMessage() { return message; }
    public int getRegisteredModules() { return registeredModules; }
    public int getInitializedModules() { return initializedModules; }
    public boolean isAvailable() { return state == State.READY || state == State.RUNNING; }
}
