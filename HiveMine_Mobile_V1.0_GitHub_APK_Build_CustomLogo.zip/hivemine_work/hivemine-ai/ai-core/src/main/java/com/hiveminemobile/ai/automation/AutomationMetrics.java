package com.hiveminemobile.ai.automation;

/** Phase 068 — Counters for automation ticks and decisions. */
public final class AutomationMetrics {
    private long ticks;
    private long startsRequested;
    private long stopsRequested;
    private long recoversRequested;
    private long refused;
    private long faults;

    public void tick() { ticks++; }
    public void startRequested() { startsRequested++; }
    public void stopRequested() { stopsRequested++; }
    public void recoverRequested() { recoversRequested++; }
    public void refused() { refused++; }
    public void fault() { faults++; }

    public long ticks() { return ticks; }
    public long startsRequested() { return startsRequested; }
    public long stopsRequested() { return stopsRequested; }
    public long recoversRequested() { return recoversRequested; }
    public long refusedCount() { return refused; }
    public long faults() { return faults; }

    public void reset() {
        ticks = startsRequested = stopsRequested = recoversRequested = refused = faults = 0;
    }
}
