package com.hiveminemobile.ai.comm;

import com.hiveminemobile.ai.Identifiers;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Bounded in-memory messaging between registered addresses. Recipients pull their own mail with
 * drain(), so delivery never runs code inside another module. A full mailbox refuses the new
 * message; it never silently drops older mail.
 */
public final class MessageBus {
    public enum Status {
        ACCEPTED, REJECTED_INVALID, REJECTED_UNKNOWN_SENDER, REJECTED_UNKNOWN_RECIPIENT,
        REJECTED_MAILBOX_FULL, REJECTED_NOT_RUNNING
    }

    public static final class Receipt {
        private final Status status;
        private final AIMessage message;
        private final String reason;

        private Receipt(Status status, AIMessage message, String reason) {
            this.status = status;
            this.message = message;
            this.reason = reason;
        }

        static Receipt accepted(AIMessage message) {
            return new Receipt(Status.ACCEPTED, message, "Message queued");
        }

        public static Receipt rejected(Status status, String reason) {
            if (status == Status.ACCEPTED) throw new IllegalArgumentException("ACCEPTED is not a rejection");
            return new Receipt(status, null, reason);
        }

        public Status getStatus() { return status; }
        public AIMessage getMessage() { return message; }
        public String getReason() { return reason; }
        public boolean isAccepted() { return status == Status.ACCEPTED; }
    }

    private final int mailboxCapacity;
    private final Set<String> addresses = new LinkedHashSet<>();
    private final Map<String, ArrayDeque<AIMessage>> mailboxes = new HashMap<>();
    private long nextSequence = 1L;
    private long acceptedCount;
    private long rejectedCount;

    public MessageBus(int mailboxCapacity) {
        if (mailboxCapacity < 1) throw new IllegalArgumentException("mailboxCapacity must be at least 1");
        this.mailboxCapacity = mailboxCapacity;
    }

    public synchronized void register(String address) {
        if (!Identifiers.isValid(address)) throw new IllegalArgumentException("address is invalid");
        if (!addresses.add(address)) throw new IllegalArgumentException("address already registered: " + address);
        mailboxes.put(address, new ArrayDeque<AIMessage>());
    }

    public synchronized boolean unregister(String address) {
        if (address == null || !addresses.remove(address)) return false;
        mailboxes.remove(address);
        return true;
    }

    public synchronized Receipt send(String sender, String recipient, String type,
                                     Map<String, String> payload, long nowMillis) {
        Map<String, String> body = payload == null ? Collections.<String, String>emptyMap() : payload;
        if (!Identifiers.isValid(sender) || !Identifiers.isValid(recipient) || !Identifiers.isValid(type)) {
            return reject(Status.REJECTED_INVALID, "Sender, recipient and type must be valid identifiers");
        }
        if (sender.equals(recipient)) {
            return reject(Status.REJECTED_INVALID, "A module cannot message itself");
        }
        if (!addresses.contains(sender)) {
            return reject(Status.REJECTED_UNKNOWN_SENDER, "Sender is not registered: " + sender);
        }
        if (!addresses.contains(recipient)) {
            return reject(Status.REJECTED_UNKNOWN_RECIPIENT, "Recipient is not registered: " + recipient);
        }
        String problem = AIMessage.payloadProblem(body);
        if (problem != null) return reject(Status.REJECTED_INVALID, problem);
        ArrayDeque<AIMessage> mailbox = mailboxes.get(recipient);
        if (mailbox.size() >= mailboxCapacity) {
            return reject(Status.REJECTED_MAILBOX_FULL, "Recipient mailbox is full: " + recipient);
        }
        AIMessage message = new AIMessage(nextSequence++, sender, recipient, type, body, nowMillis);
        mailbox.addLast(message);
        acceptedCount++;
        return Receipt.accepted(message);
    }

    public synchronized List<AIMessage> drain(String address, int max) {
        if (max < 1) throw new IllegalArgumentException("max must be at least 1");
        ArrayDeque<AIMessage> mailbox = address == null ? null : mailboxes.get(address);
        if (mailbox == null) return Collections.emptyList();
        List<AIMessage> out = new ArrayList<>();
        while (out.size() < max && !mailbox.isEmpty()) out.add(mailbox.removeFirst());
        return Collections.unmodifiableList(out);
    }

    public synchronized int pending(String address) {
        ArrayDeque<AIMessage> mailbox = address == null ? null : mailboxes.get(address);
        return mailbox == null ? 0 : mailbox.size();
    }

    public synchronized Set<String> getAddresses() {
        return Collections.unmodifiableSet(new LinkedHashSet<>(addresses));
    }

    public synchronized long getAcceptedCount() { return acceptedCount; }
    public synchronized long getRejectedCount() { return rejectedCount; }

    private Receipt reject(Status status, String reason) {
        rejectedCount++;
        return Receipt.rejected(status, reason);
    }
}
