package com.hiveminemobile.ai.task;

/** Lifecycle of a task: PENDING -> ASSIGNED -> IN_PROGRESS -> COMPLETED, with FAILED or CANCELLED as closed ends. */
public enum TaskStatus {
    PENDING, ASSIGNED, IN_PROGRESS, COMPLETED, FAILED, CANCELLED;

    /** Open tasks still count toward the queue limit and can be cancelled. */
    public boolean isOpen() {
        return this == PENDING || this == ASSIGNED || this == IN_PROGRESS;
    }
}
