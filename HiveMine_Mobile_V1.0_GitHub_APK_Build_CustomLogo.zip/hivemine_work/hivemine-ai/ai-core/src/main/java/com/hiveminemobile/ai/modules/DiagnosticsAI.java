package com.hiveminemobile.ai.modules;

import com.hiveminemobile.ai.AIErrorHandler;
import com.hiveminemobile.ai.health.HealthMonitor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Phase 020. Reads the health report, the error journal and message counters, and lists the
 * problems it finds, most severe first. It diagnoses; it does not repair anything.
 */
public final class DiagnosticsAI extends BaseSpecialist {
    public static final String ID = "diagnostics";

    public enum Severity { INFO, WARNING, CRITICAL }

    public static final class Diagnostic {
        private final Severity severity;
        private final String component;
        private final String code;
        private final String message;

        Diagnostic(Severity severity, String component, String code, String message) {
            this.severity = severity;
            this.component = component;
            this.code = code;
            this.message = message;
        }

        public Severity getSeverity() { return severity; }
        /** Component the finding is about, or null for the whole application. */
        public String getComponent() { return component; }
        public String getCode() { return code; }
        public String getMessage() { return message; }
    }

    private static final long MIN_MESSAGES = 10L;
    private static final double MAX_REJECTED_SHARE = 0.2;
    private static final int STALE_KEY_LIMIT = 3;

    public DiagnosticsAI() {
        super(ID, "analyze.diagnostics");
    }

    public List<Diagnostic> diagnose(HealthMonitor.Report health, List<AIErrorHandler.AIError> errors,
                                     long messagesAccepted, long messagesRejected, int staleStateKeys) {
        List<Diagnostic> found = new ArrayList<>();
        for (HealthMonitor.ComponentHealth component : health.getComponents()) {
            if (component.getLevel() == HealthMonitor.Level.UNAVAILABLE) {
                found.add(new Diagnostic(Severity.CRITICAL, component.getComponentId(),
                    "COMPONENT_UNAVAILABLE", component.getDetail()));
            } else if (component.getLevel() == HealthMonitor.Level.DEGRADED) {
                found.add(new Diagnostic(Severity.WARNING, component.getComponentId(),
                    "COMPONENT_DEGRADED", component.getDetail()));
            }
        }
        Map<String, Integer> criticalByComponent = new TreeMap<>();
        for (AIErrorHandler.AIError error : errors) {
            if (error.getSeverity() != AIErrorHandler.Severity.CRITICAL) continue;
            Integer count = criticalByComponent.get(error.getComponentId());
            criticalByComponent.put(error.getComponentId(), count == null ? 1 : count + 1);
        }
        for (Map.Entry<String, Integer> entry : criticalByComponent.entrySet()) {
            found.add(new Diagnostic(Severity.CRITICAL, entry.getKey(), "CRITICAL_ERRORS",
                entry.getValue() + " critical error(s) recorded"));
        }
        long total = messagesAccepted + messagesRejected;
        if (total >= MIN_MESSAGES && messagesRejected >= total * MAX_REJECTED_SHARE) {
            found.add(new Diagnostic(Severity.WARNING, "manager", "MESSAGE_REJECTIONS",
                messagesRejected + " of " + total + " messages were refused"));
        }
        if (staleStateKeys >= STALE_KEY_LIMIT) {
            found.add(new Diagnostic(Severity.WARNING, null, "STATE_STALE",
                staleStateKeys + " shared state values are stale"));
        }
        if (found.isEmpty()) found.add(new Diagnostic(Severity.INFO, null, "ALL_CLEAR", "No problems found"));
        Collections.sort(found, new Comparator<Diagnostic>() {
            @Override public int compare(Diagnostic left, Diagnostic right) {
                int bySeverity = right.severity.compareTo(left.severity);
                if (bySeverity != 0) return bySeverity;
                String a = left.component == null ? "" : left.component;
                String b = right.component == null ? "" : right.component;
                return a.compareTo(b);
            }
        });
        return Collections.unmodifiableList(found);
    }
}
