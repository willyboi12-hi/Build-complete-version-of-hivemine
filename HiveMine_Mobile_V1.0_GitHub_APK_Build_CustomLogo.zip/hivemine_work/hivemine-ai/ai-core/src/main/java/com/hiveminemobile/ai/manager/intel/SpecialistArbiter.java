package com.hiveminemobile.ai.manager.intel;

import java.util.ArrayList;
import java.util.List;

/**
 * Phase 072 — Picks the highest-confidence vote; ties break by fixed specialist priority.
 */
public final class SpecialistArbiter {
    private static final String[] PRIORITY = {
            "Safety", "Recovery", "Quest", "Farming", "Navigation", "Vision", "Learning"
    };

    public SpecialistVote arbitrate(List<SpecialistVote> votes) {
        if (votes == null || votes.isEmpty()) {
            return new SpecialistVote("none", ManagerGoal.STANDBY, 0, "no votes");
        }
        SpecialistVote best = null;
        for (SpecialistVote v : votes) {
            if (v == null) continue;
            if (best == null || better(v, best)) best = v;
        }
        return best == null ? new SpecialistVote("none", ManagerGoal.STANDBY, 0, "no votes") : best;
    }

    private boolean better(SpecialistVote a, SpecialistVote b) {
        if (a.confidence > b.confidence + 1e-9) return true;
        if (b.confidence > a.confidence + 1e-9) return false;
        return rank(a.specialistId) < rank(b.specialistId);
    }

    private int rank(String id) {
        for (int i = 0; i < PRIORITY.length; i++) {
            if (PRIORITY[i].equalsIgnoreCase(id)) return i;
        }
        return PRIORITY.length + 1;
    }

    public List<SpecialistVote> filterMinConfidence(List<SpecialistVote> votes, double min) {
        ArrayList<SpecialistVote> out = new ArrayList<SpecialistVote>();
        if (votes == null) return out;
        for (SpecialistVote v : votes) {
            if (v != null && v.confidence >= min) out.add(v);
        }
        return out;
    }
}
