package com.hiveminemobile.ai.integration;
/** Phase 099 — Markdown integration status. */
public final class IntegrationReport {
    public String toMarkdown(IntegrationManifest m, LifecycleIntegrator life, IntegrationHealthCheck.Result health) {
        StringBuilder sb = new StringBuilder();
        sb.append("# Integration report\n\n");
        sb.append("- lifecycle: ").append(life == null ? "?" : life.phase()).append('\n');
        sb.append("- health: ").append(health == null ? "?" : (health.ok ? "OK" : "FAIL")).append('\n');
        if (health != null) sb.append("- detail: ").append(health.detail).append('\n');
        sb.append("- components:\n");
        if (m != null) {
            for (String id : m.ids()) {
                sb.append("  - ").append(id).append(" @ ").append(m.version(id)).append('\n');
            }
        }
        sb.append("- contract: ").append(HiveMineMobileContract.summary()).append('\n');
        return sb.toString();
    }
}
