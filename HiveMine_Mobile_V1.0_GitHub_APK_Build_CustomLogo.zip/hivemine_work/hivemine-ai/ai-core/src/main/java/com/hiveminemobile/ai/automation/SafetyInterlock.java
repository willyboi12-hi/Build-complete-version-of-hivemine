package com.hiveminemobile.ai.automation;

/**
 * Phase 066 — Hard safety limits for automation. Trip = forced stop path.
 */
public final class SafetyInterlock {
    private final long maxSessionMs;
    private final int maxConsecutiveFailures;
    private int consecutiveFailures;
    private boolean tripped;
    private String tripReason = "";

    public SafetyInterlock(long maxSessionMs, int maxConsecutiveFailures) {
        this.maxSessionMs = maxSessionMs > 0 ? maxSessionMs : Long.MAX_VALUE;
        this.maxConsecutiveFailures = Math.max(1, maxConsecutiveFailures);
    }

    public boolean isTripped() { return tripped; }
    public String tripReason() { return tripReason; }
    public int consecutiveFailures() { return consecutiveFailures; }

    public void reset() {
        consecutiveFailures = 0;
        tripped = false;
        tripReason = "";
    }

    public void recordSuccess() { consecutiveFailures = 0; }

    public void recordFailure(String reason) {
        consecutiveFailures++;
        if (consecutiveFailures >= maxConsecutiveFailures) {
            trip("failures:" + reason);
        }
    }

    public void checkSessionDuration(long activeMs) {
        if (activeMs > maxSessionMs) trip("max-session");
    }

    public void trip(String reason) {
        tripped = true;
        tripReason = reason == null ? "unknown" : reason;
    }
}
