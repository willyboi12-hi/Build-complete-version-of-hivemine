package com.hiveminemobile.ai.manager.intel;

/**
 * Phase 077 — Escalates repeated soft failures toward recover, then shutdown.
 */
public final class EscalationManager {
    public enum Level { NONE, WARN, RECOVER, SHUTDOWN }

    private final int warnAfter;
    private final int recoverAfter;
    private final int shutdownAfter;
    private int softFailures;

    public EscalationManager(int warnAfter, int recoverAfter, int shutdownAfter) {
        this.warnAfter = Math.max(1, warnAfter);
        this.recoverAfter = Math.max(this.warnAfter + 1, recoverAfter);
        this.shutdownAfter = Math.max(this.recoverAfter + 1, shutdownAfter);
    }

    public void recordSoftFailure() { softFailures++; }
    public void recordSuccess() { softFailures = 0; }
    public int softFailures() { return softFailures; }

    public Level level() {
        if (softFailures >= shutdownAfter) return Level.SHUTDOWN;
        if (softFailures >= recoverAfter) return Level.RECOVER;
        if (softFailures >= warnAfter) return Level.WARN;
        return Level.NONE;
    }

    public ManagerGoal goalOverride() {
        Level l = level();
        if (l == Level.SHUTDOWN) return ManagerGoal.SHUTDOWN;
        if (l == Level.RECOVER) return ManagerGoal.RECOVER_SESSION;
        return null;
    }
}
