package com.hiveminemobile.ai.modules;

import com.hiveminemobile.ai.Identifiers;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 * Phase 015. Compares two inventory readings and flags decreases that no declared spend explains.
 * Item names are identifiers such as "royal-jelly". Recognition of counts comes from VisionAI.
 */
public final class InventoryAI extends BaseSpecialist {
    public static final String ID = "inventory";

    public static final class Change {
        private final String item;
        private final int before;
        private final int after;
        private final boolean unexplained;

        Change(String item, int before, int after, boolean unexplained) {
            this.item = item;
            this.before = before;
            this.after = after;
            this.unexplained = unexplained;
        }

        public String getItem() { return item; }
        public int getBefore() { return before; }
        public int getAfter() { return after; }
        public int getDelta() { return after - before; }
        /** True when the count fell by more than the declared spend for this item. */
        public boolean isUnexplained() { return unexplained; }
    }

    public InventoryAI() {
        super(ID, "analyze.inventory");
    }

    /** Returns only the items whose count changed, sorted by name. declaredSpends may be null. */
    public List<Change> compare(Map<String, Integer> before, Map<String, Integer> after,
                                Map<String, Integer> declaredSpends) {
        Map<String, Integer> spends = declaredSpends == null ? Collections.<String, Integer>emptyMap() : declaredSpends;
        validate(before);
        validate(after);
        validate(spends);
        Set<String> items = new TreeSet<>(before.keySet());
        items.addAll(after.keySet());
        List<Change> changes = new ArrayList<>();
        for (String item : items) {
            int previous = before.getOrDefault(item, 0);
            int current = after.getOrDefault(item, 0);
            int delta = current - previous;
            if (delta == 0) continue;
            boolean unexplained = delta < 0 && -delta > spends.getOrDefault(item, 0);
            changes.add(new Change(item, previous, current, unexplained));
        }
        return Collections.unmodifiableList(changes);
    }

    private static void validate(Map<String, Integer> counts) {
        for (Map.Entry<String, Integer> entry : counts.entrySet()) {
            if (!Identifiers.isValid(entry.getKey())) {
                throw new IllegalArgumentException("item id is invalid: " + entry.getKey());
            }
            if (entry.getValue() == null || entry.getValue() < 0) {
                throw new IllegalArgumentException("count must be zero or more: " + entry.getKey());
            }
        }
    }
}
