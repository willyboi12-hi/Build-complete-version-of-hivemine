package com.hiveminemobile.ai.automation;

import com.hiveminemobile.ai.control.MacroStatus;

/**
 * Phase 063 — Maps observed macro status + desired goal into a single action.
 * Does not call the macro; pure decision.
 */
public final class ActionPlanner {
    public enum Goal {
        IDLE,           // want stopped
        FARM,           // want running
        RECOVER_THEN_FARM
    }

    public AutomationAction plan(Goal goal, MacroStatus status, boolean faulted) {
        if (faulted) return AutomationAction.STOP;
        if (status == null || !status.isConnected()) {
            return goal == Goal.IDLE ? AutomationAction.NONE : AutomationAction.NONE;
        }
        switch (goal) {
            case IDLE:
                return status.isRunning() ? AutomationAction.STOP : AutomationAction.NONE;
            case FARM:
                if (status.isRunning()) return AutomationAction.NONE;
                return AutomationAction.START;
            case RECOVER_THEN_FARM:
                if (status.isRunning()) return AutomationAction.NONE;
                // Prefer recover when not running so the session can rejoin first
                return AutomationAction.RECOVER;
            default:
                return AutomationAction.NONE;
        }
    }
}
