package com.hiveminemobile.ai.manager;
/** Tracks decision latency samples for the manager. */
public final class ManagerPerformanceMonitor {
    private long samples; private long totalMs; private long maxMs;
    public void recordMs(long ms) {
        if (ms < 0) ms = 0;
        samples++; totalMs += ms; if (ms > maxMs) maxMs = ms;
    }
    public long samples() { return samples; }
    public double avgMs() { return samples == 0 ? 0 : (double) totalMs / samples; }
    public long maxMs() { return maxMs; }
}
