package com.hiveminemobile.ai.integration;

import com.hiveminemobile.ai.automation.ActionPlanner;
import com.hiveminemobile.ai.automation.AutomationOrchestrator;
import com.hiveminemobile.ai.control.AutomationController;
import com.hiveminemobile.ai.control.MacroPort;
import com.hiveminemobile.ai.control.MacroStatus;
import com.hiveminemobile.ai.manager.intel.ManagerGoal;
import com.hiveminemobile.ai.manager.intel.ManagerIntelligenceLoop;
import com.hiveminemobile.ai.manager.intel.ManagerPolicyEngine;
import com.hiveminemobile.ai.manager.intel.SpecialistVote;
import com.hiveminemobile.ai.optimize.OptimizationEngine;
import com.hiveminemobile.ai.optimize.OptimizationPolicy;

import java.util.Collections;

/**
 * Phase 098 — JVM end-to-end: policy/intel → optimization → automation → fake MacroPort.
 */
public final class EndToEndSimulation {
    public static final class FakePort implements MacroPort {
        public boolean connected = true;
        public boolean running;
        public int starts;
        @Override public void start() { starts++; running = true; }
        @Override public void stop() { running = false; }
        @Override public void recover() { running = false; }
        @Override public MacroStatus readStatus() {
            return connected ? MacroStatus.connected(running, "sim") : MacroStatus.disconnected("sim");
        }
    }

    public static final class Result {
        public final ManagerGoal goal;
        public final boolean running;
        public final int starts;
        public Result(ManagerGoal goal, boolean running, int starts) {
            this.goal = goal;
            this.running = running;
            this.starts = starts;
        }
    }

    public Result runFarmPath() {
        FakePort port = new FakePort();
        AutomationController ac = new AutomationController(port);
        ac.setAiControlEnabled(true);
        AutomationOrchestrator orch = new AutomationOrchestrator(ac, port, 50, 60_000L, 3, 5);
        orch.arm("e2e", 0);

        ManagerIntelligenceLoop loop = new ManagerIntelligenceLoop(null);
        loop.bindAutomation(orch);
        OptimizationEngine opt = new OptimizationEngine(new OptimizationPolicy());

        ManagerPolicyEngine.WorldFlags flags = new ManagerPolicyEngine.WorldFlags();
        flags.userWantsFarm = true;
        ManagerGoal g = loop.step(flags, Collections.singletonList(
                new SpecialistVote("Farming", ManagerGoal.FARM_POLLEN, 0.85, "e2e")
        ));
        g = opt.optimizeGoalStream(g);
        orch.tick(0);
        orch.tick(50);
        return new Result(g, port.running, port.starts);
    }
}
