package com.hiveminemobile.ai.observation;

import com.hiveminemobile.ai.Identifiers;
import com.hiveminemobile.ai.modules.VisionAI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Phase 042. Identifies which known screen a frame shows. Each screen is defined by marker signatures
 * and the number of markers that must be present. If two screens qualify equally, the result is
 * ambiguous and no screen is chosen.
 */
public final class InterfaceRegistry {
    public static final class Identification {
        private final String screen;
        private final int matched;
        private final boolean ambiguous;

        Identification(String screen, int matched, boolean ambiguous) {
            this.screen = screen;
            this.matched = matched;
            this.ambiguous = ambiguous;
        }

        /** Null when no screen qualified or the match was ambiguous. */
        public String getScreen() { return screen; }
        public int getMatched() { return matched; }
        public boolean isAmbiguous() { return ambiguous; }
    }

    private static final class Screen {
        final String name;
        final List<VisionAI.Signature> markers;
        final int required;

        Screen(String name, List<VisionAI.Signature> markers, int required) {
            this.name = name;
            this.markers = markers;
            this.required = required;
        }
    }

    private final VisionAI vision = new VisionAI();
    private final List<Screen> screens = new ArrayList<>();

    public synchronized void define(String name, List<VisionAI.Signature> markers, int required) {
        if (!Identifiers.isValid(name)) throw new IllegalArgumentException("screen name is invalid");
        if (markers == null || markers.isEmpty()) throw new IllegalArgumentException("at least one marker is required");
        if (required < 1 || required > markers.size()) throw new IllegalArgumentException("required must be 1..markers");
        for (Screen screen : screens) {
            if (screen.name.equals(name)) throw new IllegalArgumentException("screen already defined: " + name);
        }
        screens.add(new Screen(name, Collections.unmodifiableList(new ArrayList<>(markers)), required));
    }

    public synchronized Identification identify(VisionAI.Frame frame) {
        List<Screen> eligible = new ArrayList<>();
        List<Integer> counts = new ArrayList<>();
        for (Screen screen : screens) {
            int present = 0;
            for (VisionAI.Detection detection : vision.recognize(frame, screen.markers)) {
                if (detection.isPresent()) present++;
            }
            if (present >= screen.required) {
                eligible.add(screen);
                counts.add(present);
            }
        }
        if (eligible.isEmpty()) return new Identification(null, 0, false);
        int best = Collections.max(counts);
        int atBest = 0;
        Screen chosen = null;
        for (int i = 0; i < eligible.size(); i++) {
            if (counts.get(i) == best) {
                atBest++;
                chosen = eligible.get(i);
            }
        }
        if (atBest > 1) return new Identification(null, best, true);
        return new Identification(chosen.name, best, false);
    }
}
