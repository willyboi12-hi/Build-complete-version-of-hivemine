package com.hiveminemobile.ai.modules;

import com.hiveminemobile.ai.Identifiers;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.OptionalInt;

/**
 * Phase 011. Recognises Bee Swarm interface elements in frames the app layer captured with the
 * user's permission. VisionAI never captures the screen itself; it reads only the pixels it is given.
 */
public final class VisionAI extends BaseSpecialist {
    public static final String ID = "vision";

    /** Packed 0xAARRGGBB pixels, row by row. The array is used as given and must not change during analysis. */
    public static final class Frame {
        private final int width;
        private final int height;
        private final int[] argb;

        public Frame(int width, int height, int[] argb) {
            if (width < 1 || height < 1) throw new IllegalArgumentException("frame size must be positive");
            if (argb == null || (long) width * height != argb.length) {
                throw new IllegalArgumentException("pixel count does not match the frame size");
            }
            this.width = width;
            this.height = height;
            this.argb = argb;
        }

        public int getWidth() { return width; }
        public int getHeight() { return height; }

        int rgb(int x, int y) { return argb[y * width + x] & 0xFFFFFF; }
    }

    public static final class Region {
        private final int x;
        private final int y;
        private final int width;
        private final int height;

        public Region(int x, int y, int width, int height) {
            if (width < 1 || height < 1) throw new IllegalArgumentException("region size must be positive");
            this.x = x;
            this.y = y;
            this.width = width;
            this.height = height;
        }

        public int getX() { return x; }
        public int getY() { return y; }
        public int getWidth() { return width; }
        public int getHeight() { return height; }
    }

    /** A named element: its region, the colour it should show, and how much of the region must match. */
    public static final class Signature {
        private final String name;
        private final Region region;
        private final int expectedRgb;
        private final int tolerance;
        private final double minimumMatch;

        public Signature(String name, Region region, int expectedRgb, int tolerance, double minimumMatch) {
            if (!Identifiers.isValid(name)) throw new IllegalArgumentException("signature name is invalid");
            if (region == null) throw new IllegalArgumentException("region must not be null");
            if (tolerance < 0 || tolerance > 255) throw new IllegalArgumentException("tolerance must be 0-255");
            if (minimumMatch < 0.0 || minimumMatch > 1.0) throw new IllegalArgumentException("minimumMatch must be 0-1");
            this.name = name;
            this.region = region;
            this.expectedRgb = expectedRgb & 0xFFFFFF;
            this.tolerance = tolerance;
            this.minimumMatch = minimumMatch;
        }

        public String getName() { return name; }
    }

    public static final class Detection {
        private final String name;
        private final boolean present;
        private final double confidence;
        private final String note;

        Detection(String name, boolean present, double confidence, String note) {
            this.name = name;
            this.present = present;
            this.confidence = confidence;
            this.note = note;
        }

        public String getName() { return name; }
        public boolean isPresent() { return present; }
        public double getConfidence() { return confidence; }
        public String getNote() { return note; }
    }

    public VisionAI() {
        super(ID, "observe.frame");
    }

    public List<Detection> recognize(Frame frame, List<Signature> signatures) {
        List<Detection> found = new ArrayList<>();
        for (Signature signature : signatures) {
            if (!fits(frame, signature.region)) {
                found.add(new Detection(signature.name, false, 0.0, "region is outside the frame"));
                continue;
            }
            double ratio = matchRatio(frame, signature.region, signature.expectedRgb, signature.tolerance);
            boolean present = ratio >= signature.minimumMatch;
            found.add(new Detection(signature.name, present, ratio, present ? "matched" : "below minimum match"));
        }
        return Collections.unmodifiableList(found);
    }

    /** Share of pixels in the region within tolerance of the colour. 0 when the region is outside the frame. */
    public double matchRatio(Frame frame, Region region, int rgb, int tolerance) {
        if (!fits(frame, region)) return 0.0;
        int matches = 0;
        for (int dy = 0; dy < region.height; dy++) {
            for (int dx = 0; dx < region.width; dx++) {
                if (close(frame.rgb(region.x + dx, region.y + dy), rgb, tolerance)) matches++;
            }
        }
        return matches / (double) ((long) region.width * region.height);
    }

    /**
     * Reads a left-to-right gauge, such as the pollen bag, as the percentage of columns filled from
     * the left. A column counts as filled when at least half its pixels match the fill colour.
     * Empty when the strip lies outside the frame.
     */
    public OptionalInt readGauge(Frame frame, Region strip, int fillRgb, int tolerance) {
        if (!fits(frame, strip)) return OptionalInt.empty();
        int run = 0;
        while (run < strip.width && columnFilled(frame, strip, run, fillRgb & 0xFFFFFF, tolerance)) run++;
        return OptionalInt.of((int) ((long) run * 100L / strip.width));
    }

    private static boolean columnFilled(Frame frame, Region strip, int dx, int rgb, int tolerance) {
        int matches = 0;
        for (int dy = 0; dy < strip.height; dy++) {
            if (close(frame.rgb(strip.x + dx, strip.y + dy), rgb, tolerance)) matches++;
        }
        return matches * 2 >= strip.height;
    }


    /** Lightweight whole-frame analysis used by the Android adapter. It touches the complete frame
     * rather than a single configured pixel/region and is safe to run on every sampled screenshot. */
    public FrameAnalysis analyzeFrame(Frame frame) {
        if (frame == null) throw new IllegalArgumentException("frame must not be null");
        long sum = 0L;
        long sumSq = 0L;
        long checksum = 0xCBF29CE484222325L;
        long pixels = (long) frame.width * frame.height;
        for (int y = 0; y < frame.height; y++) {
            for (int x = 0; x < frame.width; x++) {
                int rgb = frame.rgb(x, y);
                int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
                int luminance = (299 * r + 587 * g + 114 * b) / 1000;
                sum += luminance;
                sumSq += (long) luminance * luminance;
                checksum ^= rgb & 0xFFFFFFL;
                checksum *= 0x100000001B3L;
            }
        }
        double mean = pixels == 0 ? 0.0 : sum / (double) pixels;
        double variance = pixels == 0 ? 0.0 : Math.max(0.0, sumSq / (double) pixels - mean * mean);
        return new FrameAnalysis(frame.width, frame.height, mean, Math.sqrt(variance), checksum);
    }

    public static final class FrameAnalysis {
        private final int width, height;
        private final double meanLuminance, luminanceDeviation;
        private final long contentHash;
        FrameAnalysis(int width, int height, double meanLuminance, double luminanceDeviation, long contentHash) {
            this.width = width; this.height = height; this.meanLuminance = meanLuminance;
            this.luminanceDeviation = luminanceDeviation; this.contentHash = contentHash;
        }
        public int getWidth() { return width; }
        public int getHeight() { return height; }
        public double getMeanLuminance() { return meanLuminance; }
        public double getLuminanceDeviation() { return luminanceDeviation; }
        public long getContentHash() { return contentHash; }
    }

    private static boolean fits(Frame frame, Region region) {
        return region.x >= 0 && region.y >= 0
            && (long) region.x + region.width <= frame.width
            && (long) region.y + region.height <= frame.height;
    }

    private static boolean close(int a, int b, int tolerance) {
        return Math.abs(((a >> 16) & 0xFF) - ((b >> 16) & 0xFF)) <= tolerance
            && Math.abs(((a >> 8) & 0xFF) - ((b >> 8) & 0xFF)) <= tolerance
            && Math.abs((a & 0xFF) - (b & 0xFF)) <= tolerance;
    }
}
