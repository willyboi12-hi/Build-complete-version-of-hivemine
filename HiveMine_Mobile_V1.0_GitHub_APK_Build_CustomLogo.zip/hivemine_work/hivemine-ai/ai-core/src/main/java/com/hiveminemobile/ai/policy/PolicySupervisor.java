package com.hiveminemobile.ai.policy;

import com.hiveminemobile.ai.Identifiers;
import com.hiveminemobile.ai.task.AssignmentGate;
import com.hiveminemobile.ai.task.Task;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Default-deny capability policy. A capability may be used only after the user grants it. Anything
 * under a hard-denied prefix (input, game internals, Android permissions, policy edits, bypasses)
 * can never be granted, so no specialist can unlock it at runtime.
 */
public final class PolicySupervisor implements AssignmentGate {
    static final String[] HARD_DENIED_PREFIXES = {"input.", "game.", "android.", "policy.", "bypass."};
    static final int MAX_AUDIT_ENTRIES = 100;

    private final Map<String, Long> grants = new LinkedHashMap<>();
    private final ArrayDeque<String> audit = new ArrayDeque<>();

    public static boolean isHardDenied(String capability) {
        if (capability == null) return true;
        for (String prefix : HARD_DENIED_PREFIXES) {
            if (capability.startsWith(prefix)) return true;
        }
        return false;
    }

    public synchronized boolean grant(String capability, long nowMillis) {
        if (!Identifiers.isValid(capability)) {
            record("grant refused, invalid capability: " + capability);
            return false;
        }
        if (isHardDenied(capability)) {
            record("grant refused, hard-denied: " + capability);
            return false;
        }
        grants.put(capability, nowMillis);
        record("granted: " + capability);
        return true;
    }

    public synchronized boolean revoke(String capability) {
        boolean removed = grants.remove(capability) != null;
        if (removed) record("revoked: " + capability);
        return removed;
    }

    public synchronized boolean isGranted(String capability) {
        return !isHardDenied(capability) && grants.containsKey(capability);
    }

    public synchronized Set<String> getGranted() {
        return Collections.unmodifiableSet(new LinkedHashSet<>(grants.keySet()));
    }

    /** Returns null when the task's capability is granted, otherwise the reason it is refused. */
    @Override
    public synchronized String refuse(Task task, String specialistId) {
        String capability = task.getCapability();
        if (isHardDenied(capability)) {
            record("refused hard-denied " + capability + " for " + specialistId);
            return "Capability is never permitted: " + capability;
        }
        if (!grants.containsKey(capability)) {
            record("refused ungranted " + capability + " for " + specialistId);
            return "Capability not granted by the user: " + capability;
        }
        return null;
    }

    public synchronized List<String> getAuditTrail() {
        return Collections.unmodifiableList(new ArrayList<>(audit));
    }

    private void record(String entry) {
        while (audit.size() >= MAX_AUDIT_ENTRIES) audit.removeFirst();
        audit.addLast(entry);
    }
}
