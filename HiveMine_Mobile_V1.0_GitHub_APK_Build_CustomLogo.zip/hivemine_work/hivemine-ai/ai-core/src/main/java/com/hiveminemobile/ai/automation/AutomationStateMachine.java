package com.hiveminemobile.ai.automation;

/**
 * Phase 067 — Explicit state machine for automation infrastructure.
 */
public final class AutomationStateMachine {
    private AutomationState state = AutomationState.IDLE;

    public AutomationState state() { return state; }

    public boolean arm() {
        if (state != AutomationState.IDLE && state != AutomationState.FAULT) return false;
        state = AutomationState.ARMED;
        return true;
    }

    public boolean startRunning() {
        if (state != AutomationState.ARMED && state != AutomationState.RECOVERING) return false;
        state = AutomationState.RUNNING;
        return true;
    }

    public boolean beginRecover() {
        if (state != AutomationState.RUNNING && state != AutomationState.ARMED) return false;
        state = AutomationState.RECOVERING;
        return true;
    }

    public boolean beginStop() {
        if (state == AutomationState.IDLE) return false;
        state = AutomationState.STOPPING;
        return true;
    }

    public boolean toIdle() {
        state = AutomationState.IDLE;
        return true;
    }

    public boolean fault() {
        state = AutomationState.FAULT;
        return true;
    }
}
