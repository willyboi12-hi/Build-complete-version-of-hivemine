package com.hiveminemobile.ai.task;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Deterministic importance score. Priority sets the main band (100 points per level), category
 * breaks ties inside a band, waiting time slowly lifts old tasks so they are not starved, and each
 * failed attempt lowers a task so broken work does not keep jumping the queue.
 */
public final class PriorityScorer {
    static final int PRIORITY_STEP = 100;
    static final int MAX_AGING_POINTS = 60;
    static final int RETRY_PENALTY = 10;
    static final int MAX_RETRY_PENALTY = 30;
    private static final long MINUTE_MILLIS = 60_000L;

    private PriorityScorer() { }

    public static int score(Task task, long nowMillis) {
        int base = task.getPriority().getWeight() * PRIORITY_STEP;
        long waitedMinutes = Math.max(0L, nowMillis - task.getCreatedAtMillis()) / MINUTE_MILLIS;
        int aging = (int) Math.min(MAX_AGING_POINTS, waitedMinutes);
        int penalty = Math.min(MAX_RETRY_PENALTY, RETRY_PENALTY * task.getAttempts());
        return base + categoryPoints(task.getCategory()) + aging - penalty;
    }

    /** Returns the tasks sorted best first. Ties fall back to older creation time, then to id. */
    public static List<Task> rank(Collection<Task> tasks, long nowMillis) {
        List<Task> sorted = new ArrayList<>(tasks);
        Collections.sort(sorted, new Comparator<Task>() {
            @Override public int compare(Task left, Task right) {
                int byScore = Integer.compare(score(right, nowMillis), score(left, nowMillis));
                if (byScore != 0) return byScore;
                int byAge = Long.compare(left.getCreatedAtMillis(), right.getCreatedAtMillis());
                return byAge != 0 ? byAge : left.getId().compareTo(right.getId());
            }
        });
        return Collections.unmodifiableList(sorted);
    }

    private static int categoryPoints(TaskCategory category) {
        switch (category) {
            case RECOVERY: return 40;
            case OBSERVATION: return 20;
            case ANALYSIS: return 10;
            default: return 0;
        }
    }
}
