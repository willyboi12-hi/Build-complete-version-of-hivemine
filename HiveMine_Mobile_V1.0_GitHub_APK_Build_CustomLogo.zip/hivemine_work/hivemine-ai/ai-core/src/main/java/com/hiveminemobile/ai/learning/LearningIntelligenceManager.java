package com.hiveminemobile.ai.learning;

import com.hiveminemobile.ai.memory.DecisionRecord;
import com.hiveminemobile.ai.modules.LearningAI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.OptionalDouble;

/**
 * Phase 080: connects Learning AI to the rest of the system. It produces validated recommendations and
 * records outcomes. It has no method that changes a setting, so the user's settings are never overridden.
 */
public final class LearningIntelligenceManager {
    private final LearningAI learner;
    private final LearningDataCollector collector;
    private final LearningRecommendationEngine engine;
    private final LearningResultEvaluator evaluator;
    private final LearningIntegrationBridge bridge;
    private List<Recommendation> current = Collections.emptyList();
    private int lastRejected;

    public LearningIntelligenceManager(LearningAI learner) {
        this(learner, new LearningDataCollector(), new LearningRecommendationEngine(),
             new LearningResultEvaluator(), new LearningIntegrationBridge());
    }

    LearningIntelligenceManager(LearningAI learner, LearningDataCollector collector, LearningRecommendationEngine engine,
                                LearningResultEvaluator evaluator, LearningIntegrationBridge bridge) {
        if (learner == null) throw new IllegalArgumentException("learner must not be null");
        this.learner = learner;
        this.collector = collector;
        this.engine = engine;
        this.evaluator = evaluator;
        this.bridge = bridge;
    }

    /** Learns from history and returns the current proposals. Rejections made earlier are kept. */
    public synchronized List<Recommendation> refresh(List<DecisionRecord> history) {
        LearningDataCollector.Collected collected = collector.collect(history);
        lastRejected = collected.rejected;
        Map<String, Recommendation.Status> priorStatus = new HashMap<>();
        for (Recommendation r : current) priorStatus.put(r.getId(), r.getStatus());
        List<Recommendation> fresh = engine.fromInsights(learner.learn(collected.valid));
        for (Recommendation r : fresh) {
            Recommendation.Status prior = priorStatus.get(r.getId());
            if (prior != null) r.setStatus(prior);
        }
        current = fresh;
        return recommendations();
    }

    public synchronized List<Recommendation> recommendations() {
        return Collections.unmodifiableList(new ArrayList<>(current));
    }

    public synchronized int lastRejectedRecords() { return lastRejected; }

    /** Returns true if the recommendation exists and was not already rejected. */
    public synchronized boolean reject(String id) {
        Recommendation r = find(id);
        if (r == null) return false;
        r.setStatus(Recommendation.Status.REJECTED);
        return true;
    }

    /** Records whether the user applied a recommendation and it helped. Rejected proposals cannot record outcomes. */
    public synchronized boolean reportOutcome(String id, boolean improved) {
        Recommendation r = find(id);
        if (r == null || r.getStatus() == Recommendation.Status.REJECTED) return false;
        evaluator.record(id, improved);
        r.setStatus(Recommendation.Status.OUTCOME_RECORDED);
        return true;
    }

    public OptionalDouble improvementRate(String id) { return evaluator.improvementRate(id); }

    public List<String> connectedSystems() { return bridge.connectedSystems(); }

    public List<String> routeFor(Recommendation r) { return bridge.routeFor(r); }

    private Recommendation find(String id) {
        if (id == null) return null;
        for (Recommendation r : current) if (r.getId().equals(id)) return r;
        return null;
    }
}
