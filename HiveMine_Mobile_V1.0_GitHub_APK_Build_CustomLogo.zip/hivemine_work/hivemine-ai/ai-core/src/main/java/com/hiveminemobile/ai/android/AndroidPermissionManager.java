package com.hiveminemobile.ai.android;

import java.util.*;

/** Phase 087: checks permissions through a provider. A permission is never assumed to be granted. */
public final class AndroidPermissionManager {
    public enum State { GRANTED, DENIED, UNKNOWN }

    /** Implemented by the Android app. Returns true only when the permission is granted. */
    public interface Provider { boolean isGranted(String permission); }

    static final Map<String, List<String>> FEATURE_NEEDS;
    static {
        Map<String, List<String>> m = new TreeMap<>();
        m.put("macro-control", Collections.singletonList("accessibility"));
        m.put("screen-observation", Collections.singletonList("screen-capture"));
        FEATURE_NEEDS = Collections.unmodifiableMap(m);
    }

    private final Provider provider;
    private final Set<String> lastGranted = new TreeSet<>();
    private final Set<String> revoked = new TreeSet<>();

    public AndroidPermissionManager(Provider provider) { this.provider = provider; }

    public State state(String permission) {
        if (provider == null) return State.UNKNOWN;
        try {
            boolean ok = provider.isGranted(permission);
            if (ok) lastGranted.add(permission);
            else if (lastGranted.remove(permission)) revoked.add(permission);
            return ok ? State.GRANTED : State.DENIED;
        } catch (RuntimeException e) {
            return State.UNKNOWN;
        }
    }

    public boolean featureEnabled(String feature) {
        List<String> needs = FEATURE_NEEDS.get(feature);
        if (needs == null) return false;
        for (String p : needs) if (state(p) != State.GRANTED) return false;
        return true;
    }

    public String explain(String feature) {
        List<String> needs = FEATURE_NEEDS.get(feature);
        if (needs == null) return feature + " is unknown";
        List<String> missing = new ArrayList<>();
        for (String p : needs) if (state(p) != State.GRANTED) missing.add(p);
        return missing.isEmpty() ? feature + " is enabled" : feature + " is off: grant " + missing;
    }

    public synchronized Set<String> revoked() { return Collections.unmodifiableSet(new TreeSet<>(revoked)); }
}
