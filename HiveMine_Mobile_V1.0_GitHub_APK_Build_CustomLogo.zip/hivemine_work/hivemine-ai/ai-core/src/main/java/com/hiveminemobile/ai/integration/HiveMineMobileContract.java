package com.hiveminemobile.ai.integration;
/** Phase 093 — Documented expectations for the HiveMine Mobile merge (no Android types). */
public final class HiveMineMobileContract {
    public static final String MACRO_PORT = "com.hiveminemobile.ai.control.MacroPort";
    public static final String AI_CONTROL_SETTING = "ai_control_enabled";
    public static final String[] REQUIRED_CAPABILITIES = {
            "start", "stop", "recover", "readStatus"
    };
    public static boolean hasCapability(String name) {
        if (name == null) return false;
        for (String c : REQUIRED_CAPABILITIES) if (c.equals(name)) return true;
        return false;
    }
    public static String summary() {
        return "HiveMine Mobile must implement MacroPort and only enable AI control from user settings.";
    }
}
