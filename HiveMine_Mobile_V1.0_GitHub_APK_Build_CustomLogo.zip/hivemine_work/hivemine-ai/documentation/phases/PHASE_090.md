# Phase 090 — Android configuration sync manager

Domain: ANDROID

## Status
Implemented in JVM code and tested (checks in `tests/unit/com/hiveminemobile/Phases081To090Tests.java`). Not run on an Android device.

## What it does
Syncs the AI profile to the macro's configuration store. It backs up the current settings before each write, and reports a conflict instead of overwriting settings changed outside the AI.

## API
- `sync(profile)`, `restorePrevious()`, `differences(profile)`, `backupCount()`. The store is supplied by the Android app.

## Not done
- Not wired to the dashboard. The JVM logic is tested, not the app.
- Overlap with existing code: see `OVERLAPS.md`.
