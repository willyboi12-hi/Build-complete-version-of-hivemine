# Phase 081 — Historical performance analysis

Domain: HISTORY

## Status
Implemented in JVM code and tested (checks in `tests/unit/com/hiveminemobile/Phases081To090Tests.java`). Not run on an Android device.

## What it does
Groups recorded decisions by capability and decision, counts repeated failures and successes, and counts incomplete records instead of guessing. UNKNOWN outcomes are excluded from rates.

## API
- `HistoricalPerformanceAnalyzer.analyze(List<DecisionRecord>)` returns a `Report` with `byCapability`, `repeatedFailures`, `successfulDecisions`, `incomplete`, and `toMarkdown()`.
- `rateOf(records, decision)` returns the success rate, or NaN when there is no data.

## Not done
- Not wired to the dashboard. The JVM logic is tested, not the app.
- Overlap with existing code: see `OVERLAPS.md`.
