# Phase 088 — Screen observation manager

Domain: ANDROID

## Status
Implemented in JVM code and tested (checks in `tests/unit/com/hiveminemobile/Phases081To090Tests.java`). Not run on an Android device.

## What it does
Accepts a screenshot only when screen observation is permitted and the bytes are a valid PNG. The buffer is bounded and drops the oldest frame.

## API
- `observe(now)` returns OBSERVED, NOT_PERMITTED, NO_IMAGE, INVALID_IMAGE, or FAILED. The capture adapter is supplied by the Android app.

## Not done
- Not wired to the dashboard. The JVM logic is tested, not the app.
- Overlap with existing code: see `OVERLAPS.md`.
