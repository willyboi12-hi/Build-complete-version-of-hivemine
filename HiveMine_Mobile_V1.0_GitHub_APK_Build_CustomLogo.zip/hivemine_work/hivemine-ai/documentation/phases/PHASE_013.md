# Phase 013 — FarmingAI

## Objective

Analyse pollen and honey farming performance.

## Implementation

modules/FarmingAI.java: Sample, Report; analyze().

## Dependencies

BaseSpecialist. Depends on state.

## Integration

Feeds PredictionAI. Reports only; changes nothing in the game.

## Testing

FarmingAITests: fill rate, conversions, time at 100%, honey change, ordering, validation.

## Completion criteria

- Module registered with `ManagerCoordinator` and reported AVAILABLE after start.
- Capability `analyze.farming` granted only through the policy supervisor.
- Unit checks pass in `tests/run.sh`.
- Result: Reports pollen rate, conversions, full-bag time, and honey change with advisory notes.

## Safety boundary

Analysis only. The module reads data it is given and never performs a game or device action.
