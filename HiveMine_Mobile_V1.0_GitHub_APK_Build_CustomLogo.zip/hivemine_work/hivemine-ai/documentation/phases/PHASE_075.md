# Phase 075 — Plan graph

Domain: MANAGER_INTEL
Implementor (per index): `com.hiveminemobile.ai.manager.intel.ManagerIntelligenceLoop`

## What it covers
- Phase 075 — Linear plan for v1 (graph can grow later). Cursor advances on complete.
- Phase 075 — One step in a manager plan.

## Source
- `hivemine-ai/ai-core/src/main/java/com/hiveminemobile/ai/manager/intel/PlanGraph.java`
- `hivemine-ai/ai-core/src/main/java/com/hiveminemobile/ai/manager/intel/PlanNode.java`

## Tests
- `hivemine-ai/tests/unit/com/hiveminemobile/ManagerIntelligenceTests.java`
- `hivemine-ai/tests/unit/com/hiveminemobile/PhasePowerTests.java`

## Status
Implemented in JVM code. Not run on an Android device. The APK and the real macro are not part of this phase.
