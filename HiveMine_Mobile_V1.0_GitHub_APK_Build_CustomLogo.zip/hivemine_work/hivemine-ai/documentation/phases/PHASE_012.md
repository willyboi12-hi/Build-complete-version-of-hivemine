# Phase 012 — StateAI

## Objective

Interpret the shared game state into one reliable view.

## Implementation

modules/StateAI.java: View, Reliability; interpret().

## Dependencies

GlobalStateManager (Phase 004). Depends on vision.

## Integration

Feeds FarmingAI, NavigationAI and RecoveryAI.

## Testing

StateAITests: freshness, confidence threshold, percent parsing, conflicts, reliability levels.

## Completion criteria

- Module registered with `ManagerCoordinator` and reported AVAILABLE after start.
- Capability `analyze.state` granted only through the policy supervisor.
- Unit checks pass in `tests/run.sh`.
- Result: Values are used only when observed, fresh and confident; everything else is listed as unusable.

## Safety boundary

Analysis only. The module reads data it is given and never performs a game or device action.
