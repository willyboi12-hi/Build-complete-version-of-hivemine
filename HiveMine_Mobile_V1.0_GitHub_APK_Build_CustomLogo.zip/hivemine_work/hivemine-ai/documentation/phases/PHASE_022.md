# Phase 022 — ConfigurationAI

## Objective

Validate settings against a schema and merge profiles.

## Implementation

modules/ConfigurationAI.java: Rule, Problem, Type; validate(), merge().

## Dependencies

BaseSpecialist, Identifiers.

## Integration

Registered through `ManagerCoordinator` and started with the other Stage 3 modules. Capability `analyze.configuration` is granted through the policy supervisor.

## Testing

ConfigurationAITests: required, integer range, boolean, text length, unknown keys, profile merge.

## Completion criteria

- Module reports AVAILABLE after start.
- Capability `analyze.configuration` is grantable and usable through a task.
- Unit checks pass in `tests/run.sh`.

## Notes

Unknown keys are reported, never kept. Applies nothing itself.

## Safety boundary

Analysis, configuration or reporting only. The module performs no game or device action.
