# Phase 015 — InventoryAI

## Objective

Recognise inventory changes and flag unexplained drops.

## Implementation

modules/InventoryAI.java: Change; compare().

## Dependencies

BaseSpecialist, Identifiers. Depends on vision.

## Integration

Declared spends explain drops; anything else is flagged as unexplained.

## Testing

InventoryAITests: explained and unexplained drops, new items, identifier and count validation.

## Completion criteria

- Module registered with `ManagerCoordinator` and reported AVAILABLE after start.
- Capability `analyze.inventory` granted only through the policy supervisor.
- Unit checks pass in `tests/run.sh`.
- Result: Reports changed items only, sorted by name, with explained/unexplained status.

## Safety boundary

Analysis only. The module reads data it is given and never performs a game or device action.
