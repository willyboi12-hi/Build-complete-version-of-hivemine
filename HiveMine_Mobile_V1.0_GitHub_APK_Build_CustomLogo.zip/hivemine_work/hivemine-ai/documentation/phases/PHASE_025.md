# Phase 025 — CompatibilityAI

## Objective

Check a device description against API level, permissions, features and memory.

## Implementation

modules/CompatibilityAI.java: Device, Requirements, Issue; check(), isCompatible().

## Dependencies

BaseSpecialist. Reads descriptions only; queries no device.

## Integration

Registered through `ManagerCoordinator` and started with the other Stage 3 modules. Capability `analyze.compatibility` is granted through the policy supervisor.

## Testing

CompatibilityAITests: fully compatible, blocking issues, warning-only, validation.

## Completion criteria

- Module reports AVAILABLE after start.
- Capability `analyze.compatibility` is grantable and usable through a task.
- Unit checks pass in `tests/run.sh`.

## Notes

Missing API, permission or feature is blocking. Low memory is a warning.

## Safety boundary

Analysis, configuration or reporting only. The module performs no game or device action.
