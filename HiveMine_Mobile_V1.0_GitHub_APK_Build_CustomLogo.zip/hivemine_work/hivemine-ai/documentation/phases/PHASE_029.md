# Phase 029 — SimulationAI

## Objective

Estimate strategy output under disruption scenarios.

## Implementation

modules/SimulationAI.java: Strategy, Scenario, Outcome, Ranked; simulate(), compare().

## Dependencies

BaseSpecialist. Depends on strategy.

## Integration

Registered through `ManagerCoordinator` and started with the other Stage 3 modules. Capability `simulate.scenario` is granted through the policy supervisor.

## Testing

SimulationAITests: calm and busy outputs, averaged comparison, validation.

## Completion criteria

- Module reports AVAILABLE after start.
- Capability `simulate.scenario` is grantable and usable through a task.
- Unit checks pass in `tests/run.sh`.

## Notes

Deterministic expected-value model. It does not run the game.

## Safety boundary

Analysis, configuration or reporting only. The module performs no game or device action.
