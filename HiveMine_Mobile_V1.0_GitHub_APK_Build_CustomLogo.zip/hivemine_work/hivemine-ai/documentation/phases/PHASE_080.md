# Phase 080 — Learning Intelligence Integration

Domain: MANAGER_INTEL (listed in index as "Manager intelligence 10")

## Status
Implemented in JVM code and tested (15 checks in `tests/unit/com/hiveminemobile/LearningIntegrationTests.java`). Not run on an Android device.

## Classes (package `com.hiveminemobile.ai.learning`)
- `LearningIntelligenceManager`: the central interface. Refreshes proposals from history, tracks rejections and outcomes. It has no method that changes a setting.
- `LearningDataCollector`: keeps usable records, counts incomplete ones (blank capability or decision, missing outcome).
- `LearningRecommendationEngine`: turns Learning AI insights into recommendations, skipping invalid and duplicate ones.
- `LearningResultEvaluator`: records whether a recommendation improved results, and computes the improvement rate.
- `LearningIntegrationBridge`: names the connected systems (farming, quest, configuration, analytics) and routes a recommendation to them as data. It does not call them.
- `Recommendation`: a proposal. Starts as PROPOSED.

## Built on
- `com.hiveminemobile.ai.modules.LearningAI` (existing) for insight generation.
- `com.hiveminemobile.ai.memory.ManagerMemory` (existing) for decision history.

## Not done
- The bridge only names and routes. Farming, Quest, Configuration, and Analytics do not yet consume the routed messages.
- The reconstructed spec (attachment d38ef26d) names extra classes such as `LearningFeedbackController` and `HistoricalPerformanceAnalyzer`. Those belong to phases 081 and 083, not this one.
- Accepting a recommendation is left to the user through a UI, which does not exist yet.
