# Phase 019 — LearningAI

## Objective

Summarise past outcomes per capability.

## Implementation

modules/LearningAI.java: Insight; learn().

## Dependencies

BaseSpecialist, ManagerMemory (Phase 008).

## Integration

Needs a minimum number of results before it draws conclusions. Never changes policy.

## Testing

LearningAITests: evidence minimum, unknown outcomes, rates, trends, advice, validation.

## Completion criteria

- Module registered with `ManagerCoordinator` and reported AVAILABLE after start.
- Capability `analyze.history` granted only through the policy supervisor.
- Unit checks pass in `tests/run.sh`.
- Result: Gives per-capability success rates, trends and advice once enough evidence exists.

## Safety boundary

Analysis only. The module reads data it is given and never performs a game or device action.
