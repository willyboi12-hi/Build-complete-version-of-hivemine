# Phase 073 — Decision fusion

Domain: MANAGER_INTEL
Implementor (per index): `com.hiveminemobile.ai.manager.intel.ManagerIntelligenceLoop`

## What it covers
- Phase 073 — Soft-max style fusion: sum confidence by goal, pick winner.

## Source
- `hivemine-ai/ai-core/src/main/java/com/hiveminemobile/ai/manager/intel/DecisionFusion.java`

## Tests
- `hivemine-ai/tests/unit/com/hiveminemobile/ManagerIntelligenceTests.java`
- `hivemine-ai/tests/unit/com/hiveminemobile/PhasePowerTests.java`

## Status
Implemented in JVM code. Not run on an Android device. The APK and the real macro are not part of this phase.
