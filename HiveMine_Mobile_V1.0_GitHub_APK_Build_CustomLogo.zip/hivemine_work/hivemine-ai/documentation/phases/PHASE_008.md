# Phase 008 — Manager Memory

## Scope

Phase 008 keeps a bounded history of HiveMineManagerAI decisions and their observed results, so later phases can see what worked.

## Added classes

- `memory/DecisionRecord` — immutable record: sequence, time, task, capability, specialist, decision, outcome (`SUCCESS`, `FAILURE`, `UNKNOWN`), detail.
- `memory/ManagerMemory` — bounded journal with `record`, `recent`, `forTask`, `count`, and `successRate`.

## Rules

- The oldest records are evicted first when capacity is reached.
- Detail text is capped at 500 characters.
- A blank decision or missing outcome is rejected.
- `successRate` counts only `SUCCESS` and `FAILURE`; `UNKNOWN` results do not affect it. It is empty when a capability has no such results.

## Wiring

`ManagerCoordinator` records a decision for each completed task (`SUCCESS`), each failed attempt (`FAILURE`), and each cancellation (`UNKNOWN`).

## Validation

Covered by `MemoryTests` and the coordinator tests.

## Safety boundary

Memory is an in-process record. It stores no game data beyond what specialists report, and it does not persist across restarts; persistence belongs to a later phase.
