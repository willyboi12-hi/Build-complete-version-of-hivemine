# Phase 072 — Specialist voting

Domain: MANAGER_INTEL
Implementor (per index): `com.hiveminemobile.ai.manager.intel.ManagerIntelligenceLoop`

## What it covers
- Phase 072 — Picks the highest-confidence vote; ties break by fixed specialist priority.
- Phase 072 — One specialist's recommendation.

## Source
- `hivemine-ai/ai-core/src/main/java/com/hiveminemobile/ai/manager/intel/SpecialistArbiter.java`
- `hivemine-ai/ai-core/src/main/java/com/hiveminemobile/ai/manager/intel/SpecialistVote.java`

## Tests
- `hivemine-ai/tests/unit/com/hiveminemobile/ManagerIntelligenceTests.java`
- `hivemine-ai/tests/unit/com/hiveminemobile/PhasePowerTests.java`

## Status
Implemented in JVM code. Not run on an Android device. The APK and the real macro are not part of this phase.
