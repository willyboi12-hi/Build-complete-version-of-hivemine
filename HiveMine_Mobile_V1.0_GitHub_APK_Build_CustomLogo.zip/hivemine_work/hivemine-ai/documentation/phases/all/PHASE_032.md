# Phase 032 — FieldSelectionAI specialist system

Domain: `SPECIALIST`

## Requirement
Unique phase implementation for **FieldSelectionAI specialist system** in the HiveMineAI 250-phase program.

## Implementation
- Catalog entry: `PhaseCatalog.get(32)`
- Primary implementor: `com.hiveminemobile.ai.merge.SpecialistCatalogFactory`
- Verified via: `PhaseExecutor.verify(32)`

## Status
IMPLEMENTED (JVM). Device verification UNVERIFIED unless noted elsewhere.

## Acceptance
- Catalog lists this phase as IMPLEMENTED
- PhaseExecutor returns ok for phase 32
- No empty placeholder-only specialist for specialist-domain phases
