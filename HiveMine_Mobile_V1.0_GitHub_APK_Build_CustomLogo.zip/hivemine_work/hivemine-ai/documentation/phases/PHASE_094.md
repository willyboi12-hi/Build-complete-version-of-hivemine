# Phase 094 — Smoke checks

Domain: INTEGRATION
Implementor (per index): `com.hiveminemobile.ai.integration.EndToEndSimulation`

## What it covers
- Phase 094 — Quick structural smoke checks.

## Source
- `hivemine-ai/ai-core/src/main/java/com/hiveminemobile/ai/integration/IntegrationSmoke.java`

## Tests
- `hivemine-ai/tests/unit/com/hiveminemobile/IntegrationTests.java`

## Status
Implemented in JVM code. Not run on an Android device. The APK and the real macro are not part of this phase.
