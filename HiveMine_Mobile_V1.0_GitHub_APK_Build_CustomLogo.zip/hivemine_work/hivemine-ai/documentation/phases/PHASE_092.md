# Phase 092 — Integration event bus

Domain: INTEGRATION
Implementor (per index): `com.hiveminemobile.ai.integration.EndToEndSimulation`

## What it covers
- Phase 092 — In-process pub/sub for integration events.
- Phase 092 — Bus event between manager and automation layers.

## Source
- `hivemine-ai/ai-core/src/main/java/com/hiveminemobile/ai/integration/IntegrationBus.java`
- `hivemine-ai/ai-core/src/main/java/com/hiveminemobile/ai/integration/IntegrationEvent.java`

## Tests
- `hivemine-ai/tests/unit/com/hiveminemobile/IntegrationTests.java`

## Status
Implemented in JVM code. Not run on an Android device. The APK and the real macro are not part of this phase.
