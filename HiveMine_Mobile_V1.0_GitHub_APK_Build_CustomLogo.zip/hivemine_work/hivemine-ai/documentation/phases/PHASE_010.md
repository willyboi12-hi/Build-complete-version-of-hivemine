# Phase 010 — Health Monitoring

## Scope

Phase 010 reports the health of HiveMineManagerAI and each specialist. It only reads state; it never changes module status.

## Added classes

- `health/HealthMonitor` — heartbeats, error attribution, and `evaluate`, which returns a `Report`.

## Levels

- `HEALTHY`, `DEGRADED`, `UNAVAILABLE`. The overall level is the worst of the manager and every specialist.
- A specialist reported `FAILED` or `UNAVAILABLE` by the registry is `UNAVAILABLE`.
- Heartbeats are optional. After a specialist has sent one: more than one timeout late is `DEGRADED`; more than three timeouts late is `UNAVAILABLE`.
- Registry `DEGRADED` is reported as `DEGRADED`.
- Errors at or above the threshold, attributed to that component, are `DEGRADED`.

## Wiring

`ManagerCoordinator.checkHealth` evaluates health and refuses new work to any specialist that is `UNAVAILABLE`. `assignTask` runs a check first, so a specialist that has missed heartbeats is not given work.

## Configuration

`health.heartbeatTimeoutMillis` (default 30000) and `health.errorThreshold` (default 5).

## Validation

Covered by `HealthTests`: fresh, late, and missed heartbeats, recovery, forgotten components, error attribution, registry status, and manager status. The coordinator tests cover gating and recovery.

## Safety boundary

Health reports describe readiness. They do not authorize any action.
