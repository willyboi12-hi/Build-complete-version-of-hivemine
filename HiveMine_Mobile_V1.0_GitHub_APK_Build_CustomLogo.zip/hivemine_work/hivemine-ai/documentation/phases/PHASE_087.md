# Phase 087 — Android permission manager

Domain: ANDROID

## Status
Implemented in JVM code and tested (checks in `tests/unit/com/hiveminemobile/Phases081To090Tests.java`). Not run on an Android device.

## What it does
Checks permissions through a provider interface. A permission is never assumed granted. Provider exceptions are reported as UNKNOWN.

## API
- `state`, `featureEnabled("macro-control"|"screen-observation")`, `explain`, `revoked()`.

## Not done
- Not wired to the dashboard. The JVM logic is tested, not the app.
- Overlap with existing code: see `OVERLAPS.md`.
