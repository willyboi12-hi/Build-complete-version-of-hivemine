# Phase 071 — Manager goals

Domain: MANAGER_INTEL
Implementor (per index): `com.hiveminemobile.ai.manager.intel.ManagerIntelligenceLoop`

## What it covers
- Phase 071 — Top-level manager goals (not macro commands).
- Phase 071 — Ordered goal stack. Higher index = lower priority.

## Source
- `hivemine-ai/ai-core/src/main/java/com/hiveminemobile/ai/manager/intel/ManagerGoal.java`
- `hivemine-ai/ai-core/src/main/java/com/hiveminemobile/ai/manager/intel/GoalHierarchy.java`

## Tests
- `hivemine-ai/tests/unit/com/hiveminemobile/ManagerIntelligenceTests.java`
- `hivemine-ai/tests/unit/com/hiveminemobile/PhasePowerTests.java`

## Status
Implemented in JVM code. Not run on an Android device. The APK and the real macro are not part of this phase.
