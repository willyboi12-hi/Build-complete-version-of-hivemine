# HiveMine AI Integration Handoff

## Current project

This is the combined HiveMine Mobile 1.8.0 Android project with HiveMine AI core 2.00 included as `:ai-core`. Earlier sections in `PHASE_001_SOURCE_INSPECTION.md` and `PHASE_002_PROJECT_STRUCTURE.md` document a previous 1.7.0 source inspection and should be read as historical baseline records, not current integration instructions.

## Runtime wiring now present

- `AiMacroPort` connects the AI control layer to `MacroAccessibilityService`.
- START/RECOVER requests are authorized by `AutomationController`; STOP remains available as an emergency path.
- A separate one-second Android service ticker refreshes macro status, bridge request completion, and AI `ScreenState`.
- Bag percentage and scene observations flow from the existing screenshot reader into the AI state. A one-second stale-frame watchdog is active on Android 11+ and handles the no-first-frame case.
- Supported setting proposals are validated, committed, and read back; failed writes attempt to restore the previous configuration.
- SQLite stores bounded operational event summaries. This is not a learned-policy database.

## Verification

- `bash tests/run.sh`: 897 passed.
- `bash tests/run-ai.sh`: 40 + 19 + 23 passed.
- Android Gradle build, lint, APK assembly, signing, and physical-device tests remain unverified. The local Gradle 8.9 distribution could not be downloaded in the audit environment.

## Remaining work

Full specialist orchestration, generic VisionAI frame analysis, learned-policy persistence, Android build/CI, and physical-device acceptance remain open. See `PHASE_LEDGER.md`, root `PRODUCTION_READINESS.md`, and `DEVICE_TEST_MATRIX.md`.

## Safety boundaries

Do not bypass `AutomationController`; do not treat a dispatched command as confirmed complete until the runtime status poll observes the resulting state; do not claim production readiness, undetectable automation, or account safety without evidence.
