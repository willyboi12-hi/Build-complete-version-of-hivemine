# Phase 001 — HiveMine Mobile Source Inspection

Status: IMPLEMENTED (inspection complete; reproducible with the script below). Not built as an APK and not run on a device.

## 1. Scope and method

Inspected the uploaded HiveMine Mobile v1.7.0 source archive (`HiveMineMobile-v1_7_0-Phase004-3.zip`), extracted to a scratch copy. The upload itself was not modified. Every fact below is reproduced by:

    bash documentation/inspection/inspect-natro-mobile.sh <path-to-natro-mobile-root>

The script is read-only. Its output on the uploaded tree is the evidence for this report.

## 2. Baseline identity

| Item | Value | Source |
| --- | --- | --- |
| Application id | `com.hiveminemobile` | app/build.gradle |
| Version | 1.7.0 (versionCode 17) | app/build.gradle |
| minSdk / targetSdk / compileSdk | 26 / 35 / 35 | app/build.gradle |
| Android Gradle Plugin | 8.7.3 | root build.gradle |
| Java source level | 1.8 | app/build.gradle |
| Build DSL | Groovy (`build.gradle`), no Kotlin files in any module | file scan |
| Modules | `:app`, `:ai-core` | settings.gradle |
| License | GNU GPL v3, stock text, no HiveMine-specific terms | HIVEMINE_SOURCE_LICENSE.md |

## 3. Architecture

`:app` (14 Java files, 4,225 lines) is the macro. Components:

- `MainActivity` — launcher UI. Reads the static service instance and calls its methods. No intent extras are handled (no `getIntent` or `onNewIntent`).
- `MacroAccessibilityService` — the automation engine, 1,828 lines. It runs gestures via `dispatchGesture`, takes screenshots via `takeScreenshot`, and owns the run loop. Public control methods: `startMacro()`, `startDelayed(ms)`, `stopMacro()`, `isRunning()`, `rejoinNow()`, `imLost()`, `showBubble()`, `hideBubble()`, `guidePoint(...)`, `autoSenseSpots()`, `checkDisconnectSpot(ms)`. Test and tool methods also exist: `testWalkToField`, `testMove`, `testItem`, `testTrip`, `walkCheck`. The static field `public static volatile MacroAccessibilityService instance` is set in `onServiceConnected` and cleared in `teardown()`. `onUnbind` and `onDestroy` both call `teardown()`, which also stops the macro.
- `Config` — settings stored in SharedPreferences `natro_mobile`, mode `MODE_PRIVATE`.
- `BagReader`, `AutoSense`, `Calibration` — observation by screenshot and pixel sampling.
- `Patterns`, `ExtraPatterns`, `FieldRoutes`, `FieldPresets`, `TripRoutes`, `PatternBuilder` — movement routes and tap sequences.
- `RobloxLink`, `Ui` — link conversion and UI helpers.

`:ai-core` (22 Java files, 1,067 lines) is the AI foundation: lifecycle, specialist registry, global state, and manager health. The app declares `implementation project(':ai-core')` in Gradle, but no app source file imports `com.hiveminemobile.ai`. The coupling is build-only.

`tests/` (53 Java files, 2,272 lines) is a JVM harness with Android stubs. It runs the macro engine on a simulated clock and does not need an Android SDK.

## 4. Communication surfaces inventory

| Surface | Present? | Callable by another app? | Notes |
| --- | --- | --- | --- |
| Exported activity | Yes (`MainActivity`) | Yes, but it accepts no commands | Launches the UI. No intent handling. |
| Exported service | Yes (`MacroAccessibilityService`) | No | Protected by `BIND_ACCESSIBILITY_SERVICE`; only the system binds it. |
| Static `instance` handle | Yes | No | Same-process only. |
| Broadcast receivers | None | — | Zero matches. |
| Bound service / AIDL / Messenger | None | — | Zero matches. |
| Content provider | None | — | Zero matches. |
| Sockets / HTTP | None | — | No INTERNET permission; no socket or HTTP code. |
| Declared permissions | None | — | The manifest declares no `uses-permission` at all. |
| SharedPreferences `natro_mobile` | Yes | No | MODE_PRIVATE. |
| Outgoing intents | Yes | — | Roblox `roblox://` launch, accessibility settings, MainActivity. |
| Readable status | In-process only | No | `isRunning()` and UI text fields. Nothing is exported. |

Conclusion: HiveMine Mobile exposes no interface that HiveMine AI can call or read. Any integration must add one.

## 5. Control points and safety

- Start: `startMacro()` or `startDelayed(ms)`.
- Stop: `stopMacro()`.
- System interrupt: `onInterrupt()` calls `stopMacro()`. The Android accessibility shortcut therefore already performs an emergency stop.
- The adapter must expose only start, stop, status, and the existing recovery actions (`rejoinNow`, `imLost`). It must never expose the `test*` or `walkCheck` methods, which drive gestures for testing.

## 6. Integration options evaluated

Revised integration model. HiveMineAI is a separate project that is merged into HiveMine Mobile later. The integration is therefore in-process, not cross-app. The earlier bridge-service analysis (IPC, signature permissions, shared signing key) is withdrawn because it does not apply to a merged build.

Design:

- HiveMineAI's core is an Android-free Java 8 library. It extends the `:ai-core` module that the uploaded project already contains (phases 001–004), rather than duplicating it.
- The core depends only on a `MacroPort` interface: `start()`, `startDelayed(ms)`, `stop()`, `isRunning()`, `recover()`, and `readStatus()`.
- The merge adds one adapter class in `com.hiveminemobile` that implements `MacroPort` by calling `MacroAccessibilityService.instance`. When the instance is null (service not connected), the adapter reports "not connected" and performs no action.
- Only start, stop, recover, and status are exposed. The `test*` and `walkCheck` methods are never exposed.
- Emergency stop: `MacroPort.stop()` calls `stopMacro()`. The system accessibility interrupt keeps working independently of the AI.
- User authorization: the AI starts the macro only after the user enables AI control in HiveMineAI's settings. Until then it only recommends.
- Division of labor: the AI chooses what to farm and when. HiveMine Mobile's existing routes and tap sequences perform the actions.

Testing:

- The core is tested on the JVM against a fake `MacroPort`.
- The adapter is tested only on a device, after the merge. Until then it is unverified.
- The existing JVM harness (`Sim`) continues to cover the macro engine itself.

## 7. Language and build decisions

- HiveMine Mobile is Java 8 with Groovy Gradle files and no Kotlin. The merged code must be Java 8 to build in the same project.
- HiveMineAI is therefore Java 8. The master prompt's Kotlin requirement does not apply to code that is merged into this project. Kotlin would need a new plugin in a build I cannot run here.

## 8. Licensing implications

- HiveMine Mobile is GPL-3.0. Once HiveMineAI's code is merged into it, that code is part of the same GPL-3.0 program.
- Any APK built from the merged project must be distributed under GPL-3.0, with its source available. If you distribute only for personal use, the obligation does not arise.
- This is a technical summary, not legal advice. Consult a lawyer before distributing.

## 9. Verification performed

- Inspection script re-run on the uploaded tree: all facts above reproduced.
- Upload verified unchanged: `app/` in the working copy is byte-identical to the upload.
- Baseline JVM suite on an untouched copy of the upload: 796 passed, 0 failed (`bash tests/run.sh`).
- Not performed: Gradle build, APK generation, device or emulator run. No Android SDK or Gradle is installed in this environment.

## 10. Open decisions before Phase 002

Resolved by the merge plan:

- Language: Java 8.
- Integration: in-process `MacroPort` adapter, not a bridge service.
- Signing: a shared signing key is not required.

Still open:

1. Stage numbering: the earlier roadmap and the 250-phase prompt number their phases differently. Which should HiveMineAI follow?
2. Confirm the authorization rule: the AI may start and stop the macro only after the user enables AI control in HiveMineAI's settings.
3. Confirm that HiveMineAI extends the existing `:ai-core` module in the HiveMine Mobile project, rather than creating a second AI module.

## 11. Known risks

- Roblox's rules generally prohibit third-party automation, so account risk exists regardless of this architecture.
- The macro reads the screen through screenshots and pixel sampling, so it depends on screen layout and resolution.
- The test harness uses hand-written Android stubs. Real Android behavior, including accessibility gesture timing, is untested.
