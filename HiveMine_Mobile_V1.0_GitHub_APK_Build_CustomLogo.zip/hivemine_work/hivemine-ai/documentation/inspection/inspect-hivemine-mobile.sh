#!/usr/bin/env bash
# Phase 001 — HiveMine Mobile source inspection.
# Re-derives every fact in PHASE_001_SOURCE_INSPECTION.md from a HiveMine Mobile source tree.
# Usage: bash inspect-natro-mobile.sh <path-to-natro-mobile-root>
# Read-only: it never modifies the source tree.
set -uo pipefail
ROOT="${1:?usage: inspect-natro-mobile.sh <natro-mobile-root>}"
cd "$ROOT"
MANIFEST="app/src/main/AndroidManifest.xml"
GRADLE="app/build.gradle"

section() { printf '\n== %s ==\n' "$1"; }

section "Build configuration"
grep -E "namespace|compileSdk|minSdk|targetSdk|versionName|versionCode|applicationId|sourceCompatibility|project\(" "$GRADLE" | sed 's/^ */  /'
echo "  settings modules: $(grep -oE "':[a-z-]+'" settings.gradle | tr '\n' ' ')"
echo "  root build.gradle: $(tr -s ' \n' ' ' < build.gradle)"

section "Manifest: components and their export status"
grep -oE '<(activity|service|receiver|provider)[^>]*' "$MANIFEST" | sed 's/^ */  /' || true
echo "  exported=true components: $(grep -c 'exported="true"' "$MANIFEST" || true)"
echo "  components protected by a permission attribute:"
grep -oE 'android:permission="[^"]*"' "$MANIFEST" | sed 's/^/    /' || echo "    none"

section "Manifest: declared permissions"
grep -oE '<uses-permission[^>]*' "$MANIFEST" | sed 's/^ */  /' || echo "  none declared"
grep -q "android.permission.INTERNET" "$MANIFEST" && echo "  INTERNET: declared" || echo "  INTERNET: NOT declared (no network sockets possible)"

section "Inter-app surfaces (broadcast, binding, IPC, providers, sockets, network)"
for pattern in "AIDL" "Messenger" "bindService" "BroadcastReceiver" "registerReceiver" "sendBroadcast" \
               "ContentProvider" "ServerSocket" "HttpURLConnection" "OkHttp" "localhost" "127.0.0.1"; do
  hits=$(grep -rl "$pattern" app/src/main 2>/dev/null | wc -l | tr -d ' ')
  printf '  %-20s files: %s\n' "$pattern" "$hits"
done

section "Intents and storage"
echo "  getIntent/onNewIntent handlers:"
grep -rn "getIntent()\|onNewIntent" app/src/main/java | sed 's/^/    /' || echo "    none"
echo "  SharedPreferences files:"
grep -rhoE 'getSharedPreferences\("[^"]*"' app/src/main/java | sed 's/^/    /' | sort -u
echo "  outgoing intents:"
grep -rhoE 'Intent\.ACTION_[A-Z_]*|new Intent\([^)]*\)' app/src/main/java | sort | uniq -c | sed 's/^/    /'

section "Accessibility service capabilities"
for attr in canPerformGestures canTakeScreenshot canRetrieveWindowContent accessibilityEventTypes; do
  grep -oE "android:$attr=\"[^\"]*\"" app/src/main/res/xml/accessibility_config.xml | sed 's/^/  /'
done
echo "  gesture dispatch calls: $(grep -rl 'dispatchGesture' app/src/main/java | wc -l | tr -d ' ') file(s)"
echo "  screenshot calls:       $(grep -rl 'takeScreenshot' app/src/main/java | wc -l | tr -d ' ') file(s)"

section "Languages and size (lines of source)"
for dir in app/src/main/java ai-core/src/main/java tests; do
  if [ -d "$dir" ]; then
    files=$(find "$dir" -name '*.java' | wc -l | tr -d ' ')
    lines=$(find "$dir" -name '*.java' -exec cat {} + 2>/dev/null | wc -l | tr -d ' ')
    printf '  %-26s java files: %-4s lines: %s\n' "$dir" "$files" "$lines"
  fi
done
echo "  kotlin files (any module): $(find . -name '*.kt' | wc -l | tr -d ' ')"

section "Upstream license"
head -2 HIVEMINE_SOURCE_LICENSE.md | sed 's/^/  /'
