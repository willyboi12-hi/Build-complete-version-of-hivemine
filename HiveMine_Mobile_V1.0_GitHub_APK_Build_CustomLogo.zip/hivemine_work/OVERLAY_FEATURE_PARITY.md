# HiveMine Mobile V1.0 — Floating Interface Feature Parity

The floating interface is intended to mirror the major controls available in the standalone HiveMine Mobile app while preserving the same underlying macro/AI controller.

## Mirrored controls
- Home: status, runtime, bag/pollen telemetry, Start, Stop, Pause (safe-stop semantics matching the main app), Resume, Emergency Stop, Farming Settings, Quick Actions, Recent Activity.
- Farming: field selection/preset application, Auto Farm, farm duration, bag-full threshold, pattern selection, movement speed, walk-before-farm, return-to-field.
- Quests: Smart Quests, quest interval, saved quest tap execution, quest/NPC tap counts.
- Inventory: live bag telemetry, conversion threshold, full-bag action.
- Settings: overlay transparency, humanized mode, Roblox watch/rejoin, return-to-field, rejoin wait, reset panel position, open full settings, show/hide overlay.
- AI: AI enable/disable, Start/Recover/Stop, natural-language Plan/Apply command center, recent AI decisions.

## Controller rule
All action buttons call the existing `MacroAccessibilityService`, `AutomationController`, or AI bridge. The floating UI does not implement a second macro engine.
