# Architecture overview

## Existing application
`MainActivity` owns user-facing configuration/dashboard screens. `MacroAccessibilityService` remains the execution engine for visible Android accessibility gestures, screenshots, bag reading, scene recognition, farming, conversion, reconnect, and fail-safe realignment. `Config` remains the persisted source of truth for macro settings.

## HiveMine AI boundary
`AiMacroPort` adapts the live service to `MacroPort`. All AI START/RECOVER requests pass through `AutomationController` and require the user-controlled AI-control switch. STOP is always attempted as the emergency path. An outcome such as `START_REQUESTED` is a request, not proof of execution; `AndroidMacroCommunicationBridge` tracks each request until live state confirms completion or timeout occurs.

## Closed-loop runtime

```text
AI chat / dashboard
        |
        v
AiManagerService / dashboard command bridge
        |
        v
AutomationController (authorization)
        |
        v
AiMacroPort -> MacroAccessibilityService
        |                  |
        |                  +--> accessibility gestures / reconnect / macro watchdog
        |                  +--> screenshot -> AutoSense / BagReader
        |                                      |
        +<----------- live MacroStatus <-------+
                           |
                           v
              AndroidMacroCommunicationBridge.observe
                           |
                           v
             ScreenState + command outcome history
                           |
                           v
                HiveMineAiMemoryDb (SQLite)
```

`MacroAccessibilityService` runs a separate one-second status ticker. It is intentionally independent from the gesture handler so cancelling automation steps does not stop command monitoring. Existing screenshot-based telemetry (bag percentage and scene) is published into `MacroStatus`; stale valid-frame data causes a safety stop after the configured fixed 15-second guard.

## Configuration and persistence
AI configuration proposals are validated, committed in one SharedPreferences transaction through `Config.save()`, and read back before success is reported. Operational events are stored in `HiveMineAiMemoryDb` (SQLite), capped at 2,000 rows. This event history is not yet a complete persisted training/learning model: `ManagerMemory` and specialist performance-learning still need a durable adapter.

## Manager and specialists
The AI core includes `ManagerCoordinator`, task/specialist registries, scheduling abstractions, and specialist analyzers. The current Android-facing command path still uses the BSS parser and transparent plan builder; full capability arbitration and specialist task execution are not yet connected end-to-end. Specialist source presence must not be confused with live execution.

## Safety and scope
All screen actions remain visible, user-authorized UI interactions. The project does not modify Roblox code, inspect hidden game memory, or bypass anti-cheat controls. AI control is OFF by default. If a feature lacks real observations or Android permission, it must report unavailable rather than fabricate state.

## Verification boundary
The JVM engine and AI/app wiring harnesses pass. The full Gradle build, lint, physical-device matrix, release APK, and signing have not been completed in this environment; see `PRODUCTION_READINESS.md` and `DEVICE_TEST_MATRIX.md`.
